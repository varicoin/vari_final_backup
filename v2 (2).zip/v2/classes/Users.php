<?php

class Users {

    public $app;
    public $db;
    public $mail;
    public $logs;
    public $JWToken;

    function __construct() {
        $this->app = new \Slim\Slim();
        $this->db = new DB();
        $this->mail = new Mail();
        $this->logs = new Logs();
        $this->JWToken = new JWToken();
    }

 
    function login($data, $type) {
        $email = $data['email'];
        $pwd = $data['password'];
        $user_login_qry = "SELECT * FROM `varicoin_stage`.`employee` WHERE `employee`.`email`='$email' AND `employee`.`password`='$pwd'";
        $res = $this->db->Q($user_login_qry);
        $num_rows = $this->db->NumRows($res);
        if ($num_rows < 1) {
            return array('status' => false, 'message' => 'Authorization credentials failed!');
        } else {
            $row = $this->db->R($res);

            $new['status'] = TRUE;
            
            $new['emp_id'] = $row['emp_id'];
            $new['email'] = $row['email'];
            $new['first_name'] = $row['first_name'];
            $new['last_name'] = $row['last_name'];

            $token = $this->JWToken->issueToken($new);
            $new['token'] = $token;
            return $new;
        }
    }

   

}
