<?php
	mysql_connect ('dandmudik.ipagemysql.com', 'varicoinstage', '$RtN }@<[ yd6J #lYc |H$a )+5') or die ("unable to connect with the database");
	mysql_select_db ("varicoin_stage")or die ("unable to select database");
?>