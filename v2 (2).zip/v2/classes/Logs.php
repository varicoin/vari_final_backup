<?php
class Logs{
  public $db;
  //public $app;
  function __construct(){
	   $this->db = new DB();
     //$this->app = new \Slim\Slim();
  }
  public function insertToken($token){
    $sqlu = "INSERT INTO mmtvTF.token_logs (auth_token) VALUES ('$token')";
    $insertu=$this->db->Q($sqlu);
    $last_id = $this->db->lastId($insertu);
    if($insertu){
      return $last_id;
    }else{
      return false;
    }
  }

  public function insertTokenlog($token){
    if($token != NULL){
      $tid = $token['token_id'];
      $route = addslashes($token['route']);
      $logType = $token['logType'];
      $reqHead = addslashes($token['reqHead']);
      $reqBody = addslashes($token['reqBody']);
      $response = addslashes($token['response']);
      $appMeta = addslashes($token['appMeta']);
      $userMeta = addslashes($token['userMeta']);
      $userId = $token['userId'];
    }

    $sql = "INSERT INTO mmtvTF.logs (token_id,route,log_type,request_header,request_body, return_response, token_meta, user_meta, userID) VALUES ('$tid','$route','$logType','$reqHead','$reqBody','$response','$appMeta','$userMeta','$userId')";
    $insert=$this->db->Q($sql);
    //return $insert;
    $last_id = $this->db->lastId($insert);
    if($insert){
      return $last_id;
    }else{
      return false;
    }
  }

}
