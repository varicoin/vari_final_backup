<?php

class DB
{
	var $res_per_page;
	var $pageNum;
	var $res;
	var $db;
	var $page;
	var $row;

	function DB ()
	{
		if (file_exists("dbinc/db.inc.php"))
		{
			include "dbinc/db.inc.php";
		}
		else
		{
			include "dbinc/db.inc.php";
		}
	}

	function Q ( $SQL )
	{
	//echo $SQL;
		return ( mysql_query ( $SQL ) );
	}

	function R ( $res )
	{
	    return ( mysql_fetch_array ( $res ) );
	}

	function NumRows ( $res )
	{
	    return ( mysql_num_rows ($res) );
	}

	function affected ($res)
	{
		return ( mysql_affected_rows () );
	}

	function lastId ($res)
	{
		return (mysql_insert_id());
	}

	function pages($query,$res_per_page,$resultpage,$db)
	{
		$this->db = $db;
	    $this->res = $this->Q($query);
	    $this->res_per_page = $res_per_page;

	    if ((int)$resultpage <= 0)
	    	$resultpage = 1;
	    $res = $this->res;
	    if ($resultpage > $this->NumRows($this->res))
	    	$resultpage = $this->NumRows($this->res);
	    $this->setPageNum($resultpage);
	}

	function setPageNum($pageNum)
	{
	    if ($pageNum > $this->getNumPages($this->res) or
	        $pageNum <= 0) return FALSE;

	    $this->page = $pageNum;
	    $this->row = 0;
	    echo $this->pageNum;

	    mysql_data_seek($this->res,($pageNum-1) * $this->res_per_page);
	}

	function getPageNum()
    {
	  	return $this->page;
    }

	function isLastPage()
	{
    	return ($this->page >= $this->getNumPages($this->res));
  	}

  	function isFirstPage()
  	{
    	return ($this->page <= 1);
  	}

  	function fetchArray()
  	{
    	if (!$this->res)
    		return FALSE;
    	if ($this->row >= $this->res_per_page)
    		return FALSE;
    	$this->row++;
    	return mysql_fetch_array($this->res);
  	}

    function getNumPages()
    {
  		if (!$this->res)
  			return FALSE;

    	return ceil(mysql_num_rows($this->res) /
            (float)$this->res_per_page);
  	}

	function getPagePrev($queryvars = '')
  	{
		$nav = "";
  		if (!$this->isFirstPage())
    	{
       		$nav .= "<a class=\"smalllink\" href=\"?resultpage=".
              ($this->getPageNum()-1).'&'.$queryvars.'">' . BACK_RES . '</a> ';
    	}
    	return $nav;
  	}

	function getPageNext($queryvars = '')
  	{
  	    $nav = "";
  		if (!$this->isLastPage())
    	{
      		$nav .= "<a class=\"smalllink\" href=\"?resultpage=".
              ($this->getPageNum()+1).'&'.$queryvars.'">'. FORW_RES . '</a>';
    	}
    	return $nav;
  	}

	function getPageNav($queryvars = '')
  	{
  	    $nav = "";
  	   if (!$this->isFirstPage())
    	{
       		$nav .= "<a href=\"?resultpage=".
              ($this->getPageNum()-1).'&'.$queryvars.'">' . PREV_RES . '</a> ';
    	}

    	if ($this->getNumPages($this->res) > 1)
      	for ($i=1; $i<=$this->getNumPages($this->res); $i++)
      	{
        	if ($i==$this->page)
          		$nav .= "$i ";
        	else
        	  	$nav .= "<a href=\"?resultpage={$i}&".
                  $queryvars."\">{$i}</a> ";
		}
    	if (!$this->isLastPage())
    	{
      		$nav .= "<a href=\"?resultpage=".
              ($this->getPageNum()+1).'&'.$queryvars.'">'. NEXT_RES . '</a> ';
    	}

    	return $nav;
	}

}
?>
