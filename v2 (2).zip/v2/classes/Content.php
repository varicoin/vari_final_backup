<?php

class Content {

    public $app;
    public $db;
    public $mail;
    public $logs;
    public $JWToken;

    function __construct() {
        $this->app = new \Slim\Slim();
        $this->db = new DB();
        $this->mail = new Mail();
        $this->logs = new Logs();
        $this->JWToken = new JWToken();
    }
	/****** Adding Customer ***********/
    function dealerAdd($dealer_details) {
		
			$cust_str = array();
			$cust_vals = array();
		
		
			foreach ($dealer_details as $key => $val) {
				$cust_str[] = $key;
				$cust_vals[] = '"'.$val.'"';
			}
			$cust_str =  implode(',', $cust_str);
			$cust_vals =  implode(',', $cust_vals); 
			$insert_cust_sql = "insert into `varicoin_stage`.`water` (".$cust_str.") VALUES " . "(".$cust_vals.")";
			$res_cust = $this->db->Q($insert_cust_sql);
			
			
			if ($res_cust) {
			
				return array('status' => TRUE);
            }
			else
			{
				return array('status' => FALSE, 'message' => 'Adding Customer details has failed !');
			}
        }
		/****** Customer List ***********/
		 function customerList($data) {
			$page  = $data['page'];
			$limit = $data['limit'];
			
			$cust_list_sql = "select * from pmj.customer order by cust_id DESC limit $page,$limit";
			
			
			$res = $this->db->Q($cust_list_sql);
			$rows = $this->db->NumRows($res);
			 if ($rows < 1) {
				return false;
			}
			else {
            $a = array();
			$i=0;
			 $a['status'] = TRUE;
			 $a['count'] = $rows;
			 while ($row = $this->db->R($res)) {
                $a['list'][$i]['customer_details']['cust_id'] = $row['cust_id'];
				 $a['list'][$i]['customer_details']['name'] = $row['name'];
				 $a['list'][$i]['customer_details']['email'] = $row['email'];
				 $a['list'][$i]['customer_details']['phone'] = $row['phone'];
				 $a['list'][$i]['customer_details']['dob'] = $row['dob'];
				 $a['list'][$i]['customer_details']['proof_type'] = $row['proof_type'];
				 $a['list'][$i]['customer_details']['proof_id'] = $row['proof_id'];
				 $a['list'][$i]['customer_details']['country'] = $row['country'];
				 $a['list'][$i]['customer_details']['city'] = $row['city'];
				 $a['list'][$i]['customer_details']['pincode'] = $row['pincode'];
				 $a['list'][$i]['customer_details']['address1'] = $row['address1'];
				 $a['list'][$i]['customer_details']['address2'] = $row['address2'];
				 $a['list'][$i]['customer_details']['Lankdmark'] = $row['landmark'];
				 $a['list'][$i]['customer_details']['alternate_address'] = $row['alternate_address'];
				 $a['list'][$i]['customer_details']['investment_duration'] = $row['investment_duration'];
				 $a['list'][$i]['customer_details']['investment_amount'] = $row['investment_amount'];
				 $a['list'][$i]['customer_details']['enrollment_start_date'] = $row['enrollment_start_date'];
				 $a['list'][$i]['customer_details']['enrollment_end_date'] = $row['enrollment_end_date'];
				 $a['list'][$i]['customer_details']['receipt_no'] = $row['receipt_no'];
				 $a['list'][$i]['customer_details']['receipt_date'] = $row['receipt_date'];
				$cust_nominee_sql = "select * from pmj.nominee where cust_id='".$row['cust_id']."'";
			    $res_nominee = $this->db->Q($cust_nominee_sql);
				$row_nominee = $this->db->R($res_nominee);
				 $a['list'][$i]['nominee_details']['id'] = $row_nominee['id'];
				 $a['list'][$i]['nominee_details']['name'] = $row_nominee['name'];
				 $a['list'][$i]['nominee_details']['email'] = $row_nominee['email'];
				 $a['list'][$i]['nominee_details']['phone'] = $row_nominee['phone'];
				 $a['list'][$i]['nominee_details']['dob'] = $row_nominee['dob'];
				 $a['list'][$i]['nominee_details']['relation'] = $row_nominee['relation'];
				 $a['list'][$i]['nominee_details']['country'] = $row_nominee['country'];
				 $a['list'][$i]['nominee_details']['city'] = $row_nominee['city'];
				 $a['list'][$i]['nominee_details']['pincode'] = $row_nominee['pincode'];
				 $a['list'][$i]['nominee_details']['address1'] = $row_nominee['address1'];
				 $a['list'][$i]['nominee_details']['Address2'] = $row_nominee['address2'];
				 $a['list'][$i]['nominee_details']['address2'] = $row_nominee['landmark'];
				 $a['list'][$i]['nominee_details']['createdDate'] = $row_nominee['createdDate'];
				$cust_payment_sql = "select * from pmj.payment where cust_id='".$row['cust_id']."'";
			    $res_pay = $this->db->Q($cust_payment_sql);
				$row_pay = $this->db->R($res_pay);
				 $a['list'][$i]['payment_details']['id'] = $row_pay['id'];
				 $a['list'][$i]['payment_details']['mode'] = $row_pay['mode'];
				 $a['list'][$i]['payment_details']['check_no'] = $row_pay['check_no'];
				 $a['list'][$i]['payment_details']['bank'] = $row_pay['bank'];
				 $a['list'][$i]['payment_details']['branch'] = $row_pay['branch'];
				 $a['list'][$i]['payment_details']['amount'] = $row_pay['amount'];
				 $a['list'][$i]['payment_details']['createdDate'] = $row_pay['createdDate'];
				$cust_collection_sql = "select * from pmj.collection where cust_id='".$row['cust_id']."'";
			    $res_collection = $this->db->Q($cust_collection_sql);
				$row_collection = $this->db->R($res_collection);
				 $a['list'][$i]['collection_details']['id'] = $row_collection['id'];
				 $a['list'][$i]['collection_details']['emp_id'] = $row_collection['emp_id'];
				 $a['list'][$i]['collection_details']['comments'] = $row_collection['comments'];
				 $a['list'][$i]['collection_details']['collectionDate'] = $row_collection['collectionDate'];
				
				
              
				$i++;
            }
			
            return $a;
        }
        }
}
