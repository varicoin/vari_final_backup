<?php
class Mail {
  function sendJ($msg){
    $mandrill = new Mandrill('xHgcF4eopDvp_Kd3L0s2Kw');
    $result = $mandrill->messages->send($msg);
  }
}
