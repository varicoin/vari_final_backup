<?php
class TokenAuth extends \Slim\Middleware {
	public $logs;
	public $JWToken;
    public function __construct() {
			$this->JWToken = new JWToken();
			$this->logs = new Logs();
    }
    public function deny_access() {
        $res = $this->app->response();
        $res->setBody('Invalid Token');
        $res->status(401);
    }
		public function loginRequired() {
        $res = $this->app->response();
        $res->setBody('Login required.');
        $res->status(401);
    }
    public function call() {
			$app = $this->app;
			$currentRoute = $app->request()->getPathInfo();
                        

			if($currentRoute =='/user/payment/fail/' ||$currentRoute =='/user/payment/cancel/' ||
                            $currentRoute =='/user/payment/success/' || $currentRoute =='/user/auth/login/' || 
                                $currentRoute =='/user/auth/deleteUser/' || $currentRoute == '/getToken/' ||
                                $currentRoute == '/user/sppay/success/' || $currentRoute == '/user/sppay/fail/' || 
                                 $currentRoute == '/user/sppay/cancel/' || $app->request->isGet()) {
				/*if(strpos($currentRoute,'/user/auth/devices/') !==false){
					if(array_key_exists("loggedIN",$_SESSION) && $_SESSION["loggedIN"] == TRUE){
						$this->next->call();
					}else{
						//$this->loginRequired();
						$token = explode('/',$currentRoute);
						if(!empty($token['5'])){
								$userData = json_decode(base64_decode($token['5']),true);
								if(in_array("email", $userData) || !empty($userData["email"])){
									$app->render('user/login.html', array('email'=>$userData['email'],'field'=>'disabled="disabled"'));
								}else{
									$this->deny_access();
								}
						}else{
							$this->deny_access();
						}
					}
				}else{
					$this->next->call();
				}*/
				$this->next->call();
			}
                       else if($app->request->isPost() &&  $currentRoute == '/user/email/' )
                       {
                           $this->next->call();
                       }
                        else{
          $tokenAuth = $app->request->headers->get('Authorization');
          //print_r($this->authenticate($tokenAuth));
          if(!empty($tokenAuth) && $this->JWToken->authenticate($tokenAuth)){
              $this->next->call();
							//$app->response->getBody();
          }else{
						//if($currentRoute == '/user/auth/confirm/' || $currentRoute == '/user/auth/resendConfirmation/'){
						if($currentRoute == '/user/auth/resendConfirmation/'){
							$this->next->call();
						}else{
							$this->deny_access();
						}
          }
      }
    }
}
