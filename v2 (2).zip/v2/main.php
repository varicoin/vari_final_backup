<?php

session_cache_limiter(false);
session_start();
date_default_timezone_set('America/New_York');
require 'vendor/autoload.php';
require 'classes/autoload.php';


if (isset($_SERVER['HTTP_ORIGIN'])) {
    header("Access-Control-Allow-Origin: {$_SERVER['HTTP_ORIGIN']}");
    header('Access-Control-Allow-Credentials: true');

    header("Access-Control-Allow-Headers: AUTHORIZATION, X-CLIENT-ID, X-CLIENT_SECRET");
    header('Access-Control-Max-Age: 86400');    // cache for 1 day
}

// Access-Control headers are received during OPTIONS requests
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {

    if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_METHOD']))
        header("Access-Control-Allow-Methods: GET, POST, OPTIONS");

    if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']))
        header("Access-Control-Allow-Headers:        {$_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']}");

    exit(0);
}


$user = new Users();
$JWToken = new JWToken();
$Content = new Content();


$app = new \Slim\Slim(array(
    'debug' => true,
    'templates.path' => 'templates',
    'mode' => 'development',
    'log.enabled' => true,
    'cookies.domain' => 'localhost',
    'cookies.secure' => true,
    'http.version' => '1.1',
    'view' => new \Slim\Views\Twig()
        ));

$app->setName('MMTV_API');
$view = $app->view();
$view->parserOptions = array(
    'debug' => true,
    'cache' => dirname(__FILE__) . '/cache'
);
$view->parserExtensions = array(
    new \Slim\Views\TwigExtension(),
);
//Basic Auth
$app->add(new \Slim\Middleware\HttpBasicAuthentication([
    "path" => ["/getToken", "/user/auth/login/"],
    "realm" => "Protected",
    "secure" => false,
    "relaxed" => ["localhost", "vari.co.in"],
    "users" => ["mang0t0ucH" => "t0uchm@ng0f0n3!"]
]));

$app->add(new \TokenAuth());

$app->notFound(function () use ($app) {
    echo "Page Not Found!";
});

$app->error(function (\Exception $e) use ($app) {
    if ($app['mode'] === 'development') {
        // Output exception message
        echo $e->getMessage();
        // Output stacktrace
        debug_print_backtrace();
    } else {
        echo "Something went wrong. We are looking into it.";
        // PRO TIP: Use a third-party logger here (e.g. Monolog)
    }
});

//DIGEST AUTH
//$app->add(new \Slim\Extras\Middleware\HttpDigestAuth(array('mang0t0ucH' => 't0uchm@ng0f0n3!')));

$app->post('/user/email/', function()use($app, $user, $JWToken) {
    $body = json_decode($app->request->getBody(), true);
    $email = array("email" => $body['email']);
    $userDetails = $user->getDetailsByMailId($body['email']);

    $app->response->setBody(json_encode(
                    array('token_email' => $JWToken->issueToken($userDetails) . '/' . base64_encode(json_encode($email))
    )));
});

$app->get('/', function () use ($app) {
    echo "UnAuthorized!";
});

$app->get('/logout/', function () use ($app) {
    if (in_array('loggedIN', $_SESSION)) {
        var_dump($_SESSION['loggedIN']);
    }

    $_SESSION = array();
    session_destroy();

    if (in_array('loggedIN', $_SESSION)) {
        var_dump($_SESSION['loggedIN']);
    } else {
        echo 'Logged Out';
    }
});

$app->post('/getToken/', function () use ($app, $JWToken) {
    $body = json_decode($app->request->getBody(), true);
    if (is_array($body) && empty($body) && !array_key_exists('deviceId', $body)) {
        $app->response->setStatus(401);
    } else {
        $token = $JWToken->checkApp($body, true);
        if ($token) {
            $app->response->setBody($token);
        } else {
            $app->response->setStatus(401);
        }
    }
});



//User Modules
//
$app->group('/user', function () use ($app, $user, $JWToken, $Content) {
    $app->group('/auth', function () use ($app, $user, $JWToken, $Content) {

        $app->post('/login/', function () use ($app, $user, $JWToken) {
		

            $body = json_decode($app->request->getBody(), TRUE);

            $data = $user->login($body, 'MAIL');

            $app->response->headers->set('Content-Type', 'application/json');
            $app->response->setBody(json_encode($data));
        });


	});

 });
 
 $app->group('/water', function () use ($app, $user, $JWToken, $Content) {
	 $app->post('/dealerAdd/', function () use ($app, $JWToken,$Content) {
		$body = json_decode($app->request->getBody(), true);
		$agent = $app->request->headers();
		$tokenAuth = $agent->get('Authorization');
		$payload = json_decode($JWToken->getUserPayload($tokenAuth), true);
		$body = json_decode($app->request->getBody(), true);
		
		
		if (!is_null($payload) && array_key_exists('emp_id', $payload)) {
			
            $details = $Content->customerAdd($body['dealer_details']);
            if ($details) {
                $app->response->headers->set('Content-Type', 'application/json');
                $app->response->setStatus(200);
                $app->response->setBody(json_encode($details));
            } else {
                $app->response->headers->set('Content-Type', 'application/json');
                $app->response->setBody(json_encode(array("status" => FALSE)));
                $app->response->setStatus(403);
            }
        } else {

            $app->response->headers->set('Content-Type', 'application/json');
            $app->response->setBody(json_encode(array("status" => FALSE, "message" => "Invalid Token!")));
            $app->response->setStatus(401);
        }
	});
	
	$app->post('/list/', function () use ($app, $JWToken,$Content) {
		$body = json_decode($app->request->getBody(), true);
		$agent = $app->request->headers();
		$tokenAuth = $agent->get('Authorization');
		$payload = json_decode($JWToken->getUserPayload($tokenAuth), true);
		$body = json_decode($app->request->getBody(), true);
		
		if (!is_null($payload) && array_key_exists('emp_id', $payload)) {
			$emp_id = $payload['emp_id'];
            $details = $Content->customerList($body);
            if ($details) {
                $app->response->headers->set('Content-Type', 'application/json');
                $app->response->setStatus(200);
                $app->response->setBody(json_encode($details));
            } else {
                $app->response->headers->set('Content-Type', 'application/json');
                $app->response->setBody(json_encode(array("status" => FALSE)));
                $app->response->setStatus(403);
            }
        } else {

            $app->response->headers->set('Content-Type', 'application/json');
            $app->response->setBody(json_encode(array("status" => FALSE, "message" => "Invalid Token!")));
            $app->response->setStatus(401);
        }
	});
});


$app->run();
