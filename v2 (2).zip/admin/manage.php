<?php
@session_start();
include("../includes/paths.php");
error_reporting(1);
if (isset($_REQUEST['page'])) {
    $page = $_REQUEST['page'];
}else{
    $page = 1;
}
if (isset($_REQUEST['rp'])) {
	$rp = $_REQUEST['rp'];
}else{
	$rp = 34;
}
require("../includes/admin.class.php");
$function = new Admin();
switch($_REQUEST['mode']){
	case 'getPostMails':
		echo $function->getPostMails($page, $rp, null, null);
		break;
    case 'managereplymails':
        echo $function->getRecentReplies($page,null, null,'0, 1');
        break;
    case 'classifiedads':
        echo $function->getRecentMails($page,null, null,'1,2');
        break;
    case 'managenewpostssms':
        echo $function->getRecentReplies($page,null, null);
        break;
    case 'sendsms':
        echo $function->getSMSRecords($page,null, null);
        break;
    case 'managehelp':
        echo $function->getHelpRecords($page,null, null,'0, 1');
        break;
    case 'getReplyDetails':
        $ids = implode(",", $_POST['ids']);
        echo $function->getReplyDetails($ids);
        break;
    case 'rejectReplies':
        $ids = implode(",", $_POST['ids']);
        echo $function->rejectReplies($ids);
        break;
    case 'searchPosts':
       $numbers = $_POST['numbers'];
       echo $function->getPostsOnMobile($numbers, $page,null);
       break;
}
exit;