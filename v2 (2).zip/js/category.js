globalModuleApp.factory('checkFilter', [function(){
    return function(totalAds, conditions){
        if (!angular.isUndefined(totalAds) && !angular.isUndefined(conditions) && conditions.length > 0) {
            var tmpRecords =[];
            angular.forEach(conditions, function (condition) {
            	id = condition[0];
                key = condition[1];
                if(id.length>0){
                	angular.forEach(totalAds, function (totalAd) {
                        if (id.indexOf(totalAd[key])!==-1) {
                            tmpRecords.push(totalAd);
                        }
                    });
                }
            });
            return tmpRecords;
        }else{
            return totalAds;
        }
    }
}]);

globalModuleApp.controller('categoryController', function($scope, $http, $rootScope,checkFilter){
        $scope.quantityTypes = ['', 'PER Each', 'PER KG', 'PER Quintal', 'Per Ton', 'Per Litre', 'Others'];
        $scope.postingbyTypes = $rootScope.postingbyTypes;
        $scope.sellingTypes = ['SELLING', 'BUYING', 'Closed'];
	    $scope.subCategories = subCategories;
        $scope.category = categories[0];
        $scope.states = [{"main":["24","Andhra Pradesh ","andhra"],"districts":[["31","Krishna","krishna"],["32","Guntur","guntur"],["33","West Godavari","west-godavari"],["34","East Godavari","east-godavari"],["35","Visakhapatnam","visakhapatnam"],["36","Vijayanagaram","vizianagaram"],["37","Srikakulam","sri-kakulam"],["38","Warangal","warangal"],["39","Rangareddy","rangareddy"],["40","Prakasam","prakasam"],["41","Nizamabad","nizamabad"],["42","Nellore","nellore"],["43","Nalgonda","nalgonda"],["44","Medak","medak"],["45","Mahabubnagar","mahabubnagar"],["46","Kurnool","kurnool"],["47","Khammam","khammam"],["48","Karimnagar","karimnagar"],["49","Cuddepah","cuddepah"],["50","Chittoor","chittoor"],["51","Anantpur","anantpur"],["52","Adilabad","adilabad"],["513","Hyderabad","Hyderabad"]]},{"main":["14","Arunachal Pradesh","arunachal"],"districts":null},{"main":["13","Assam","assam"],"districts":null},{"main":["9","Bihar","bihar"],"districts":[["460","Paschim Chamrapran","west-champaren"],["461","Purvi Chamrapran","east-champaren"],["462","Sitamarhi","sitamarhi"],["463","Madhubani","madhubani"],["464","Supaul","supaul"],["465","Araria","araria"],["466","Kishanganj","kishanganj"],["467","Purnia","purnia"],["468","Katihar","katihar"],["469","Madhepura","madhepura"],["470","Saharsa","saharsa"],["471","Darbhanga","darbhanga"],["472","Muzaffarpur","muzzaffarpur"],["473","Gopalganj","gopalganj"],["474","Siwan","siwan"],["475","Saran","saran"],["476","Vaishali","vaishali"],["477","Samastipur","samastipur"],["478","Begusarai","begusarai"],["479","Khagaria","khagaria"],["480","Bhagalpur","bhagalpur"],["481","Banka","banka"],["482","Munger","munger"],["483","Lakhisarai","luckeesarai"],["484","Sheikhpura","sheikhpura"],["485","Nalanda","nalanda"],["486","Patna","patna"],["487","Bhojpur","bhojpur"],["488","Buxar","buxar"],["489","Kaimur (Bhabua)","bhabua"],["490","Rohtas","rohtas"],["491","Arwal","arwal"],["492","Jahanabad","jehanabad"],["493","Aurangabad (Bihar)","aurangabad (bihar)"],["494","Gaya","gaya"],["495","Nawada","nawada"],["496","Jamui","jamui"],["497","Sheohar","sheohar"]]},{"main":["21","Chhattisgarh","chhattisgarh"],"districts":[["444","Koria","Bharatpur"],["445","Surguja","ambikapur"],["446","Jashpur","jashpur"],["447","Raigarh","raigarh"],["448","Korba","korba"],["449","Bilaspur","bilaspur"],["450","Janjgir-Champa","janjgir"],["451","Mahasamund","mahasamund"],["452","Raipur","raipur"],["453","Dhamtari","dhamtari"],["454","Durg","durg"],["455","Kawardha","kawardha"],["456","Rajnandgaon","rajnandgaon"],["457","Kanker(Uttar Bastar)","kanker"],["458","Bastar","jagdalpur"],["459","Dantewada(Dakshin Bastar)","dantewada"]]},{"main":["26","Delhi","delhi"],"districts":[["501","Central Delhi","Central Delhi"],["502","North Delhi","North Delhi"],["503","South Delhi","South Delhi"],["504","East Delhi","East Delhi"],["505","N .East Delhi","N. East Delhi"],["506","S. West Delhi","S. West Delhi"],["507","New Delhi","New Delhi"],["508","N. West Delhi","N. West Delhi"],["509","West Delhi","West Delhi"]]},{"main":["27","Goa","goa"],"districts":[["511","North Goa","North Goa"],["512","South Goa","South Goa"]]},{"main":["19","Gujarat","gujarat"],"districts":[["109","Kachchh","kutch"],["110","Banaskantha","banaskantha"],["111","Patan","patan"],["112","Mahesana","mehsana"],["113","Sabarkantha","sabarkantha"],["114","Gandhinagar","gandhinagar"],["115","Ahmedabad","ahmedabad"],["116","Surendranagar","surendranagar"],["117","RajKot","rajkot"],["118","Jamnagar","jamnagar"],["119","Porbandar","porbandar"],["120","Junagadh","junagadh"],["121","Amreli","amreli"],["122","Bhavnagar","bhavnagar"],["123","Anand","anand"],["124","Kheda","kheda"],["125","Panchmahals","panchmahal"],["126","Dahod","dohad"],["127","Vadodara","baroda"],["128","Narmada","narmada"],["129","Bharuch","broach"],["130","Surat","surat "],["131","Dangs","dangs "],["132","Navasri","navsari"],["133","Valsad","valsad"]]},{"main":["6","Haryana","haryana"],"districts":[["54","Panchkula","panchkula"],["55","Ambala","ambala"],["56","Yamunanagar","yamuna-ngr"],["57","Kurukshetra","kurukshetra"],["58","Kaithal","karithal"],["59","Karnal","karnal"],["60","Panipat","panipat"],["61","Sonipat","sonipat"],["62","Jind","jind"],["63","Fatehabad","fatehabad"],["64","Sirsa","sirsa"],["65","Hisar","hissar"],["66","Bhiwani","bhiwani"],["67","Rohtak","rohtak"],["68","Jhajjar","jhajjar"],["69","Mahendragarh","mahendragarh"],["70","Rewari","rewari"],["71","Gurgaon","gurgaon"],["72","Mewat","mewat"],["73","Palwal","palwal"],["74","Faridabad","faridabad"]]},{"main":["3","Himachal Pradesh","himachal"],"districts":[["388","Chamba","chamba"],["389","Kangra","kangra"],["390","Lahaul & Spiti","lahaul-spiti"],["391","Kullu","kulu"],["392","Mandi","mandi"],["393","Hamirpur","hamirpur"],["394","Una","una"],["395","Bilaspur","bilaspur-hp"],["396","Sloan","solan"],["397","Sirmour","sirmur"],["398","Shimla","shimla"],["399","Kinnaur","kinnaur"]]},{"main":["2","Jammu & Kashmir ","jammukashmir"],"districts":[["499","Jammu","Jammu"],["500","Samba","Samba"]]},{"main":["10","Jharkhand","jharkhand"],"districts":[["514"," Deoghar (J)",""]]},{"main":["25","Karnataka","karnataka"],"districts":[["134","Belgaum","belgaum"],["135","Bagalkot","bagalkote"],["136","Gadag","gadag"],["137","Bijapur","bijapur"],["138","Gulbarga","gulbarga"],["139","Raichur","raichur"],["140","Bidar","bidar"],["141","Koppal","koppal"],["142","Bellary","bellary"],["143","Haveri","haveri"],["144","Uttara Kannad","uttarkannad"],["145","Davangere","devangere"],["146","Shimoga","shimoga"],["147","Udupi","udupi"],["148","Chikmagalur","chikmagalur"],["149","Hassan","hassan"],["150","Dakshina Kannad","dakshina-kannad"],["151","Chitradurga","chitradurga"],["152","Tumkur","tumkur"],["153","Dharwad","dharwad"],["154","Mandya","mandya"],["155","Mysore","mysore"],["156","Chamrajnagar","chamarajnagar"],["157","Banglore","bangalore-urban"],["158","Bangalore Rural","bangalore-rural"],["159","Chikkaballapur","chikmagalur"],["160","Kodagu","kodagu"],["161","Ramnagar","ramnagar"],["162","Kolar","kolar"]]},{"main":["29","Kerala","kerala"],"districts":[["263","Kasaragode","kasaragod"],["264","Kannur","kannur"],["265","Kozhikode","kozhikode"],["266","Wayanad","wayanad"],["267","Malappuram","malappuram"],["268","Palakkad","palakkad"],["269","Thrissur","thrissur"],["270","Ernakulam","ernakulam"],["271","Idukki","idukki"],["272","Kottayam","kottayam"],["273","Alappuzha","alappuzha"],["274","Pathanamthitta","pattanamthitta"],["275","Kollam","kollam"],["276","Thiruvananthapuram","tiruvandrum"],["290","Bathinda","bhatinda"]]},{"main":["20","Madhya Pradesh","madhya"],"districts":[["310","Sheopur","sheopur"],["311","Morena","morena"],["312","Bhind","bhind"],["313","Gwalior","gwalior"],["314","Datia","datia"],["315","Shivpuri","shivpuri"],["316","Guna","guna"],["317","Ashok Nagar","ashok-nagar"],["318","Sagar","sagar"],["319","TikamGarh","tikamgarh"],["320","Chhatarpur","chhatarpur"],["321","Damoh","damoh"],["322","Panna","panna"],["323","Satna","satna"],["324","Rewa","rewa"],["325","Sidhi","siddhi"],["326","Shahdol","shahdol"],["327","Anuppur","annupur"],["328","Umaria","umaria"],["329","Katni","katni"],["330","Jabalpur","jabalpur"],["331","Dindori","dindori"],["332","Mandla","mandla"],["333","Balaghat","balaghat"],["334","Seoni","seoni"],["335","Narasingpur","narsingpur"],["336","Chhindwara","chhindwara"],["337","Betul","betul"],["338","Harda","harda"],["339","Hoshangabad","hoshangabad"],["340","Raisen","raisen"],["341","Vidisha","vidisha"],["342","Bhopal","bhopal"],["343","Sehore","sehore"],["344","Rajgarh","raigarh"],["345","Shajapur","shajapur"],["346","Dewas","dewas"],["347","Khandwa (East NImar)","khandwa"],["348","Burhanpur","burhanpur"],["349","Khargone (West Nimar)","khargaon"],["350","Badwani","badwani"],["351","Jhabua","jhabua"],["352","Dhar","dhar"],["353","Indore","indore"],["354","Ujjain","ujjain"],["355","Ratlam","ratlam"],["356","Mandsour","mandsaur"],["357","Neemuch","neemuch"]]},{"main":["23","Maharashtra","maharashtra"],"districts":[["75","Nandurbar","nandurbar"],["76","Dhule","dhule"],["77","Nashik","nasik"],["78","Jalgaon","jalgaon"],["79","Buldhana","buldhana"],["80","Akola","akola"],["81","Washim","washim"],["82","Amravati","amravati"],["83","Wardha","wardha"],["84","Nagpur","nagpur"],["85","Bhandara","bhandara"],["86","Gondia","gondia"],["87","Gadchiroli","gadchiroli"],["88","Chandrapur","chandrapur"],["89","Yavatmal","yeotmal"],["90","Nanded","nanded"],["91","Parbhani","parbhani"],["92","Jalna","jalna"],["93","Aurangabad","aurangabad"],["94","Thane","thane"],["95","Mumbai Subarban","mumbai subarban"],["96","Mumbai City","mumbai"],["97","Raigarh","raigarh-mh"],["98","Ratnagiri","ratnagiri"],["99","Pune","pune"],["100","Ahmadnagar","ahmednagar"],["101","Bid","bid"],["102","Latur","latur"],["103","Osmanabad","osmanabad"],["104","Solapur","sholapur"],["105","Satara","satara"],["106","Sangli","sangli"],["107","Sindhudurg","sindhudurg"],["108","Kolhapur","kolhapur"]]},{"main":["16","Manipur","manipur"],"districts":null},{"main":["30","Meghalaya","meghalaya"],"districts":null},{"main":["17","Mizoram","mizoram"],"districts":null},{"main":["15","Nagaland","nagaland"],"districts":null},{"main":["22","Orissa","orissa"],"districts":[["358","Baragarh","baragarh"],["359","Jharsuguda","jharsuguda"],["360","Sundargarh","sundergarh"],["361","Sambalpur","sambalpur"],["362","Deogarh","deogarh"],["363","Keonjhar","kendujhargarh"],["364","Mayurbhanj","mayurbhanj"],["365","Balasore","balasore"],["366","Bhadrak","bhadrak"],["367","Jajpur","jajpur"],["368","Dhenkanal","dhenkanal"],["369","Angul","angul"],["370","Subarnapur","sambalpur"],["371","Bolangir","balagir"],["372","Nuapada","nuaparha"],["373","Nabarangpur","nabarangpur"],["374","Kalahandi","kalahandi"],["375","Kandhmal","phulbani"],["376","Boudh","bauda"],["377","Cuttack","cuttack"],["378","Kendrapara","kendrapara"],["379","JagatsinghPur","jagatsingpur"],["380","Puri","puri"],["381","Khurda","khordha"],["382","Nayagarh","nayagarh"],["383","Ganjam","ganjam"],["384","Gajapati","gajapati"],["385","Rayagada","rayagada"],["386","Koraput","koraput"],["387","Malkangiri","malkangiri"]]},{"main":["4","Punjab","punjab"],"districts":[["277","Gurdaspur","gurdaspur"],["278","Amritsar","amritsar"],["279","Kapurthala","kapurthala"],["280","Jalandhar","jalandhar"],["281","Hoshiarpur","hoshiarpur"],["282","Nawan Shahr","nawanshahr"],["283","Rupnagar","rupnagar"],["284","Fatehgarh Sahib","fatehgarh-sahib"],["285","Ludhiana","ludhiana"],["286","Moga","moga"],["287","Firozpur","ferozepur"],["288","Muktsar","muktsar"],["289","Faridkot","faridkot"],["291","Mansa","mansa"],["292","Sangrur","sangrur"],["293","Patiala","patiala"]]},{"main":["7","Rajasthan","rajasthan"],"districts":[["413","Ganganagar","ganganagar"],["414","Hanumangarh","hanumangarh"],["415","Bikaner","bikaner"],["416","Churu","churu"],["417","Jhunjhunu","jhunjhunu"],["418","Sikar","sikar"],["419","Jaipur","jaipur"],["420","Alwar","alwar"],["421","Bharatpur","bharatpur"],["422","Dholpur","dhaulpur"],["423","Karauli","karauli"],["424","Dausa","dausa"],["425","SawaiMadhopur","sawai-madhopur"],["426","Tonk","tonk"],["427","Ajmer","ajmer"],["428","Nagur","nagaur"],["429","Pali","pali"],["430","Jodhpur","jodhpur"],["431","Jaisalmer","jaislamer"],["432","Barmer","barmer"],["433","Jalore","jalore"],["434","Sirohi","sirohi"],["435","Udaipur","udaipur"],["436","Dungarpur","dungarpur"],["437","Banswara","banswara"],["438","Chittorgarh","chittaurgarh"],["439","Rajsamand","rajsamand"],["440","Bhilwara","bhilwara"],["441","Bundi","bundi"],["442","Kota","kota"],["443","Baran","baran"],["498","Jhalawar","jhalawar"]]},{"main":["12","Sikkim","sikkim"],"districts":null},{"main":["28","Tamil Nadu","tamilnadu"],"districts":[["163","Chennai","chennai"],["164","Thiruvallur","tiruvallur"],["165","Kancheepuram","kanchipuram"],["166","Vellore","vellore"],["167","Krishnagiri","krishnagiri"],["168","Dharmapuri","dharmapuri"],["169","Tiruvannamalai","tiruvannamalai"],["170","Viluppuram","villupuram"],["171","Salem","salem"],["172","Namakkal","namakkal"],["173","Erode","erode"],["174","Coimbatore","coimbatore"],["175","Dindigul","dindigul"],["176","Karur","karur"],["177","Tiruchirappalli","trichy"],["178","The Nilgiris","nilgiris"],["179","Pudukkottai","pudukottai"],["180","Perambalur","perambalur"],["181","Cuddalore","cuddalore"],["182","Nagapattinam","nagapattinam"],["183","Thanjavur","thanjavur"],["184","Thiruvarur","tiruvallur"],["185","Sivaganga","sivaganga"],["186","Madurai","madurai"],["187","Theni","theni"],["188","Virudhunagar","virudhunagar"],["189","Tirunelveli","tirunelveli"],["190","Ramanathapuram","ramanathapuram"],["191","Thoothukkudi","tuticorin"],["192","Kanniyakumari","kanyakumari"],["510","Ariyalur","Ariyalur"]]},{"main":["18","Tripura","tripura"],"districts":null},{"main":["8","Uttar Pradesh ","uttar"],"districts":[["193","Saharanpur","saharanpur"],["194","Muzaffar Nagar","muzaffarnagar"],["195","Bijnor","bijnore"],["196","Moradabad","moradabad"],["197","Ramapur","rampur"],["198","Jyotiba Phule Nagar","jyotiba-phule"],["199","Meerut","meerut"],["200","Baghpat","baghpat"],["201","Ghaziabad","ghaziabad"],["202","Gautam Buddha Nagar","noida"],["203","Bulandshahr","bulandshahr"],["204","Aligarh","aligarh"],["205","Mahamaya Nagar","hathras"],["206","Mathura","mathura"],["207","Agra","agra"],["208","Firozabad","firozabad"],["209","Etah","etah"],["210","Mainpuri","mainpuri"],["211","Badaun","badayun"],["212","Bareilly","bareilly"],["213","Pilibhit","pillibhit"],["214","Shahjahanpur","shahjahanpur"],["215","Kehri","lakhimpur"],["216","Sitapur","sitapur"],["217","Harodi","hardoi"],["218","Unnao","unnao"],["219","Lucknow","lucknow"],["220","Rae Bareli","raebareli"],["221","Sultanpur","sultanur"],["222","Farrukhabad","farrukhabad"],["223","Kannauj","kannauj"],["224","Etawah","etawah"],["225","Auraiya","auraiya"],["226","Kanpur","kanpur-deh"],["227","Kanpur Nagar","kanpur-city"],["228","Jalaun","jalaun"],["229","Jhansi","jhansi"],["230","Lalitpur","lalitpur"],["231","Hamirpur","hamirpur"],["232","Mahoba","mahoba"],["233","Banda","banda"],["234","Chitrakoot","chitrakut"],["235","Fatehpur","fatehpur"],["236","Pratapgarh","pratapgarh"],["237","Kaushambi","kaushambhi"],["238","Allahabad","allahabad"],["239","Barabanki","barabanki"],["240","Fizabad","faizabad"],["241","Ambedkar Nagar","ambedkar-ngr"],["242","Bahraich","bahraich"],["243","Shrawasti","shravasti-nagar"],["244","Balrampur","balrampur"],["245","Gonda","gonda"],["246","Siddharthnagar","sidharth-nagar"],["247","Basti","basti"],["248","Saint Kabir Nagar","sant-kabir-nagar"],["249","Maharajganj","maharajganj"],["250","Gorakhpur","gorakhpur"],["251","Kushinagar","kushinagar"],["252","Deoria","deoria"],["253","Azamgarh","azamgarh"],["254","Maunath Bhanjan","maunath"],["255","Ballia","ballia"],["256","Jaunpur","jaunpur"],["257","Ghazipur","ghazipur"],["258","Chandauli","chandauli"],["259","Varanasi","varanasi"],["260","Sant Ravidas Nagar","santravinagar"],["261","Mirzapur","mirzapur"],["262","Sonbhadra","sonbhadra"]]},{"main":["5","Uttarakhand","uttarakhand"],"districts":[["400","Uttar Kashi","uttarkashi"],["401","Chamoli","chamoli"],["402","Rudryaprayag","rudraprayag"],["403","Tehri Garhwal","tehri-garhwal"],["404","Dehradun","dehradun"],["405","Haridwar","haridwar"],["406","Garhwal","pauri"],["407","Pithoragarh","pithoragarh"],["408","Bageshwar","bageshwar"],["409","Almora","almora"],["410","Champawat","champawat"],["411","Nainital","nainital"],["412","Udamsingh Nagar","udhamsingh-ngr"]]},{"main":["11","West Bengal","westbengal"],"districts":[["294","Cooch Behar","koch-behar"],["295","Jalpaiguri","jalpaiguri"],["296","Darjeeling","darjeeling"],["297","Uttar Dinajpur","north-dinajpur"],["298","Dakshin Dinajpur","dakshan-dinajpur"],["299","Maldaha","maldah"],["300","Murshidabad","murshidabad"],["301","Nadia","nadia"],["302","24 Parganas","north-24-pargans"],["303","South 24 Parganas","south-24-pargana"],["304","Howrah","howrah"],["305","Hooghly","hugli"],["306","Purulia","purulia"],["307","Bankura","bankura"],["308","Bardhaman","burdwan"],["309","Birbhum","birbhum"]]}];
        $scope.totalAds = recentPosts;
        $scope.totalActualAds = $scope.totalAds;
        $scope.type = 'ads';
        $scope.sortingOrder = 'date';
        $scope.itemsPerPage = 100;
        $scope.adsCurrentPage = 1;
        $scope.smsAdsCurrentPage = 1;
        $scope.currentPage = 1;
        $scope.lowerLimit = 1;
        $scope.isPrevious = false;
        $scope.pages = Math.round($scope.totalAds.length / $scope.itemsPerPage );
        if($scope.pages > 10){
        	$scope.isNext = true;
        }else{
        	$scope.isNext = false;
        }
        passAds = [];
        passParam = [];
        $scope.range =  [];        
        $scope.checkMode = [];
        ischeckMode = false;
        $scope.checkPostingType = [];
        ischeckPostingType = false;
        $scope.checkDistricts = [];
        ischeckDistricts = false;
        $scope.checkItems = [];
        ischeckItems = false;
        $scope.checkAssemblies = [];
        ischeckAssemblies = false;
        
        $scope.updateCheckCondition = function(id, check, status){
            id = id.toString();
            var index = $scope[check].indexOf(id);
            if(status){
                if(index < 0){
                    $scope[check].push(id);
                }
            }else {
                if(index > -1){
                    $scope[check].splice(index, 1);
                }
            }
            switch(check){
                case 'checkMode':
            	    if(ischeckMode){
            	    	passAds = $scope.totalActualAds;
            	    }else{
            	    	passAds = $scope.totalAds;
            	    	ischeckMode=true;
            	    }
        	        break;
                case 'checkPostingType':
                	if(ischeckPostingType){
            	    	passAds = $scope.totalActualAds;
            	    }else{
            	    	passAds = $scope.totalAds;
            	    	ischeckPostingType=true;
            	    }
                	break;
                case 'checkItems':
                	if(ischeckItems){
            	    	passAds = $scope.totalActualAds;
            	    }else{
            	    	passAds = $scope.totalAds;
            	    	ischeckItems=true;
            	    }
                	break;
                case 'checkDistricts':
                	if(ischeckDistricts){
            	    	passAds = $scope.totalActualAds;
            	    }else{
            	    	passAds = $scope.totalAds;
            	    	ischeckDistricts=true;
            	    }
                	break;
                case 'checkAssemblies':
                	if(ischeckAssemblies){
            	    	passAds = $scope.totalActualAds;
            	    }else{
            	    	passAds = $scope.totalAds;
            	    	ischeckAssemblies=true;
            	    }
                	break;
            }
            if(!angular.isUndefined($scope[check]) && $scope[check].length==0){
            	passAds = $scope.totalActualAds;
            }
            passParam[0] = [$scope.checkMode, 'sellingType'];
            passParam[1] = [$scope.checkPostingType,'postingby'];
            passParam[2] = [$scope.checkItems, 'cropid'];
            passParam[3] = [$scope.checkDistricts, 'districtid'];
            passParam[4] = [$scope.checkAssemblies, 'assemblyid'];
           	$scope.totalAds = checkFilter(passAds, passParam);
            
            $scope.Sorting(1);
        };
  
    /*    
	$scope.filterAdsType = function(type) {
            switch(type){
                case 'sms':
                	$scope.adsCurrentPage = $scope.currentPage;
                	$scope.currentPage = $scope.smsAdsCurrentPage;
                    $scope.type = undefined;
                    $scope.totalAds = recentSMSPosts;
                    break;
                case 'ads':
                	$scope.smsAdsCurrentPage = $scope.currentPage;
                	$scope.currentPage = $scope.adsCurrentPage;
                    $scope.type = 'ads';
                    $scope.totalAds = recentPosts;
                    break;
                case 'all':
                    $scope.type = 'all';
                    $scope.totalAds = recentPosts.concat(recentSMSPosts);
                    break;
            }
            $scope.Sorting($scope.currentPage);
    };
    */
	$scope.checkstate = function(districtId, mode, districtModel) {
	    var chk_arr =  document.getElementsByName("state_checkbox");
	    var chklength = chk_arr.length;             
	    var result = new Array();
	    count =0;
	    for(k=0;k< chklength;k++)
	    {
                chk_arr[k].checked;
                if(chk_arr[k].checked==true)
                {
                    var cid = chk_arr[k].value;
                    count++;
                    result.push(cid);
                }
                result.join(',');
	    } 
            if(count==1)
                    cvalue = "0," + result;
            else
                    cvalue =  result;
            $http.get("getAjaxRequestedData.php?mode=assemblies&id="+cvalue+'')
						.success(function(response) {
            $scope.districts = response[0].districts;
	        $scope.constituencies = response[1].assemblies;
	});
        if(districtModel==true){
            $scope.statescheck = districtModel;
        }
        else
        {
            $scope.statescheck = undefined;
            $scope.constituencies = undefined;
        }
        if(districtId){
            $scope.updateCheckCondition(districtId, mode, districtModel);
        }
    };
    
    $scope.Sorting = function(currentPage){
        $scope.pages = Math.ceil($scope.totalAds.length / $scope.itemsPerPage );
        $scope.pages= ($scope.pages==0)?1:$scope.pages;
        $scope.currentPage = (currentPage)?currentPage:$scope.currentPage;
        $scope.range = [];
        
        if(currentPage-5 > 1 ){
        	$scope.lowerLimit = currentPage-5;
        	$scope.isPrevious = true;
        }else{
        	$scope.lowerLimit = 1;
        	$scope.isPrevious = false;
        }
        
        if($scope.lowerLimit == 1 && $scope.pages >=10){
        	upperlimit = 10;
        }else if(currentPage+5 >=$scope.pages){
	        upperlimit = $scope.pages;
	        isNext = false;
        }else{
        	upperlimit = currentPage+5 ;
        	isNext = true;
        }
                
        for(var i=$scope.lowerLimit;i<=upperlimit;i++){
            $scope.range.push(i);
        }
        $scope.startLimits = (currentPage - 1) * $scope.itemsPerPage;
    };       
    $scope.Sorting(1);
});

globalModuleApp.filter('searchFor', [function(){
    return function(districts, filterParam){
        if(!filterParam){
            return districts;
        }else if(typeof(filterParam) == 'string'){
            searchString = filterParam;
            var result = [];
            searchString = searchString.toLowerCase();
            angular.forEach(districts, function(item){
                if(item.toLowerCase().indexOf(searchString) !== -1){
                    result.push(item);
                }
            });
        } else {
            if(!filterParam[0]){
                return districts;
            }
            var tmpAssemblies = [];
            var result = [];
            searchString = filterParam[0].toLowerCase();
            angular.forEach(districts, function (totalAd) {
                tmpAssemblies = [];
                angular.forEach(totalAd[filterParam[1]], function (newArr) {
                    if (newArr[filterParam[2]].toLowerCase().indexOf(searchString) !== -1) {
                        tmpAssemblies.push(newArr);
                    }
                });
                if(tmpAssemblies.length >0){
                    totalAd[filterParam[1]] = tmpAssemblies;
                    result.push(totalAd);
                }
            });
        }
        return result;
    };
}]);