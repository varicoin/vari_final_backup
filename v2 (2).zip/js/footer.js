
function getFooterInfo(elem, indx, list) {
    var container = document.getElementById("footer");
    if(elem.image!=null) {
        var footer = '<div class="listBlock"> <a href="'+elem.href+'"><img src="images/hm-icons/'+elem.image+'.png"></a> <span><a href="'+elem.href+'">'+elem.label+'</a></span><div class="patentpending"> </div>';
    }else {
        var footer = '<div class="copyright">'+elem.copyright+'<a href="'+elem.href+'">'+elem.href+'</a>. '+elem.label+'</div><span>Patent Pending* (2422/CHE/2013)</span>';
    }
    container.innerHTML = container.innerHTML + footer;
}

$(document).ready(function(){
   _.each(footer, getFooterInfo);
});