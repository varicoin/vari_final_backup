$( "#tabs" ).tabs();
globalModuleApp.controller('layoutController', function($scope, $rootScope){
	
    $scope.layoutCategories = [
        {'image':'cropIco', 'label':'Crops', 'href':'categorySections.php?section=Crops&categoryid=1d7ad6df', 'count':postsCount[1]['count'], 'smsCount':postsCount[1]['smsCount']},
        {'image':'flowerIco', 'label':'Flowers & Nursery', 'href':'categorySections.php?section=Flowers & Nursery&categoryid=901bc8d1', 'count':postsCount[369]['count'], 'smsCount':postsCount[369]['smsCount']},
        {'image':'liveStockIco', 'label':'Live STOCK & Products', 'href':'categorySections.php?section=Animal Products&categoryid=4c810fe5', 'count':postsCount[3]['count'], 'smsCount':postsCount[3]['smsCount']},
        {'image':'vegetableIco', 'label':'Vegetables', 'href':'categorySections.php?section=Vegetables&categoryid=df70008c', 'count':postsCount[360]['count'], 'smsCount':postsCount[360]['smsCount']},
        {'image':'medicineIco', 'label':'Medicinal Plants', 'href':'categorySections.php?section=Medicinal Plants&categoryid=88c2a98e', 'count':postsCount[345]['count'], 'smsCount':postsCount[345]['smsCount']},
        {'image':'fruitIco', 'label':'Fruits', 'href':'categorySections.php?section=Fruits&categoryid=c13297fb', 'count':postsCount[2]['count'], 'smsCount':postsCount[2]['smsCount']},
        {'image':'productIco', 'label':'Products', 'href':'categorySections.php?section=Products&categoryid=1ff10f8e', 'count':postsCount[6]['count'], 'smsCount':postsCount[6]['smsCount']},
        {'image':'manureIco', 'label':'Manure & Waste', 'href':'categorySections.php?section=Manure & Waste&categoryid=9d5ff573', 'count':postsCount[4]['count'], 'smsCount':postsCount[4]['smsCount']},
        {'image':'machineIco', 'label':'Machines', 'href':'categorySections.php?section=Machines&categoryid=554a9436', 'count':postsCount[319]['count'], 'smsCount':postsCount[319]['smsCount']},
        {'image':'organicIco', 'label':'Organic & Natural', 'href':'categorySections.php?section=Organic & Natural&categoryid=867549f5', 'count':postsCount[303]['count'], 'smsCount':postsCount[303]['smsCount']},
    ];

});