$( "#tabs" ).tabs();
function getFooterInfo(elem, indx, list) {
    var container = document.getElementById("footer");
    if(elem.image!=null){
        var footer = '<div class="listBlock"> <a href="'+elem.href+'"><img src="prod_new/images/'+elem.image+'.png"></a> <span><a href="'+elem.href+'">'+elem.label+'</a></span> </div>';
    }else{
        var footer = '<div class="copyright">'+elem.copyright+'<a href="'+elem.href+'">'+elem.href+'</a>. '+elem.label+'</div>';
    }
    container.innerHTML = container.innerHTML + footer;
}
function getSMSAdvertismentBlock(elem, indx, list) {
    var container = document.getElementById('smsAdsSection');
	var htmlContent = '<div class="listBlock2"><div class="thumbImg"><img src="prod_new/images/'+elem.image+'"></div><div class="rBlock"><div class="td1"><div class="greenButton2"><a href="#"><span>'+elem.mode+'</span></a></div><div class="title">'+elem.title+'</div><div class="cl"></div></div><div class="td2"><div class="breadcrumb"><a href="'+elem.href+'">'+elem.category+'</a> <a href="#">'+elem.district+'</a> '+elem.state+' </div><div class="priceBox"> <div class="minimumPrice"> Minimum price<span><span class="black">&#8377;</span> '+elem.minPrice+'</span> </div><div class="maximumPrice"> Maximum price<span><span class="black">&#8377;</span> '+elem.maxPrice+'</span></div></div></div></div><div class="cl"></div></div>';
	container.innerHTML += htmlContent;
}
function getAdvertismentBlock(elem, indx, list) {
    var container = document.getElementById('adsSection');
	var htmlContent = '<div class="listBlock"><div class="thumbImg"><img src="prod_new/images/'+elem.image+'"></div><div class="rBlock"><div class="tr1"><div class="title">'+elem.title+'</div><div class="breadcrumb"><a href="#">'+elem.category+'</a> <a href="#">'+elem.assembly+'</a> <a href="#">'+elem.district+'</a> '+elem.state+' </div><div class="cl"></div></div><div class="greyButton"><a href="#"><span>'+elem.postedby+'</span></a></div><div class="greenButton"><a href="#"><span>'+elem.mode+'</span></a></div><div class="priceBox"><div class="minimumPrice"> Minimum price<span><span class="black">&#8377;</span> '+elem.minPrice+'</span> </div><div class="maximumPrice"> Maximum price<span><span class="black">&#8377;</span> '+elem.maxPrice+'</span> </div></div><div class="greyButton2"><a href="#"><span>per '+elem.quantity+'</span></a></div></div><div class="cl"></div></div>';
	container.innerHTML += htmlContent;
}

$(document).ready(function(){
   _.each(footer, getFooterInfo);
   _.each(smsAds, getSMSAdvertismentBlock);
   _.each(ads, getAdvertismentBlock);
   $("#activity").on("click", function(e){
        alert('1');
        e.preventDefault();
        $("body, html").animate({ 
            scrollTop: $( $(this).attr('href') ).offset().top 
        }, 600);
    });
});