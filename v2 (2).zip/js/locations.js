globalModuleApp.controller('locationController', function($scope, $rootScope){
    $scope.quantityTypes = ['', 'Each', 'PER KG', 'PER Quintal', 'Per Ton', 'Per Litre', 'Others'];
    $scope.postingbyTypes = $rootScope.postingbyTypes;
    $scope.sellingTypes = ['SELLING', 'BUYING', 'Closed'];
    $scope.totalAds = recentPosts;
	$scope.categories = $rootScope.categories;
    $scope.BackupItems = $rootScope.BackupItems;
	$scope.items = [];
    $scope.states = states[0];
	$scope.districts= districts;
    $scope.sortingOrder = 'subject';
    $scope.itemsPerPage = 100;
    $scope.adsCurrentPage = 1;
    $scope.currentPage = 1;
    $scope.pages = Math.round($scope.totalAds.length / $scope.itemsPerPage );
    
    $scope.range =  [];
    $scope.smsRange = [];
    $scope.checkMode = [];
    $scope.checkPostingType = [];
    $scope.checkSubCategories = [];
    $scope.checkItems = [];
    $scope.checkAssemblies = [];
    
    $scope.updateCheckCondition = function(id, check, status){
        id = id.toString();
        var index = $scope[check].indexOf(id);
        if(status){
            if(index < 0){
                $scope[check].push(id);
            }
        }else {
            if(index > -1){
                $scope[check].splice(index, 1);
            }
        }          
    };
    
    $scope.updateSubCategories = function(id, itemName, status){
        var index = $scope.checkSubCategories.indexOf(id);
        if(status){
            if(index < 0){
                $scope.checkSubCategories.push(id);
                $scope.items.push({
                    'subcategory':itemName,
                    'items':$scope.BackupItems[id]
                });
            }
        }else {
            if(index > -1){
                $scope.checkSubCategories.splice(index, 1);
            }
        }          
    };
   /* $scope.filterAdsType = function(type){
        switch(type){
            case 'sms':
            	$scope.adsCurrentPage = $scope.currentPage;
            	$scope.currentPage = $scope.smsAdsCurrentPage;
                $scope.totalAds = recentSMSPosts;
                break;
            case 'ads':
            	$scope.smsAdsCurrentPage = $scope.currentPage;
            	$scope.currentPage = $scope.adsCurrentPage;
                $scope.totalAds = recentPosts;
                break;
            case 'all':
                $scope.totalAds = recentPosts.concat(recentSMSPosts);
                break;
        }
        $scope.Sorting($scope.currentPage);
    };*/
    $scope.Sorting = function(currentPage){
        $scope.pages = Math.round($scope.totalAds.length / $scope.itemsPerPage );
        $scope.currentPage = (currentPage)?currentPage:$scope.currentPage;
        $scope.range = [];
        

        if(currentPage-5 > 1 ){
        	$scope.lowerLimit = currentPage-5;
        }else{
        	$scope.lowerLimit = 1;
        }
        
        if($scope.lowerLimit == 1 && $scope.pages<=10){
        	upperlimit = 10;
        }else if(currentPage+5 >=$scope.pages){
	        upperlimit = $scope.pages;
        }else{
        	upperlimit = currentPage+5 ;
        }
                
        for(var i=$scope.lowerLimit;i<=upperlimit;i++){
            $scope.range.push(i);
        }
        
        $scope.startLimits = (currentPage - 1) * $scope.itemsPerPage;
    };       
    $scope.Sorting(1);
    $scope.watch('checkFilter', function(){
        $scope.Sorting();
    });
});

globalModuleApp.filter('checkFilter', [function(){
    return function(totalAds, filterParam){
        condtion = filterParam[0];
        key = filterParam[1];
        if (!angular.isUndefined(totalAds) && !angular.isUndefined(condtion) && condtion.length > 0) {
            var tmpRecords =[];
            angular.forEach(condtion, function (id) {
                angular.forEach(totalAds, function (totalAd) {
                    if (angular.equals(totalAd[key], id)) {
                        tmpRecords.push(totalAd);
                    }
                });
            });
            return tmpRecords;
        }else{
            return totalAds;
        }
    }
}]);

globalModuleApp.filter('searchFor', [function(){
    return function(districts, filterParam){
        if(!filterParam){
            return districts;
        }else if(typeof(filterParam) == 'string'){
            searchString = filterParam;
            var result = [];
            searchString = searchString.toLowerCase();
            angular.forEach(districts, function(item){
                if(item.toLowerCase().indexOf(searchString) !== -1){
                    result.push(item);
                }
            });
        } else {
            if(!filterParam[0]){
                return districts;
            }
            var tmpAssemblies = [];
            var result = [];
            searchString = filterParam[0].toLowerCase();
            angular.forEach(districts, function (totalAd) {
                tmpAssemblies = [];
                angular.forEach(totalAd[filterParam[1]], function (newArr) {
                    if (newArr[filterParam[2]].toLowerCase().indexOf(searchString) !== -1) {
                        tmpAssemblies.push(newArr);
                    }
                });
                if(tmpAssemblies.length >0){
                    totalAd[filterParam[1]] = tmpAssemblies;
                    result.push(totalAd);
                }
            });
        }
        return result;
    };
}]);