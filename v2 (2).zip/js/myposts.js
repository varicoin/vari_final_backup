$(".flexme1").flexigrid({
	url: 'livefeed.php?mode=myposts',
	dataType : 'json',
	colModel : [ {
		display : 'Post Id',
		name : 'id',
		width : 100,
		sortable : true,
		align : 'center'
	}, {
		display : 'Subject',
		name : 'subject',
		width : 300,
		sortable : true,
		align : 'left'
	}, {
		display : 'Category',
		name : 'category',
		width : 150,
		sortable : true,
		align : 'left'
	}, {
		display : 'Constituency',
		name : 'assembly',
		width : 150,
		sortable : true,
		align : 'left'
	}, {
		display : 'District',
		name : 'district',
		width : 120,
		sortable : true,
		align : 'left'
	}, {
		display : 'State',
		name : 'state',
		width : 120,
		sortable : true,
		align : 'left'
	}, {
		display : 'Type',
		name : 'type',
		width : 120,
		sortable : true,
		align : 'left'
	}, {
		display : 'Posted On',
		name : 'postedon',
		width : 100,
		sortable : true,
		align : 'left'
	}, {
		display : 'Action',
		name : 'action',
		width : 100,
		sortable : true,
		align : 'left'
	} ],

	usepager: true,
	useRp: true,
	rp: 17,
	showTableToggleBtn: false,
	resizable: false,
	width: 700,
	height: 370

});
