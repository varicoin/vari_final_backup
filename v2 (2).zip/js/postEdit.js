globalModuleApp.controller('postEditController', function($scope){
	$scope.post = post;
	$scope.images = images;
	$scope.hidrem = '';
	var range = [];
	if(images!=null){
		$scope.imagesLength = images.length;
		$scope.imageUploadLength = 3 - (images.length);
	}else{
		$scope.imageUploadLength = 3;
	}
	
	if($scope.imageUploadLength > 0){
		for(var i=0;i<$scope.imageUploadLength;i++) {
		  range.push(i);
		}
		$scope.range = range;
	}
	var inc = 0;
	$scope.removeimagesid = function(index){
		var r=confirm("Do you want to delete image.");
		if (r==true)
		{
			range.push(inc);
			$scope.range = range;
			$scope.hidrem += images[index].id + ', ';
			inc++;
		}
		else
		{
		  //do nothing
		}
	
	
	}
});