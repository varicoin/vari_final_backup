globalModuleApp.controller('postController', function($scope, $http, $interval){
	    $scope.post = postDetails[0];
		var a = location.href; 
	    var b = a.substring(a.indexOf("=")+1);
	    if(angular.isObject($scope.post.images)){
			 var img_loc = $scope.post.images[0]['location']; 
			 var imgData = img_loc.substring(img_loc.indexOf("_")+1);
			 if(imgData)
			 {
				 $scope.appImg = 1;
				
			 }
			 else
			 {
				$scope.appImg = 0;
			
			 }
			
			
			
	    	$scope.slideshow=true;
	    	$scope.imgLength = $scope.post.images.length;
	    	$scope.imageindex=0;
		    $interval(function(){
	            if($scope.imageindex < $scope.imgLength-1){
	            	$scope.imageindex++;
	            }else{
	                $scope.imageindex = 0;
	            }
		    }, 5000);
	    }else{
	    	$scope.slideshow=false;
	    }
        $scope.Mobilesalt = salt;
        $scope.adReplySalt = Math.random().toString(36).substr(2)+Math.random().toString(36).substr(2);
        $scope.captcha = null;
        $scope.isCaptchaEnable = true;
        $scope.mobileNumber = null;
        $scope.postingBy = ['Farmer', 'Individual', 'Agent','Co operative', 'Company'];
        $scope.postingBy[-1] = 'Others';
        $scope.quantityTypes = ["","Each","Kilograms","Quintal","Tons","Litre","Others"];
        $scope.mode = ['Selling', 'Buying', 'Closed'];
        
        $scope.getNumber = function() {
		
		if($scope.captcha==null){
            window.alert("Security code shouldn't be empty");
            $("input[name=securitycode]").focus();
            return false;			
		}else if($scope.captcha.length!=4){
            window.alert("Security code should of length 4 characters");
            $("input[name=securitycode]").focus();
            return false;
        }
		
		
		
        var sendObj = {
            method: 'POST',
            url: 'getAjaxRequestedData.php',
            data: {
                security_id:$scope.Mobilesalt,
                mode:"mobile",
                postType:'ads',
                id: $scope.post.postid, 
                captcha:$scope.captcha
            },
            headers: {'Content-Type': 'application/x-www-form-urlencoded'}
        };
		$http(sendObj).then(function(response){

            data = response.data;
            if(data.error){
              $scope.Mobilesalt = data.captcha;
              $scope.captcha = null;
              $scope.msgError=data.msg
            }else{
              $scope.isCaptchaEnable = false;
              $scope.mobileNumber = data.msg;
              $scope.msgError=null;
            }
        });
    };
    
    $scope.replySubmit = function(){
    	$scope.errors=[];
    	$scope.reply.salt = $scope.adReplySalt;
    	$scope.reply.postid = $scope.post.postid;
    	$scope.reply.type = 'Ad';
        var req = {
            method: 'POST',
            url: 'reply.php?',
            data:$scope.reply,
            headers: {'Content-Type': 'application/x-www-form-urlencoded'}
        };
        $http(req).then(function(response) {
        	data = response.data;
        	if(data.error){
                
            }else {
            	$scope.reply = []; 
            }
        	$scope.adReplySalt = Math.random().toString(36).substr(2)+Math.random().toString(36).substr(2);
            $scope.errors = data.error_message;
            
        }, function(response) {
          $scope.data = response.status || "Request failed";
      });
    };
	$scope.changeCaptcha = function(){
		$scope.adReplySalt = Math.random().toString(36).substr(2)+Math.random().toString(36).substr(2);
	};
    
    
});