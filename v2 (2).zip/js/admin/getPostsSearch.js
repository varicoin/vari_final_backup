$("#getPosts").click(function(){
    var numbers = $("#mobile_numbers").val();
    $.post('admin/manage.php?mode=searchPosts',{
        numbers:numbers
    }, function(data, status){
        if(data.isSuccess){
            $(".flexme5").flexAddData(data.records);
        }
    }, 'json');
});
$(".flexme5").flexigrid({
	dataType : 'json',
	colModel : [ {
		display : 'Post Id',
		name : 'id',
		width : 50,
		sortable : true,
		align : 'center'
	}, {
		display : 'Subject',
		name : 'title',
		width : 150,
		sortable : true,
		align : 'left'
	}, {
		display : 'Crop',
		name : 'item',
		width : 150,
		sortable : true,
		align : 'left'
	}, {
		display : 'State',
		name : 'state',
		width : 50,
		sortable : true,
		align : 'left'
	}, {
		display : 'District',
		name : 'district',
		width : 50,
		sortable : true,
		align : 'left',
	}, {
		display : 'Assembly',
		name : 'assembly',
		width : 100,
		sortable : true,
		align : 'left',
	}, {
		display : 'Mode',
		name : 'mode',
		width : 100,
		sortable : true,
		align : 'left',
	}, {
		display : 'Mobile',
		name : 'mobile',
		width : 100,
		sortable : true,
		align : 'left',
	}, {
		display : 'Min. Price',
		name : 'minPrice',
		width : 120,
		sortable : true,
		align : 'left',
	}, {
		display : 'Price',
		name : 'price',
		width : 120,
		sortable : true,
		align : 'left',
	} , {
		display : 'Quantity',
		name : 'quantity',
		width : 120,
		sortable : true,
		align : 'left',
	} , {
		display : 'Posting By',
		name : 'postedby',
		width : 120,
		sortable : true,
		align : 'left',
	} ],
	usepager: true,
	useRp: true,
	rp: 34,
	showTableToggleBtn: false,
	resizable: false,
	width: 700,
	height: 370
});