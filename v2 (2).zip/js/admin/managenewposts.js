function accept(){}
function reject(){}
$(".flexme2").flexigrid({
	url: 'admin/manage.php?mode=classifiedads',
	dataType : 'json',
	colModel : [ {
		display : 'Post Id',
		name : 'postid',
		width : 50,
		sortable : true,
		align : 'center'
	}, {
		display : 'Subject',
		name : 'subject',
		width : 150,
		sortable : true,
		align : 'left'
	}, {
		display : 'Message',
		name : 'message',
		width : 250,
		sortable : true,
		align : 'left'
	}, {
		display : 'To Mail',
		name : 'tomails',
		width : 50,
		sortable : true,
		align : 'left',
	}, {
		display : 'CC Mail',
		name : 'ccmails',
		width : 100,
		sortable : true,
		align : 'left',
	}, {
		display : 'Type',
		name : 'type',
		width : 100,
		sortable : true,
		align : 'left',
	}, {
		display : 'Posted on',
		name : 'postedon',
		width : 100,
		sortable : true,
		align : 'left',
	}, {
		display : 'Action',
		name : 'action',
		width : 120,
		sortable : true,
		align : 'left',
	}],
        buttons : [
                {name: 'Accept', bclass: 'edit', onpress : accept},
                {name: 'Reject', bclass: 'delete', onpress : reject},
                {separator: true}
        ],

	usepager: true,
	useRp: true,
	rp: 17,
	showTableToggleBtn: false,
	resizable: false,
	width: 700,
	height: 370
});