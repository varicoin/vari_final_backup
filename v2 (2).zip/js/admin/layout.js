$( "#tabs" ).tabs();
globalModuleApp.controller('adminController', function($scope, $http, $rootScope){
	$scope.classifiedPostsList = classifiedPostsList;
	$scope.smsPostsList = smsPostsList;
	console.log($scope.smsPostsList);
	$scope.repliesList = repliesList;
	$scope.smsRepliesList = smsRepliesList;
	$scope.Accept = function(mailid,postid,mode){
		var ccmails = angular.element('.ccmails'+mailid+'').val();
		var ccphones = angular.element('.ccphones'+mailid+'').val();
		var mobileText = angular.element('.mobileText'+mailid+'').val();
		console.log(ccphones);
		$http({
			method:'post',
			url:"Akjdkjdsowrier.php?",
			data:{
				'mode':mode,
				'condition':'Accept',
				'mailid':mailid,
				'ccmails':ccmails,
				'ccphones':ccphones,
				'mobileText':mobileText,
				'postid':postid
			},
		    headers: {'Content-Type': 'application/x-www-form-urlencoded'},
		}).success(function(response) {
			if(!response.error && response.isSent){
				alert('Mails and SMS`s sent successfully');
				angular.element("#rowId"+mailid+'').remove();
			}else if(response.error){
				alert(response.error_message);
			}
		});
		
	};
	$scope.Reject = function(mailid,postid){
		$http({
			method:'post',
			url:"Akjdkjdsowrier.php?",
			data:{
				'mode':'ads',
				'condition':'reject',
				'mailid':mailid,
				'postid':postid
			},
		    headers: {'Content-Type': 'application/x-www-form-urlencoded'},
		}).success(function(response) {
			if(!response.error && response.isSent){
				alert('Rejected successfully');
				angular.element("#rowId"+mailid+'').remove();
			}else if(response.error){
				alert(response.error_message);
			}
		});
	};
	$scope.replyAccept = function(id,postid,mode){
		var ccmail = angular.element('.ccmail'+id+'').val();
		var ccphone = angular.element('.ccphone'+id+'').val();
		var mobileText = angular.element('.replymobileText'+id+'').val();
		$http({
			method:'post',
			url:"replyAkjdkjdsowrier.php?",
			data:{
				'mode':'replies',
				'condition':'Accept',
				'replyid':id,
				'ccmail':ccmail,
				'ccphone':ccphone,
				'mobileText':mobileText,
				'postid':postid
			},
		    headers: {'Content-Type': 'application/x-www-form-urlencoded'},
		}).success(function(response) {
			if(!response.error && response.isSent){
				alert('Reply Mail and SMS sent successfully');
				angular.element("#replyRowId"+id+'').remove();
			}else if(response.error){
				alert(response.error_message);
			}
		});
		
	};
	$scope.replyReject = function(id,postid){
		$http({
			method:'post',
			url:"replyAkjdkjdsowrier.php?",
			data:{
				'mode':'replies',
				'condition':'reject',
				'replyid':id,
				'postid':postid
			},
		    headers: {'Content-Type': 'application/x-www-form-urlencoded'},
		}).success(function(response) {
			if(!response.error && response.isSent){
				alert('Reply Rejected successfully');
				angular.element("#replyRowId"+id+'').remove();
			}else if(response.error){
				alert(response.error_message);
			}
		});
	};
});