function accept(){}
function reject(){}
$(".flexme6").flexigrid({
	url: 'admin/manage.php?mode=managehelp',
	dataType : 'json',
	colModel : [ {
		display : 'Id',
		name : 'id',
		width : 50,
		sortable : true,
		align : 'center'
	}, {
		display : 'Name',
		name : 'name',
		width : 150,
		sortable : true,
		align : 'left'
	}, {
		display : 'Email Id',
		name : 'emailid',
		width : 150,
		sortable : true,
		align : 'left'
	}, {
		display : 'Question',
		name : 'question',
		width : 150,
		sortable : true,
		align : 'left'
	}, {
		display : 'Details',
		name : 'details',
		width : 150,
		sortable : true,
		align : 'left'
	}, {
		display : 'Phone',
		name : 'phone',
		width : 50,
		sortable : true,
		align : 'left',
	}, {
		display : 'Posted on',
		name : 'date',
		width : 50,
		sortable : true,
		align : 'left',
	}, {
		display : 'Action',
		name : 'action',
		width : 60,
		sortable : true,
		align : 'left',
	}],
        buttons : [
                {name: 'Accept', bclass: 'edit', onpress : accept},
                {name: 'Reject', bclass: 'delete', onpress : reject},
                {separator: true}
        ],
	usepager: true,
	useRp: true,
	rp: 17,
	showTableToggleBtn: true,
	resizable: false,
	width: 700,
	height: 370

});
