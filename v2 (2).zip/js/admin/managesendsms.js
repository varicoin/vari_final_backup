function accept(){}
function reject(){}
$(".flexme3").flexigrid({
	url: 'admin/manage.php?mode=sendsms',
	dataType : 'json',
	colModel : [ {
		display : 'Post Id',
		name : 'postid',
		width : 50,
		sortable : true,
		align : 'center'
	}, {
		display : 'Subject',
		name : 'subject',
		width : 100,
		sortable : true,
		align : 'left'
	}, {
		display : 'Message',
		name : 'message',
		width : 50,
		sortable : true,
		align : 'left'
	}, {
		display : 'Crop',
		name : 'cropid',
		width : 50,
		sortable : true,
		align : 'left'
	}, {
		display : 'Posted on',
		name : 'postedon',
		width : 50,
		sortable : true,
		align : 'left',
	}, {
		display : 'Type',
		name : 'type',
		width : 50,
		sortable : true,
		align : 'left',
	}, {
		display : 'Mode',
		name : 'mode',
		width : 50,
		sortable : true,
		align : 'left',
	}],
        buttons : [
                {name: 'Accept', bclass: 'edit', onpress : accept},
                {name: 'Reject', bclass: 'delete', onpress : reject},
                {separator: true}
        ],
	usepager: true,
	useRp: true,
	rp: 17,
	showTableToggleBtn: false,
	resizable: false,
	width: 700,
	height: 370

});
