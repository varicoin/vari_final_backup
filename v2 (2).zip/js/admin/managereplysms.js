function RepliesSubmit(com, grid){
   var idsArr = [];
    $('.trSelected', $(".flexme4")).each(function () {
        idsArr.push($(this).attr('data-id'));
    });
    if(com=='Accept') {
       
        $.post('admin/manage.php?mode=getReplyDetails', {
                   ids:idsArr
            }, function(data, status){
                  if(data.isSuccess){
                    console.log(data.records);
                   $( "#popup1" ).dialog();
                   //$('.trSelected', $(".flexme1")).remove();
                   //window.alert("Selected Replies are been Rejected!!");
                 }else{
                   window.alert("Error: Data retrieval failed!!");
                }
            }, 'json');
    } else if(com=='Reject') {
        if(window.confirm("Are you sure to Reject Selected Replies")){
            $.post('admin/manage.php?mode=rejectReplies', {
                   ids:idsArr
            }, function(data, status){
                  if(data.isSuccess){
                   $('.trSelected', $(".flexme1")).remove();
                   window.alert("Selected Replies are been Rejected!!");
                 }else{
                   window.alert("Error: Rejection functionality failed!!");
                }
            }, 'json');
        }
    }
   
// $('.flexme1').flexAddData({rows:[],page:0,total:0});
}
$(".flexme4").flexigrid({
	url: 'admin/manage.php?mode=managereplymails',
	dataType : 'json',
	colModel : [{
		display : 'Post Id',
		name : 'postid',
		width : 50,
		sortable : true,
		align : 'left'
	}, {
		display : 'Email',
		name : 'email',
		width : 150,
		sortable : true,
		align : 'left'
	}, {
		display : 'Phone',
		name : 'phone_number',
		width : 50,
		sortable : true,
		align : 'left'
	}, {
		display : 'Message',
		name : 'message',
		width : 150,
		sortable : true,
		align : 'left'
	}, {
		display : 'Type',
		name : 'type',
		width : 50,
		sortable : true,
		align : 'left',
	}, {
		display : 'Posted on',
		name : 'postedon',
		width : 100,
		sortable : true,
		align : 'left',
	}, {
		display : 'Action',
		name : 'action',
		width : 150,
		sortable : true,
		align : 'left',
	}, {
		display : 'Replied By',
		name : 'name',
		width : 100,
		sortable : true,
		align : 'left',
	}, {
		display : 'Price',
		name : 'mode_price',
		width : 120,
		sortable : true,
		align : 'left',
	} , {
		display : 'Min. Price ',
		name : 'mode_minprice',
		width : 120,
		sortable : true,
		align : 'left',
	}, {
		display : 'Quantity ',
		name : 'mode_quantity',
		width : 120,
		sortable : true,
		align : 'left',
	}, {
		display : 'To Name',
		name : 'to_name',
		width : 70,
		sortable : true,
		align : 'left',
	}, {
		display : 'To mail',
		name : 'to_email',
		width : 120,
		sortable : true,
		align : 'left',
	}, {
		display : 'Location',
		name : 'location',
		width : 70,
		sortable : true,
		align : 'left',
	}],
        buttons : [
                {name: 'Accept', bclass: 'edit', onpress : RepliesSubmit},
                {name: 'Reject', bclass: 'delete', onpress : RepliesSubmit},
                {separator: true}
        ],
	usepager: true,
	useRp: true,
	rp: 34,
	showTableToggleBtn: true,
	resizable: false,
	width: 700,
	height: 370

});