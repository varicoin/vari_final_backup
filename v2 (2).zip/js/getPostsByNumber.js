$(".flexme3").flexigrid({
	dataType : 'json',
	colModel : [ {
		display : 'Post Id',
		name : 'id',
		width : 50,
		sortable : true,
		align : 'center'
	}, {
		display : 'Post',
		name : 'post',
		width : 150,
		sortable : true,
		align : 'left'
	}, {
		display : 'Assembly',
		name : 'assembly',
		width : 150,
		sortable : true,
		align : 'left'
	}, {
		display : 'District',
		name : 'district',
		width : 150,
		sortable : true,
		align : 'left'
	}, {
		display : 'Crop',
		name : 'crop',
		width : 50,
		sortable : true,
		align : 'left'
	}, {
		display : 'Type',
		name : 'type',
		width : 50,
		sortable : true,
		align : 'left',
	}, {
		display : 'Posted on',
		name : 'postedon',
		width : 100,
		sortable : true,
		align : 'left',
	}, {
		display : 'Posted By',
		name : 'postedby',
		width : 100,
		sortable : true,
		align : 'left',
	}, {
		display : 'Price Mode',
		name : 'Pricemode',
		width : 120,
		sortable : true,
		align : 'left',
	} ],

	usepager: true,
	useRp: true,
	rp: 17,
	showTableToggleBtn: false,
	resizable: false,
	width: 700,
	height: 370

});
