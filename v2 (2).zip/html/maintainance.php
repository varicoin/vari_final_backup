<?php
echo "<h1>Site is under maintaince...Will be back soon</h1>";

?>
