<?php
if ($_GET['randomId'] != "fvOQC0jB_0F1m5E31iZECQb9bdeYr26KaAUAeYmlD07knllAMCgnITDrI60hSzxr") {
    echo "Access Denied";
    exit();
}

// display the HTML code:
echo stripslashes($_POST['wproPreviewHTML']);

?>  
