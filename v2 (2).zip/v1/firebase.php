<?php

//mysql_connect ("dandmudik.ipagemysql.com","varicoinuser","8-&q ICHhW 0*&Z x|4u }_%] b\H1uSer") or die ("unable to connect with the database");
//mysql_select_db ("varicoin_vari",$conn1)or die ("unable to select database");

?>

<script src="https://www.gstatic.com/firebasejs/3.6.3/firebase.js"></script>
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
<script>
  // Initialize Firebase
  var config = {
    apiKey: "AIzaSyAdsyhHa-KUia-idj-iWKYtncjJYF_6sxk",
    authDomain: "varitest-c3b29.firebaseapp.com",
    databaseURL: "https://varitest-c3b29.firebaseio.com",
    storageBucket: "varitest-c3b29.appspot.com",
    messagingSenderId: "247505506063"
  };
  firebase.initializeApp(config);
   var ref = firebase.database().ref("items");
     var arr = "";
	    var today = new Date();
		var yesterday = new Date(new Date().setDate(new Date().getDate()-40));
		var dd = today.getDate();
		var mm = today.getMonth()+1; //January is 0!
		var yyyy = today.getFullYear();
		var yes_dd  = yesterday.getDate();
		var yes_mm  = yesterday.getMonth();
		var yes_yyyy = yesterday.getFullYear();

		
		 
		if(mm<10){
			mm='0'+mm;
		} 

		 var month = new Array(12);
			month[0] = "Jan";
			month[1] = "Feb";
			month[2] = "Mar";
			month[3] = "Apr";
			month[4] = "May";
			month[5] = "Jun";
			month[6] = "Jul";
			month[7] = "Aug";
			month[8] = "Sep";
			month[9] = "Oct";
			month[10] = "Nov";
			month[11] = "Dec";
			var monthtoday = month[today.getUTCMonth()];
			var monthyesterday = month[yesterday.getUTCMonth()];
		    var today = monthtoday+' '+dd+', '+yyyy;
			var last2days = monthyesterday+' '+yes_dd+', '+yes_yyyy;
			document.write(today + '\n' +last2days);

    ref.orderByChild("date").startAt('Dec 1, 2016').endAt('Feb 4, 2017').on("child_added",function (childSnapshot) {
    console.log(JSON.stringify(childSnapshot.val()));
	  arr = JSON.stringify(childSnapshot.val());
	   $.ajax({
                url: 'sms.php',
                dataType: 'json',
                type: 'post',
                contentType: 'application/json',
                data: arr,
                success: function( data, textStatus, jQxhr ){
                    $('#response pre').html( data );
                },
                error: function( jqXhr, textStatus, errorThrown ){
                    console.log( errorThrown );
                }
            });
  }) 
  

  
</script>