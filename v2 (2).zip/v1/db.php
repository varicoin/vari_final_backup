 <?php 
$link = mysql_connect('dandmudik.ipagemysql.com', 'varicoinstage', '$RtN }@<[ yd6J #lYc |H$a )+5'); 
if (!$link) { 
    die('Could not connect: ' . mysql_error()); 
} 

mysql_select_db('varicoin_stage',$link); 
?> 