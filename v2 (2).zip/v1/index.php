<?php
//session_start();

			
include_once('request.php');

define("NOAPPIDCMD",     "xappidxcmd");
define("NOPOSTVAR",     "nopostvar");
define("NOCMDFND",     "nocmdfnd");
define("NOAPPIDFND",     "noappiidfnd");
define("NOFND", "notfound");

$status = new status();
$getcontent = new content();
@$reqsent = $GLOBALS["HTTP_RAW_POST_DATA"];
$reqsent = file_get_contents('php://input');
if($reqsent !='' ){
	$postreq = $reqsent;
}


if(isset($_REQUEST['apiid']) && isset($_REQUEST['cmd'])){
	
	$apiid=$_REQUEST['apiid'];
	$cmd=$_REQUEST['cmd'];
	if($cmd=='main_list')
	$cat_id =$_REQUEST['id'];
	if($cmd=='postdata')
		$pid =$_REQUEST['id'];
    if(isset($_REQUEST['cid']))
	  $cid = $_REQUEST['cid'];
  if(isset($_REQUEST['cname']))
	  $cname = $_REQUEST['cname'];
  if(isset($_REQUEST['iid']))
	  $iid = $_REQUEST['iid'];
  
   if(isset($_REQUEST['page']))
	  $page = $_REQUEST['page'];
    if(isset($_REQUEST['limit']))
	  $limit = $_REQUEST['limit'];
    
	
	if($apiid == 'vari'){
		
		
		if($cmd == 'categories' || $cmd == 'userprofile' || $cmd == 'firebase'  || $cmd == 'selling'  || $cmd == 'buying' || $cmd == 'products' || $cmd == 'product_details' || $cmd == 'post_sms_ads' || $cmd == 'postSmAds' || $cmd == 'postadd' || $cmd == 'recent_ads_more' || $cmd == 'viewed_ads' || $cmd == 'viewed_sms_ads' || $cmd == 'viewed_sms_ads_details' || $cmd == 'sent_sms_ads' || $cmd == 'sent_sms_ads_details' || $cmd == 'reply_ads' || $cmd == 'cat_search' || $cmd == 'replyad' || $cmd == 'recent_actions'  || $cmd == 'sms_ads' || $cmd == 'sms_ads_details' || $cmd == 'register' || $cmd == 'login' || $cmd == 'forgotpassword' || $cmd == 'mode' || $cmd == 'ads' || $cmd == 'addetails' || $cmd == 'categories_list' || $cmd == 'postdata' || $cmd == 'constituencies' || $cmd == 'constituency' || $cmd == 'states' || $cmd == 'awards'  || $cmd == 'main_list' || $cmd == 'items' || $cmd == 'vari_items'){$postreq = '123';}
		
		if($postreq == ''){
			$args = NOPOSTVAR;
			echo $status -> failure($args);
		}
		else{
				switch ($cmd){
					case "awards":
						$getcontent -> awards($postreq);
						break;
					case "postSmAds":
						$getcontent -> postSmAds($postreq);
						break;
					case "firebase":
						$getcontent -> firebase($postreq);
						break;	
					case "selling":
						$getcontent -> selling($postreq,$page,$limit);
						break;
					case "buying":
						$getcontent -> buying($postreq,$page,$limit);
						break;		
					case "userprofile":
						$getcontent -> userprofile($postreq);
						break;
					case "forgotpassword":
						$getcontent -> forgotpassword($postreq);
						break;
					case "recent_ads_more":
						$getcontent -> recent_ads_more($postreq,$page,$limit);
						break;	
					case "viewed_ads":
						$getcontent -> viewed_ads($postreq,$page,$limit);
						break;
					case "products":
						$getcontent -> products($postreq,$page,$limit);
						break;	
					case "product_details":
						$getcontent -> product_details($postreq);
						break;	
									
					case "post_sms_ads":
						$getcontent -> post_sms_ads($postreq);
						break;	
					case "viewed_sms_ads":
						$getcontent -> viewed_sms_ads($postreq,$page,$limit);
						break;
					case "viewed_sms_ads_details":
						$getcontent -> viewed_sms_ads_details($postreq);
						break;		
					case "sent_sms_ads":
						$getcontent -> sent_sms_ads($postreq,$page,$limit);
						break;	
					case "sent_sms_ads_details":
						$getcontent -> sent_sms_ads_details($postreq);
						break;		
					case "replyad":
						$getcontent -> replyad($postreq);
						break;
					case "reply_ads":
						$getcontent -> reply_ads($postreq,$page,$limit);
						break;
					case "cat_search":
						$getcontent -> cat_search($postreq,$page,$limit);
						break;	
					case "addetails":
						$getcontent -> addetails($postreq);
						break;	
					case "categories":
						$getcontent -> categories($postreq);
						break;
					case "sms_ads":
						$getcontent -> sms_ads($postreq,$page,$limit);
						break;	
					case "sms_ads_details":
						$getcontent -> sms_ads_details($postreq);
						break;		
					case "recent_actions":
						$getcontent -> recent_actions($postreq);
						break;
					case "login":
						$getcontent -> login($postreq);
						break;	
					case "register":
						$getcontent -> register($postreq);
						break;	
					case "postadd":
						$getcontent -> postadd($postreq);
						break;	
					case "categories_list":
						$getcontent -> categories_list($postreq);
						break;	
					case "ads":
						$getcontent -> ads($postreq,$page,$limit);
						break;	
					case "mode":
						$getcontent -> mode($postreq);
						break;		
					case "postdata":
						$getcontent -> postdata($postreq,$pid);
						break;
					case "constituencies":
						$getcontent -> constituencies($postreq,$cid,$cname);
						break;
					case "constituency":
						$getcontent -> constituency($postreq);
						break;
					case "states":
						$getcontent -> states($postreq);
						break;
					case "main_list":
						$getcontent -> main_list($postreq,$cat_id);
						break;
					case "items":
						$getcontent -> items($postreq,$iid);
						break;	
					case "vari_items":
						$getcontent -> vari_items($postreq);
						break;	
					
					
					default:
						echo $status -> failure(NOCMDFND);
					}
		}
	}
	else{
			$args = NOAPPIDFND;
			echo $status -> failure($args);
		}
}
else{
		$args = NOAPPIDCMD;
		echo $status -> failure($args);
}
	
?>




