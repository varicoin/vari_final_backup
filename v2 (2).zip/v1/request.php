<?php
session_start();
error_reporting(1);
//include_once('db.php');

class content
{
    Public $statusObj;
    
    //Public $db;
    
    public function Otherclass()
    {
        $statusObj = new status();
        //$db = new DB();
    }
    
    function login($args)
    {
        
        $data  = json_decode(file_get_contents('php://input'));
        $email = $data->email;
        
        $password = $data->password;
        
        foreach ($data->devicedetails as $details) {
            if ($details->name) {
                $name = $details->name;
            }
            if ($details->os) {
                $os = $details->os;
            }
            if ($details->id) {
                $id = $details->id;
            }
            if ($details->address) {
                $address = $details->address;
            }
            if ($details->email) {
                $email = $details->email;
            }
            if ($details->password) {
                $password = $details->password;
            }
        }
        
        
        
        
	    $conn2 =mysql_connect ("dandmudik.ipagemysql.com","varicoinguest","8-&q ICHhW 0*&Z x|4u }_%] b\H1gUeSt") or die ("unable to connect with the database");
     
	     mysql_select_db ("varicoin_vari",$conn2)or die ("unable to select database");
        
        
        $user       = mysql_query("select * from users where password='" . $password . "' and email='" . $email . "'");
        $user_info  = mysql_num_rows($user);
        $return_arr = array();
        
        
        
        if ($user_info == 1) {
            
            
            while ($row = mysql_fetch_array($user)) {
                
                $row_array = array(
                    'status' => 1,
                    'data' => array(
                        "userid" => $row['id'],
                        "email" => $row['email'],
                        "firstname" => $row['first_name'],
                        "lastname" => $row['last_name'],
                        "phone_num" => $row['mobile_num'],
                        "address" => $row['contact_info'],
                        "mode" => $row['mode']
                    )
                );
                //array_push($return_arr,$row_array);
            }
            
            echo json_encode($row_array);
            
            
            
        } else {
            $row_array = array(
                'status' => 0,
                'error' => 401,
                'error_msg' => 'Unauthorized'
            );
			
			 $date = date('d-m-Y h:i:s');
				$logtext = "Route : login\n Date : ".$date."\n " . json_encode($row_array) . "\n";
				$myFile  = "log.txt";
				$fh = fopen($myFile, 'a') or die("can't open file");
				fwrite($fh, $logtext);
				fclose($fh);
				
				if ($logtext != '') {
					$log = json_decode($response, true);
					foreach ($log as $v) {
						echo $v . "<br/>";
					}
				}
            
            echo json_encode($row_array);
        }
        
        
        
    }
    
    function userprofile($args)
    {
        
        $data      = json_decode(file_get_contents('php://input'));
        $firstname = $data->firstname;
        $lastname  = $data->lastname;
        $email     = $data->email;
        $mobile    = $data->mobile;
        $address   = $data->address;
        
        
        foreach ($data->devicedetails as $details) {
            if ($details->name) {
                $name = $details->name;
            }
            if ($details->os) {
                $os = $details->os;
            }
            if ($details->id) {
                $id = $details->id;
            }
            if ($details->address) {
                $address = $details->address;
            }
            if ($details->email) {
                $email = $details->email;
            }
            if ($details->password) {
                $password = $details->password;
            }
        }
        
        
        
        
        $conn2 =mysql_connect ("dandmudik.ipagemysql.com","varicoinguest","8-&q ICHhW 0*&Z x|4u }_%] b\H1gUeSt") or die ("unable to connect with the database");
   
    
		mysql_select_db ("varicoin_vari",$conn2)or die ("unable to select database");
        
        $user      = mysql_query("select * from users where  device_id='" . $id . "'");
        $user_info = mysql_num_rows($user);
        
        $return_arr = array();
        $row_array  = array();
        
        if ($user_info > 0) {
            
            
            
             $conn1 = mysql_connect ("dandmudik.ipagemysql.com","varicoinuser","8-&q ICHhW 0*&Z x|4u }_%] b\H1uSer") or die ("unable to connect with the database");
			mysql_select_db ("varicoin_vari",$conn1)or die ("unable to select database");
            $update = mysql_query("update users set first_name='" . $firstname . "',last_name='" . $lastname . "',mobile_num='" . $mobile . "',contact_info='" . $address . "' where email='" . $email . "' and device_id='" . $id . "'");
            if ($update) {
                $row_array = array(
                    'status' => 1
                );
                // array_push($return_arr,$row_array);
                echo json_encode($row_array);
            } else {
                $row_array = array(
                    'status' => 0
                );
                //array_push($return_arr,$row_array);
                echo json_encode($row_array);
            }
            
            
            
            
        } else {
            $row_array = array(
                'status' => 0,
                'error' => 401,
                'error_msg' => 'Unauthorized'
            );
            
			 $date = date('d-m-Y h:i:s');
				$logtext = "Route : userprofile\n Date : ".$date."\n " . json_encode($row_array) . "\n";
				$myFile  = "log.txt";
				$fh = fopen($myFile, 'a') or die("can't open file");
				fwrite($fh, $logtext);
				fclose($fh);
				
				if ($logtext != '') {
					$log = json_decode($response, true);
					foreach ($log as $v) {
						echo $v . "<br/>";
					}
				}
            //array_push($return_arr,$row_array);
            echo json_encode($row_array);
        }
      
        
    }
    
    function forgotpassword($args)
    {
        
        $data  = json_decode(file_get_contents('php://input'));
        $email = $data->email;
        
        $newpassword     = $data->newpassword;
        $confirmpassword = $data->confirmpassword;
        
        foreach ($data->devicedetails as $details) {
            if ($details->name) {
                $name = $details->name;
            }
            if ($details->os) {
                $os = $details->os;
            }
            if ($details->id) {
                $id = $details->id;
            }
            if ($details->address) {
                $address = $details->address;
            }
            if ($details->email) {
                $email = $details->email;
            }
            if ($details->password) {
                $password = $details->password;
            }
        }
        
        
        
        $conn2 =mysql_connect ("dandmudik.ipagemysql.com","varicoinguest","8-&q ICHhW 0*&Z x|4u }_%] b\H1gUeSt") or die ("unable to connect with the database");
   
    
	 mysql_select_db ("varicoin_vari",$conn2)or die ("unable to select database");
        
        $user      = mysql_query("select * from users where email='" . $email . "' and device_id='" . $id . "'");
        $user_info = mysql_num_rows($user);
        
        $return_arr = array();
        $row_array  = array();
        
        if ($user_info == 1) {
            
            if (($newpassword == $confirmpassword) && ($newpassword != "" && $confirmpassword != "")) {
                
                 $conn1 = mysql_connect ("dandmudik.ipagemysql.com","varicoinuser","8-&q ICHhW 0*&Z x|4u }_%] b\H1uSer") or die ("unable to connect with the database");
				mysql_select_db ("varicoin_vari",$conn1)or die ("unable to select database");
                $update = mysql_query("update users set password='" . $newpassword . "' where email='" . $email . "' and device_id='" . $id . "'");
                if ($update) {
                    $row_array['status'] = "Success";
                    array_push($return_arr, $row_array);
                    echo json_encode($return_arr);
                } else {
                    $row_array['status'] = "Fail";
                    array_push($return_arr, $row_array);
                    echo json_encode($return_arr);
                }
                
            } else {
                $row_array['status'] = "Password mismatch";
                
                array_push($return_arr, $row_array);
                echo json_encode($return_arr);
            }
            
        } else {
            $row_array['status'] = "Fail";
            
            array_push($return_arr, $row_array);
            echo json_encode($return_arr);
        }
        
        
        
        
        
        
        /* $date = date("Y-m-d H:i:s");
        $logtext = "Request----".$date."------" . json_encode($data) . "\n";
        $logtext .= "Response------" . json_encode($return_arr) . "\n";
        $myFile = "log.txt";
        $fh = fopen($myFile, 'a') or die("can't open file");
        fwrite($fh, $logtext);
        fclose($fh);
        
        if ($logtext != '') {
        $log = json_decode($logtext, true);
        foreach ($log as $v) {
        echo $v . "<br/>";
        }
        }*/
        
        
        
        
        //$category = $data->category;
        
    }
    
    
    function firebase($args)
    {
        $row_array  = array();
        $return_arr = array();
        $data       = json_decode(file_get_contents('php://input'));
        $userId     = $data->userId;
        $firebaseId = $data->firebaseId;
        
        $conn1 = mysql_connect ("dandmudik.ipagemysql.com","varicoinuser","8-&q ICHhW 0*&Z x|4u }_%] b\H1uSer") or die ("unable to connect with the database");
	     mysql_select_db ("varicoin_vari",$conn1)or die ("unable to select database");
        $update = mysql_query("UPDATE  `users_info` SET  `firebaseId` =  '" . $firebaseId . "' WHERE  `userId` ='" . $userId . "' ");
        
        if ($update)
            $row_array['status'] = "Success";
        else
            $row_array['status'] = "Fail";
        array_push($return_arr, $row_array);
        echo json_encode($return_arr);
    }
    
    
    function register($args)
    {
        $row_array  = array();
        $return_arr = array();
        $data       = json_decode(file_get_contents('php://input'));
        /*echo "<pre>";
        print_r($data);
        exit;*/
        
        foreach ($data->devicedetails as $details) {
            if ($details->name) {
                $name = $details->name;
            }
            if ($details->os) {
                $os = $details->os;
            }
            if ($details->id) {
                $id = $details->id;
            }
            if ($details->address) {
                $address = $details->address;
            }
            if ($details->email) {
                $email = $details->email;
            }
            if ($details->password) {
                $password = $details->password;
            }
            
        }
        $email = $data->email;
        
        $password   = $data->password;
        $firstname  = $data->firstname;
        $lastname   = $data->lastname;
        $mode       = 0;
        $phone      = $data->phone;
        $address    = $data->address;
        $gender     = $data->gender;
        $firebaseId = $data->firebaseId;
        
        
        
        $date = date("Y-m-d H:i:s");
        
        
        
        $conn2 =mysql_connect ("dandmudik.ipagemysql.com","varicoinguest","8-&q ICHhW 0*&Z x|4u }_%] b\H1gUeSt") or die ("unable to connect with the database");
   
    
	 mysql_select_db ("varicoin_vari",$conn2)or die ("unable to select database");
        $user      = mysql_query("select * from users where email='" . $email . "' and password='" . $password . "'");
        $user_info = mysql_num_rows($user);
        $user_arr  = mysql_fetch_array($user);
        if ($user_info == 0 && $email != "" && $password != "") {
            
            $conn1 = mysql_connect ("dandmudik.ipagemysql.com","varicoinuser","8-&q ICHhW 0*&Z x|4u }_%] b\H1uSer") or die ("unable to connect with the database");
	     mysql_select_db ("varicoin_vari",$conn1)or die ("unable to select database");
            
            
            
            $register_add = mysql_query("INSERT INTO `users` ( `email`, `first_name`, `last_name`, `password`, `contact_person`, `contact_info`, `phone_num`, `mobile_num`, `mode`, `created`, `activationcode`, `device_name`, `device_os`, `device_id`) VALUES ('" . $email . "', '" . $firstname . "', '" . $lastname . "', '" . $password . "', 'admin', '" . $address . "',  '" . $phone . "','" . $phone . "', '" . $mode . "', '" . $date . "', 'test', '" . $name . "', '" . $os . "', '" . $id . "')");
            
            if ($register_add) {
                
                
                
                
                $userq = mysql_query("select * from users where email='" . $email . "' and password='" . $password . "'");
                
                $userid              = mysql_fetch_array($userq);
                $row_array['status'] = 1;
                $row_array['data']   = array(
                    "userid" => $userid['id']
                );
                
                
                $conn1 = mysql_connect ("dandmudik.ipagemysql.com","varicoinuser","8-&q ICHhW 0*&Z x|4u }_%] b\H1uSer") or die ("unable to connect with the database");
	            mysql_select_db ("varicoin_vari",$conn1)or die ("unable to select database");
                
                $users_info = mysql_query("INSERT INTO  `users_info` ( `userId` ,  `gender` ,  `firebaseId` ) 
													VALUES ('" . $userid['id'] . "',  '" . $gender . "',  '" . $firebaseId . "');");
                // array_push($return_arr,$row_array);
                echo json_encode($row_array);
            }
            
            else {
                $row_array['status'] = 0;
                
                //  array_push($return_arr,$row_array);
                echo json_encode($row_array);
                
            }
        }
        if ($user_info == 1) {
            
            
            $row_array['status']     = 0;
            $row_array['error']      = 409;
            $row_array['error_msg'] = "User Already Exist";
			
			   $date = date('d-m-Y h:i:s');
				$logtext = "Route : register\n Date : ".$date."\n " . json_encode($row_array) . "\n";
				$myFile  = "log.txt";
				$fh = fopen($myFile, 'a') or die("can't open file");
				fwrite($fh, $logtext);
				fclose($fh);
				
				if ($logtext != '') {
					$log = json_decode($response, true);
					foreach ($log as $v) {
						echo $v . "<br/>";
					}
				}
            
            
            echo json_encode($row_array);
        }
        

        
    }
    
    function postadd($args)
    {
        
        $date = date("Y-m-d H:i:s");
        
        $row_array  = array();
        $return_arr = array();
        
        
        $data = json_decode(file_get_contents('php://input'));
        
       error_log("test\n" . str_replace('\"',"\n",json_encode($data, JSON_PRETTY_PRINT)));
	
		
        $category     = $data->category;
        $sub_category = $data->sub_category;
        $item         = $data->item;
        $user         = $data->user;
        /*$add_type = $data->ad_details[0]->ad_type;
        $title = $data->ad_details[1]->title;
        $state = $data->ad_details[2]->state;
        $district = $data->ad_details[3]->district;
        $Assembly = $data->ad_details[4]->Assembly;
        $minPrice = $data->ad_details[5]->minPrice;
        $maxPrice = $data->ad_details[6]->maxPrice;
        $priceMode = $data->ad_details[7]->priceMode;
        $quantity = $data->ad_details[8]->quantity;
        $postingBy = $data->ad_details[9]->postingBy;
        $description = $data->ad_details[10]->description;*/
        foreach ($data->ad_details as $adDetails) {
            if ($adDetails->ad_type) {
                $add_type = $adDetails->ad_type;
            }
            
            if ($adDetails->title) {
                $title = $adDetails->title;
            }
            if ($adDetails->state) {
                $state = $adDetails->state;
            }
            if ($adDetails->district) {
                $district = $adDetails->district;
            }
            if ($adDetails->Assembly) {
                $Assembly = $adDetails->Assembly;
            }
            if ($adDetails->minPrice) {
                $minPrice = $adDetails->minPrice;
            }
            if ($adDetails->maxPrice) {
                $maxPrice = $adDetails->maxPrice;
            }
            if ($adDetails->priceMode) {
                $priceMode = $adDetails->priceMode;
            }
            if ($adDetails->quantity) {
                $quantity = $adDetails->quantity;
            }
            if ($adDetails->postingBy) {
                
                $postingBy = $adDetails->postingBy;
                
                
            }
            
            
            
            if ($adDetails->description) {
                $description = $adDetails->description;
            }
            
        }
        
        
        if (!$postingBy)
            $postingBy = 0;
        if (!$add_type)
            $add_type = 0;
        
        
        
        // $images1 = $data->images[0];
        for ($i = 0; $i <= count($data->images); $i++) {
            
            
            $images = $data->images[$i];
            foreach ($images as $key => $image) {
                $arr = explode("img", $key);
                //$data = "img".$arr[1];
                if ($arr[1] == 1) {
                    if ($image != "") {
                        $img1          = base64_decode($image);
                        $imgname->img1 = 'vari_1' . strtotime($date) . '.jpg';
                        $imgurl->url1  = "https://" . $_SERVER['SERVER_NAME'] . "/uploads/" . $imgname->img1;
                        file_put_contents('../uploads/' . $imgname->img1, $img1);
                    } else {
                        $img1          = "";
                        $imgname->img1 = "";
                        $imgurl->url1  = "";
                    }
                    
                    
                    
                    
                }
                if ($arr[1] == 2) {
                    if ($image != "") {
                        $img2          = base64_decode($image);
                        $imgname->img2 = 'vari_2' . strtotime($date) . '.jpg';
                        $imgurl->url2  = "https://" . $_SERVER['SERVER_NAME'] . "/uploads/" . $imgname->img2;
                        file_put_contents('../uploads/' . $imgname->img2, $img2);
                    } else {
                        $img2          = "";
                        $imgname->img2 = "";
                        $imgurl->url2  = "";
                    }
                }
                if ($arr[1] == 3) {
                    if ($image != "") {
                        $img3          = base64_decode($image);
                        $imgname->img3 = 'vari_3' . strtotime($date) . '.jpg';
                        $imgurl->url3  = "https://" . $_SERVER['SERVER_NAME'] . "/uploads/" . $imgname->img3;
                        file_put_contents('../uploads/' . $imgname->img3, $img3);
                    } else {
                        $img3          = "";
                        $imgname->img3 = "";
                        $imgurl->url3  = "";
                    }
                }
                if ($arr[1] == 4) {
                    if ($image != "") {
                        $img4          = base64_decode($image);
                        $imgname->img4 = 'vari_4' . strtotime($date) . '.jpg';
                        $imgurl->url4  = "https://" . $_SERVER['SERVER_NAME'] . "/uploads/" . $imgname->img4;
                        file_put_contents('../uploads/' . $imgname->img4, $img4);
                    } else {
                        $img4          = "";
                        $imgname->img4 = "";
                        $imgurl->url4  = "";
                    }
                }
                if ($arr[1] == 5) {
                    if ($image != "") {
                        $img5          = base64_decode($image);
                        $imgname->img5 = 'vari_5' . strtotime($date) . '.jpg';
                        $imgurl->url5  = "https://" . $_SERVER['SERVER_NAME'] . "/uploads/" . $imgname->img5;
                        file_put_contents('../uploads/' . $imgname->img5, $img5);
                    } else {
                        $img5          = "";
                        $imgname->img5 = "";
                        $imgurl->url5  = "";
                    }
                }
                
                
                
            }
            
            
            
            
        }
        
        
        /*foreach($images1 as $image1)
        {
        $img1 = $images1->$image1;
        print_r($img1); exit;
        }
        $images2 = $data->images[1];
        foreach($images2 as $image2)
        {
        $img2 = $image2;
        }
        $images3 = $data->images[2];
        foreach($images3 as $image3)
        {
        $img3 = $image3;
        }
        $images4 = $data->images[3];
        foreach($images4 as $image4)
        {
        $img4 = $image4;
        }
        $images5 = $data->images[4];
        foreach($images5 as $image5)
        {
        $img5 = $image5;
        }*/
        
        
        
        
        
        
        foreach ($data->devicedetails as $details) {
            if ($details->name) {
                $name = $details->name;
            }
            if ($details->os) {
                $os = $details->os;
            }
            if ($details->id) {
                $id = $details->id;
            }
            if ($details->address) {
                $address = $details->address;
            }
            if ($details->email) {
                $email = $details->email;
                
                
            }
            if ($details->password) {
                $password = $details->password;
            }
        }
        
        /*$name = $data->devicedetails[0]->name;
        $os = $data->devicedetails[1]->os;
        $id = $data->devicedetails[2]->id;
        $address = $data->devicedetails[3]->address;
        $email = $data->devicedetails[4]->email;
        
        $password = $data->devicedetails[5]->password;*/
        //$address = "mothi nagar";
        
        
        
        
        $conn2 =mysql_connect ("dandmudik.ipagemysql.com","varicoinguest","8-&q ICHhW 0*&Z x|4u }_%] b\H1gUeSt") or die ("unable to connect with the database");
   
    
	    mysql_select_db ("varicoin_vari",$conn2)or die ("unable to select database");
        $userq = mysql_query("select * from users where email = '" . $email . "' ");
        
        $user_info = mysql_num_rows($userq);
        $user_data = mysql_fetch_array($userq);
       
        if ($user_info == 1) {
            
            if (($img1 != "" || $img2 != "" || $img3 != "" || $img4 != "" || $img5 != "") && $title != "" && $description != "") {
                
               $conn1 = mysql_connect ("dandmudik.ipagemysql.com","varicoinuser","8-&q ICHhW 0*&Z x|4u }_%] b\H1uSer") or die ("unable to connect with the database");
	         mysql_select_db ("varicoin_vari",$conn1)or die ("unable to select database");          
                
                $postadd = mysql_query("INSERT INTO `posts` (`userid`, `assemblyid`, `districtid`, `categoryid`, `cropid`, `subject`, `message`, `minprice`, `price`, `quantityType`, `quantity`, `location`, `contact_info`, `date`,`editedon`,`postingby`, `mode`,`rate`,`views`) VALUES (".$user_data['id'].", '" . $Assembly . "', '" . $district . "', '" . $sub_category . "', '" . $item . "', '" . $title . "', '" . $description . "', '" . $minPrice . "', '" . $maxPrice . "', '" . $priceMode . "', '" . $quantity . "', '" . $user_data['contact_info'] . "', '" . $user_data['mobile_num'] . "',  '" . $date . "',  '" . $date . "', '" . $postingBy . "', '" . $add_type . "',5,1);");
                
                
                 $conn2 =mysql_connect ("dandmudik.ipagemysql.com","varicoinguest","8-&q ICHhW 0*&Z x|4u }_%] b\H1gUeSt") or die ("unable to connect with the database");
   
    
	              mysql_select_db ("varicoin_vari",$conn2)or die ("unable to select database");
               
                
                
                $post    = mysql_query("select * from posts where userid=" . $user . " and postingby=" . $postingBy . " and assemblyid=" . $Assembly . " order by id desc limit 1");
                $post_id = mysql_fetch_array($post);
                
                
                
                
                $post_info = mysql_num_rows($post);
                if ($post_info == 1) {
                    
                    
                    $i = 0;
                    foreach ($data->images as $images) {
                        $i++;
                        $imgs = "img" . $i;
                        
                        if ($images->$imgs != "") {
                            
                            if (!empty($imgname->$imgs)) {
                                
                                $date = date("Y-m-d H:i:s");
                                
                              $conn1 = mysql_connect ("dandmudik.ipagemysql.com","varicoinuser","8-&q ICHhW 0*&Z x|4u }_%] b\H1uSer") or die ("unable to connect with the database");
	                          mysql_select_db ("varicoin_vari",$conn1)or die ("unable to select database"); 
                                $postimageadd = mysql_query("INSERT INTO `uploads` ( `name`, `location`, `postid`, `date`, `type`) VALUES ('Test', '" . $imgname->$imgs . "', '" . $post_id['id'] . "', '" . $date . "', '0');");
                            }
                        }
                        
                        
                    }
                    
                }
                
                
                if ($postadd) {
                    
                    
                    $conn2 =mysql_connect ("dandmudik.ipagemysql.com","varicoinguest","8-&q ICHhW 0*&Z x|4u }_%] b\H1gUeSt") or die ("unable to connect with the database");
   
    
	               mysql_select_db ("varicoin_vari",$conn2)or die ("unable to select database");
                    
                    
                    $postquery = mysql_query("select * from posts where userid=" . $user . " and postingby=" . $postingBy . " and assemblyid=" . $Assembly . " order by id desc limit 1");
                    
                    $postdata = mysql_fetch_array($postquery);
                    
                    /*$viewpostid  =$post_id['id'];
                    $view_post = mysql_query("select * from posts where id=".$viewpostid);
                    $view_postinfo = mysql_fetch_array($view_post);*/
                    $postingByArray    = array(
                        "Farmer",
                        "Individual",
                        "Agent",
                        "Retail",
                        "Wholesaler",
                        "Company"
                    );
                    $postingby         = $postingByArray[$postingBy];
                    $quantityTypeArray = array(
                        "",
                        "Ea",
                        "Kg",
                        "Qt",
                        "T",
                        "Ltr",
                        "Oth"
                    );
                    $quantityType      = $quantityTypeArray[$postdata['quantityType']];
                    $modeArray         = array(
                        "Selling",
                        "Buying"
                    );
                    $mode              = $modeArray[$add_type];
                    
                    $timestamp           = strtotime($post_id['date']);
                    $row_array['status'] = 1;
                    $row_array['data']   = array(
                        "id" => $postdata['id'],
                        "subject" => $postdata['subject'],
                        "mode" => $mode,
                        "description" => $postdata['message'],
                        "postingBy" => $postingby,
                        "minPrice" => $postdata['minprice'],
                        "maxPrice" => $postdata['price'],
                        "quantity" => $quantity,
                        "quantityType" => $quantityType,
                        "first_name" => $user_data['first_name'],
                        "last_name" => $user_data['last_name'],
                        "contact" => $user_data['mobile_num'],
                        "Postedon" => date("d/m/Y H:i:s", $timestamp),
                        "timestamp" => $timestamp,
                        "views" => $postdata['views'],
                        "address" => $user_data['contact_info'],
                        "images" => array(
                            "img1" => $imgurl->url1,
                            "img2" => $imgurl->url2,
                            "img3" => $imgurl->url3,
                            "img4" => $imgurl->url4,
                            "img5" => $imgurl->url5
                        )
                    );
                    
                    /*$row_array['final_ad_details'] = array("id"=>$postdata['id'],"subject"=>$postdata['subject'],"mode"=>$mode,"description"=>$postdata['message'],"postingBy"=>$postingby,"minPrice"=>$postdata['minprice'],"maxPrice"=>$postdata['price'],"quantity"=>$quantity,"quantityType"=>$quantityType,"first_name"=>$user_data['first_name'],"last_name"=>$user_data['last_name'],"contact"=>$user_data['mobile_num'],"Postedon"=>date("d/m/Y H:i:s",$timestamp),"timestamp"=>$timestamp,"views"=>$postdata['views'],"address"=>$user_data['contact_info']);*/
                    
                    
                    $conn2 =mysql_connect ("dandmudik.ipagemysql.com","varicoinguest","8-&q ICHhW 0*&Z x|4u }_%] b\H1gUeSt") or die ("unable to connect with the database");
   
    
	                mysql_select_db ("varicoin_vari",$conn2)or die ("unable to select database");
					
                    
                    
                    
                    $itemquery     = mysql_query("select category from categories where id='" . $item . "'");
                    $itemdata      = mysql_fetch_array($itemquery);
                    $districtquery = mysql_query("select name from states where id='" . $district . "'");
                    $districtdata  = mysql_fetch_array($districtquery);
                    $assemblyquery = mysql_query("select name from constituencies where id='" . $Assembly . "'");
                    $assemblydata  = mysql_fetch_array($assemblyquery);
                    
                    /*$to = "<nikileshrolla@gmail.com><wom.nikileshrolla@gmail.com>";
                    $subject = 'Reply AD' ;
                    $body = "Hi, <br>".$postingBy." has posted an ".$mode." Ad under the Item ".$itemdata['category'].": ".$title."<br> in Distict ".$districtdata['name']." and in the assembly constituency ".$assemblydata['name']." to view  <a href='http://vari.co.in/post.php?postid=" . $post_id['id']."'>http://vari.co.in/post.php?postid=" . $post_id['id']."</a><br/><br/>Do you like the website, is it helpful to you and do you recommend it to your friend and do you have any feedback please send us an email to varicoin@yahoo.com
                    <br/><br/>Regards<br/> www.vari.co.in";
                    
                    $headers = "MIME-Version: 1.0" . "\r\n";
                    $headers .= "Content-type:text/html;charset=iso-8859-1" . "\r\n";
                    $headers .= 'From: Vari Team <varicoin@yahoo.com >' . "\r\n";
                    
                    $result = mail($to, $subject, $body, $headers);*/
                    if ($add_type == 0) {
                        $modecheck = 1;
                    } else if ($add_type == 1) {
                        $modecheck = 0;
                    }
                    
                    $emails = array();
                    
                    $conn2 =mysql_connect ("dandmudik.ipagemysql.com","varicoinguest","8-&q ICHhW 0*&Z x|4u }_%] b\H1gUeSt") or die ("unable to connect with the database");
   
    
	              mysql_select_db ("varicoin_vari",$conn2)or die ("unable to select database");
                    
                    
                    $postbuyerq = mysql_query("select distinct(userid) from posts where categoryid=" . $sub_category . " and mode=" . $modecheck . " order by id desc");
                    while ($postbuyerr = mysql_fetch_row($postbuyerq)) {
                        
                        
                        
                         $conn2 =mysql_connect ("dandmudik.ipagemysql.com","varicoinguest","8-&q ICHhW 0*&Z x|4u }_%] b\H1gUeSt") or die ("unable to connect with the database");
   
    
	                     mysql_select_db ("varicoin_vari",$conn2)or die ("unable to select database");
                        
                        $usermailq = mysql_query("select email from users where id=" . $postbuyerr[0] . " group by email");
                        $usermailr = mysql_fetch_row($usermailq);
                        $emails[]  = $usermailr[0];
                        
                    }
                    $email_list = implode(",", $emails);
                    
                    
                    
                    $sub = $title;
                    $msg = " You got a reply for ad http://vari.co.in/post.php?postid=" . $postid . " <br/>(Name)" . $username . "<br/> Mobile Number :" . $phone_num . "<br/>Email :" . $email . "<br/>Message : " . $title . "<br/>Buying/Selling Max Price : " . $maxPrice . "<br/> Buying/Selling Min Price : " . $minPrice . "<br/> Price Mode : " . $mode . " <br/> Posting By : " . $postingBy . "<br/> Quantity : " . $quantity . " <br/><br/><br/>Feedback/Comments email to varicoin@yahoo.com<br/>Regards<br/>vari.co.in";
                    
                    mysql_select_db("varicoin_vari", $conn1) or die("unable to select database");
                    $insertmail = mysql_query("INSERT INTO  `mailtracktbl` (`postid` ,   `mode` ,`added_date`,`sent_date`,   `status` ) VALUES ('" . $postdata['id'] . "',  0, '" . date('Y-m-d H:i:s') . "','" . date('Y-m-d H:i:s') . "',  -1);");
                    
                    
                    
                    
                    echo json_encode($row_array);
                }
                
                else {
                    $row_array['status'] = 0;
						   $date = date('d-m-Y h:i:s');
						   $query = "select * from users where email = '" . $email . "' and password='".$password."' ";
					$logtext = "Route : postadd\n Date : ".$date."\n " . json_encode($row_array) . "\n".$query;
					$myFile  = "log.txt";
					$fh = fopen($myFile, 'a') or die("can't open file");
					fwrite($fh, $logtext);
					fclose($fh);
					
					if ($logtext != '') {
						$log = json_decode($response, true);
						foreach ($log as $v) {
							echo $v . "<br/>";
						}
					}
                    
                    
                    
                    
                    echo json_encode($row_array);
                    
                }
            } else {
                
                
                $row_array['status'] = 0;
				   $date = date('d-m-Y h:i:s');
				 $query = "select * from users where email = '" . $email . "' and password='".$password."' ";
					$logtext = "Route : postadd\n Date : ".$date."\n " . json_encode($row_array) . "\n";
				$myFile  = "log.txt";
				$fh = fopen($myFile, 'a') or die("can't open file");
				fwrite($fh, $logtext);
				fclose($fh);
				
				if ($logtext != '') {
					$log = json_decode($response, true);
					foreach ($log as $v) {
						echo $v . "<br/>";
					}
				}
                
                
                echo json_encode($row_array);
            }
            
        } else {
            $row_array = array(
                'status' => 0,
                'error' => 401,
                'error_msg' => 'Unauthorized'
            );
            
            $json_string = file_get_contents('php://input');
            $date = date('d-m-Y h:i:s');
			
				 $query = "select * from users where email = '" . $email . "' and password='".$password."' ";
					$logtext = "Route : postadd\n Date : ".$date."\n " . json_encode($row_array) . "Request :\n".$json_string;
				$myFile  = "log.txt";
				$fh = fopen($myFile, 'a') or die("can't open file");
				fwrite($fh, $logtext);
				fclose($fh);
				
				if ($logtext != '') {
					$log = json_decode($response, true);
					foreach ($log as $v) {
						echo $v . "<br/>";
					}
				}
            echo json_encode($row_array);
            
        }
        
        
        /* $date = date("Y-m-d H:i:s");
        $logtext = "Request----".$date."------" . json_encode($data) ."\n";
        $logtext .= "Response----".json_encode($return_arr);
        $myFile = "log.txt";
        $fh = fopen($myFile, 'a') or die("can't open file");
        fwrite($fh, $logtext);
        fclose($fh);
        
        if ($logtext != '') {
        $log = json_decode($logtext, true);
        foreach ($log as $v) {
        echo $v . "<br/>";
        }
        } */
        
        
        //$category = $data->category;
        
    }
    
    function replyad($args)
    {
        $row_array  = array();
        $return_arr = array();
        
        $date = date('Y-m-d H:i:s', time());
        
        
        $data      = json_decode(file_get_contents('php://input'));
        $postid    = $data->postid;
        $message   = $data->message;
        $minprice  = $data->minprice;
        $maxprice  = $data->maxprice;
        $quantity  = $data->quantity;
        $replyby   = $data->replyby;
        $pricemode = $data->pricemode;
        $username  = $data->username;
        $useremail = $data->useremail;
        $phone_num = $data->phone_num;
        $location  = $data->location;
        $userid    = $data->userid;
        
        foreach ($data->devicedetails as $details) {
            if ($details->name) {
                $name = $details->name;
            }
            if ($details->os) {
                $os = $details->os;
            }
            if ($details->id) {
                $id = $details->id;
            }
            if ($details->address) {
                $address = $details->address;
            }
            if ($details->email) {
                $email = $details->email;
            }
            if ($details->password) {
                $password = $details->password;
            }
            if ($details->location) {
                $location = $details->location;
            }
        }
        
        
        $conn2 =mysql_connect ("dandmudik.ipagemysql.com","varicoinguest","8-&q ICHhW 0*&Z x|4u }_%] b\H1gUeSt") or die ("unable to connect with the database");
   
    
	 mysql_select_db ("varicoin_vari",$conn2)or die ("unable to select database");
        
        
        $userq = mysql_query("select * from users where email='" . $email . "' and password='" . $password . "'");
        
        $user_info = mysql_num_rows($userq);
        $user_data = mysql_fetch_array($userq);
        
        // $postquery = mysql_query("select email from  posts where id=".$postid."");
        // $postdata =mysql_fetch_array($postquery);
        
        
        if ($postid != "") {
            
           
                
                $replyByArray = array(
                    "Farmer",
                    "Individual",
                    "Agent",
                    "Retail",
                    "Wholesaler",
                    "Company"
                );
                $reply_by     = $replyByArray[$post_id['postingby']];
                /*$quantityTypeArray = array("","Ea","Kg","Qt","T","Ltr","Oth");
                $quantityType = $quantityTypeArray[$post_id['quantityType']];*/
                $modeArray    = array(
                    "Selling",
                    "Buying"
                );
                $mode         = $modeArray[$add_type];
                $qty          = $quantity . $pricemode;
                
               $conn1 = mysql_connect ("dandmudik.ipagemysql.com","varicoinuser","8-&q ICHhW 0*&Z x|4u }_%] b\H1uSer") or die ("unable to connect with the database");
	               mysql_select_db ("varicoin_vari",$conn1)or die ("unable to select database");
                
                $replyadd = mysql_query("INSERT INTO `replies` ( `type`, `sent`, `postid`, `message`, `mode_minprice`, `mode_price`, `qtyType`,`mode_quantity`, `name`, `email`, `phone_number`, `location`,`postedBy`, `postedon`,`shipit`) VALUES ( 1, 0, '" . $postid . "', '" . $message . "', '" . $minprice . "', '" . $maxprice . "','0', '" . $qty . "', '" . $username . "', '" . $useremail . "', '" . $phone_num . "', '" . $address . "','" . $mode . "','" . $date . "', '1');");
                
                
                  $conn2 =mysql_connect ("dandmudik.ipagemysql.com","varicoinguest","8-&q ICHhW 0*&Z x|4u }_%] b\H1gUeSt") or die ("unable to connect with the database");
   
    
	              mysql_select_db ("varicoin_vari",$conn2)or die ("unable to select database");
                
                
                
                $postquery = mysql_query("select userid from posts where id=" . $postid . "");
                $postdata  = mysql_fetch_array($postquery);
                
                $userquery = mysql_query("select email from users where id=" . $postdata['userid'] . "");
                $userdata  = mysql_fetch_array($userquery);
                
                
                
                if ($replyadd) {
                    $sub = "Reply AD";
                    $msg = " You got a reply for ad http://vari.co.in/post.php?postid=" . $postid . " <br/>(Name)" . $username . "<br/> Mobile Number :" . $phone_num . "<br/>Email :" . $useremail . "<br/>Message : " . $message . "<br/>Buying/Selling Max Price : " . $maxprice . "<br/> Buying/Selling Min Price : " . $minprice . "<br/> Price Mode : " . $mode . " <br/> Reply By : " . $reply_by . "<br/> Quantity : " . $qty . " <br/><br/><br/>Feedback/Comments email to varicoin@yahoo.com<br/>Regards<br/>vari.co.in";
                    
                    $conn1 = mysql_connect ("dandmudik.ipagemysql.com","varicoinuser","8-&q ICHhW 0*&Z x|4u }_%] b\H1uSer") or die ("unable to connect with the database");
							mysql_select_db ("varicoin_vari",$conn1)or die ("unable to select database");
                    mysql_select_db("varicoin_vari", $conn1) or die("unable to select database");
                    $insertmail = mysql_query("INSERT INTO  `mailtracktbl` (`postid` ,   `mode` ,`added_date`,`sent_date`,   `status` ) VALUES ('" . $postid . "',  0, '" . date('Y-m-d H:i:s') . "','" . date('Y-m-d H:i:s') . "',  -1);");
                    
                    
                    
                    
                    
                    
                    $row_array['status'] = 1;
                     $conn1 = mysql_connect ("dandmudik.ipagemysql.com","varicoinuser","8-&q ICHhW 0*&Z x|4u }_%] b\H1uSer") or die ("unable to connect with the database");
	               mysql_select_db ("varicoin_vari",$conn1)or die ("unable to select database");
                    
                    $replyview = mysql_query("INSERT INTO  `recent_actions` (  `postid` ,  `actionid` ,  `date` ,  `actionby` ) 
																VALUES(	 " . $postid . ",  2,  '" . date('Y-m-d H:i:s') . "',  0
																);");
                    
                    
                    
                    
                    echo json_encode($row_array);
                }
                
                else {
                    
                    $row_array['status'] = 0;
                    
                    
                    
                    
                    echo json_encode($row_array);
                    
                }
            } else {
                
                
               $row_array = array(
                'status' => 0,
                'error' => 401,
                'error_msg' => 'Unauthorized'
				
            );
			
			
				$date = date('d-m-Y h:i:s');
				$logtext = "Route : replyad\n Date : ".$date."\n " . json_encode($row_array) . "\n";
				$myFile  = "log.txt";
				$fh = fopen($myFile, 'a') or die("can't open file");
				fwrite($fh, $logtext);
				fclose($fh);
				
				if ($logtext != '') {
					$log = json_decode($response, true);
					foreach ($log as $v) {
						echo $v . "<br/>";
					}
				}
            
             echo json_encode($row_array);
            }
            
       
        
    
        
    }
    
    
    function addetails($args)
    {
        
        // $row_array = array();
        $return_arr = array();
        
        $date   = date("Y-m-d H:m:s");
        $data   = json_decode(file_get_contents('php://input'));
        $postid = $data->postid;
        $conn2 =mysql_connect ("dandmudik.ipagemysql.com","varicoinguest","8-&q ICHhW 0*&Z x|4u }_%] b\H1gUeSt") or die ("unable to connect with the database");
   
    
	 mysql_select_db ("varicoin_vari",$conn2)or die ("unable to select database");
        $adquery   = mysql_query("select * from posts where id=" . $postid . " order by id desc");
        $addetails = mysql_fetch_array($adquery);
        $num_rows  = mysql_num_rows($adquery);
             
        
        $user      = mysql_query("select * from users where id=" . $addetails['userid'] . "");
        $user_data = mysql_fetch_array($user);
        
        $sql2 = "SELECT  location FROM `uploads` where postid=" . $postid . " ";
        
        $res2   = mysql_query($sql2);
        $images = array();
        $i      = 0;
        while ($row2 = mysql_fetch_array($res2)) {
            if ($row2['location'] != "") {
                $i++;
                $images['img' . $i] = "https://" . $_SERVER['SERVER_NAME'] . "/uploads/" . $row2['location'];
            }
        }
        
        
        $postingByArray    = array(
            "Farmer",
            "Individual",
            "Agent",
            "Retail",
            "Wholesaler",
            "Company"
        );
        $postingBy         = $postingByArray[$addetails['postingby']];
        $quantityTypeArray = array(
            "",
            "Ea",
            "Kg",
            "Qt",
            "T",
            "Ltr",
            "Oth"
        );
        $quantityType      = $quantityTypeArray[$addetails['quantityType']];
        $modeArray         = array(
            "Selling",
            "Buying"
        );
        $mode              = $modeArray[$addetails['mode']];
        $timestamp         = strtotime($addetails['date']);
        $ViewsDetails      = $addetails['views'];
        if ($addetails['views'] == "" || $addetails['views'] == 0) {
            $addetails['views'] = 0;
            
        } else {
            $addetails['views'] = $addetails['views'] + 1;
            
        }
        
         $conn1 = mysql_connect ("dandmudik.ipagemysql.com","varicoinuser","8-&q ICHhW 0*&Z x|4u }_%] b\H1uSer") or die ("unable to connect with the database");
	               mysql_select_db ("varicoin_vari",$conn1)or die ("unable to select database");
        $update = mysql_query("UPDATE  `posts` SET  `views` = " . $addetails['views'] . " WHERE  `id` =" . $postid . "");
        
        //	echo "UPDATE  `posts` SET  `views` = ".$addetails['views']." WHERE  `id` =".$postid."";
        
        $path = "https://" . $_SERVER['SERVER_NAME'] . "/uploads/" . $row2['location'];
        if ($num_rows>0) {
            $row_array['status'] = 1;
            $row_array['data']   = array(
                "id" => $addetails['id'],
                "subject" => $addetails['subject'],
                "mode" => $mode,
                "description" => $addetails['message'],
                "postingBy" => $postingBy,
                "minPrice" => $addetails['minprice'],
                "maxPrice" => $addetails['price'],
                "quantity" => $addetails['quantity'],
                "quantityType" => $quantityType,
                "first_name" => $user_data['first_name'],
                "last_name" => $user_data['last_name'],
                "contact" => $user_data['mobile_num'],
                "Postedon" => date("d/m/Y", $timestamp),
                "views" => $addetails['views'],
                "address" => $user_data['contact_info'],
                "images" => $images
            );
        }
        
        else {
            $row_array['status'] = 0;
				$date = date('d-m-Y h:i:s');
				$logtext = "Route : addetails\n Date : ".$date."\n " . json_encode($row_array) . "\n";
				$myFile  = "log.txt";
				$fh = fopen($myFile, 'a') or die("can't open file");
				fwrite($fh, $logtext);
				fclose($fh);
				
				if ($logtext != '') {
					$log = json_decode($response, true);
					foreach ($log as $v) {
						echo $v . "<br/>";
					}
				}
        }
        
        /*$row_array['final_ad_details'] = array("id"=>$addetails['id'],"subject"=>$addetails['subject'],"mode"=>$mode,"description"=>$addetails['message'],"postingBy"=>$postingBy,"minPrice"=>$addetails['minprice'],"maxPrice"=>$addetails['price'],"quantity"=>$addetails['quantity'],"quantityType"=>$quantityType,"first_name"=>$user_data['first_name'],"last_name"=>$user_data['last_name'],"contact"=>$user_data['mobile_num'],"Postedon"=>date("d/m/Y",$timestamp),"views"=>$addetails['views'],"address"=>$user_data['contact_info']);*/
        
        
        
        
        echo json_encode($row_array);
        
        $conn1 = mysql_connect ("dandmudik.ipagemysql.com","varicoinuser","8-&q ICHhW 0*&Z x|4u }_%] b\H1uSer") or die ("unable to connect with the database");
	 mysql_select_db ("varicoin_vari",$conn1)or die ("unable to select database");
        
        $postview = mysql_query("INSERT INTO  `recent_actions` (  `postid` ,  `actionid` ,  `date` ,  `actionby` ) 
																VALUES(	 " . $postid . ",  4,  '" . date('Y-m-d H:i:s') . "',  0
																);");
        
        
        
        
        //$logtext = "Request----".$date."\n";
        /*$logtext = json_encode($return_arr);
        $myFile = "log.txt";
        $fh = fopen($myFile, 'a') or die("can't open file");
        fwrite($fh, $logtext);
        fclose($fh);
        
        if ($logtext != '') {
        $log = json_decode($logtext, true);
        foreach ($log as $v) {
        echo $v ;
        }
        }*/
        
        
        //$category = $data->category;
        
    }
	
	    function awards($args)
    {
        
        /* $row_array = array();
        $return_arr = array();*/
        $row_array['status'] = 1;
       
                $row_array['data']['images'] = array(
                    "img1" => "https://" . $_SERVER['SERVER_NAME'] . "/v1/awards/1.PNG" ,
                    "img2" => "https://" . $_SERVER['SERVER_NAME'] . "/v1/awards/2.JPG" ,
                    "img3" => "https://" . $_SERVER['SERVER_NAME'] . "/v1/awards/3.jpg" ,
                    "img4" => "https://" . $_SERVER['SERVER_NAME'] . "/v1/awards/4.PNG" 
                    
                );
                
                
         
        echo json_encode($row_array);
    }
    
    function products($args, $page, $limit)
    {
        
        /* $row_array = array();
        $return_arr = array();*/
        $row_array['status'] = 1;
        $conn2 =mysql_connect ("dandmudik.ipagemysql.com","varicoinguest","8-&q ICHhW 0*&Z x|4u }_%] b\H1gUeSt") or die ("unable to connect with the database");
        mysql_select_db ("varicoin_vari",$conn2)or die ("unable to select database");
        
        $catquery = mysql_query("select * from view_posts where main_category_id=6  order by id desc limit $page,$limit");
        $catcount = mysql_num_rows($catquery);
        if ($catcount != 0) {
            while ($catdetails = mysql_fetch_array($catquery)) {
                
                $sql2 = "SELECT  location FROM `uploads` where postid=" . $catdetails['id'] . " limit $page,$limit  ";
                $res2 = mysql_query($sql2);
                while ($row2 = mysql_fetch_array($res2)) {
                    if ($row2['location'] != "") {
                        break;
                    }
                }
                
                
                
                
                if ($catdetails['date'] != "") {
                    //echo "<pre>";
                    // echo   $catdetails['date'];
                    
                    $var         = $catdetails['date'];
                    $datefrmt    = str_replace('/', '-', $var);
                    $newdatefrmt = date('d-m-Y', strtotime($datefrmt));
                    $source      = $newdatefrmt;
                    $date        = new DateTime($source);
                    $posted_date = $date->format('jS F, Y');
                    
                    
                    
                }
                $modeArray           = array(
                    "Selling",
                    "Buying"
                );
                $mode                = $modeArray[$catdetails['mode']];
                $postingByArray      = array(
                    "Farmer",
                    "Individual",
                    "Agent",
                    "Retail",
                    "Wholesaler",
                    "Company"
                );
                $postingBy           = $postingByArray[$catdetails['postingby']];
                $quantityTypeArray   = array(
                    "",
                    "Ea",
                    "Kg",
                    "Qt",
                    "T",
                    "Ltr",
                    "Oth"
                );
                $quantityType        = $quantityTypeArray[$catdetails['quantityType']];
                $images['img1']      = "https://" . $_SERVER['SERVER_NAME'] . "/uploads/" . $row2['location'];
                $row_array['data'][] = array(
                    "id" => $catdetails['id'],
                    "subject" => $catdetails['title'],
                    "mode" => $mode,
                    "postingBy" => $postingBy,
                    "minPrice" => $catdetails['minPrice'],
                    "maxPrice" => $catdetails['price'],
                    "quantity" => $catdetails['quantity'],
                    "quantityType" => $quantityType,
                    "Postedon" => $posted_date,
                    "location" => $catdetails['assembly'],
                    "images" => $images
                );
                
                
                
                //array_push($return_arr,$row_array);	 
                // unset( $row_array['status']);
                $var = "";
            }
            
            
        }
        echo json_encode($row_array);
    }
    
    function product_details($args)
    {
        
        // $row_array = array();
        //$return_arr = array();
        
        $date   = date("Y-m-d H:m:s");
        $data   = json_decode(file_get_contents('php://input'));
        $postid = $data->postid;
        
        
        
        $conn2 =mysql_connect ("dandmudik.ipagemysql.com","varicoinguest","8-&q ICHhW 0*&Z x|4u }_%] b\H1gUeSt") or die ("unable to connect with the database");
         mysql_select_db ("varicoin_vari",$conn2)or die ("unable to select database");
        
        $adquery   = mysql_query("select * from posts where id=" . $postid . " order by id desc");
        $addetails = mysql_fetch_array($adquery);
        
        
        
        $user      = mysql_query("select * from users where id=" . $addetails['userid'] . "");
        $user_data = mysql_fetch_array($user);
        
        $sql2 = "SELECT  location FROM `uploads` where postid=" . $postid . " ";
        
        $res2   = mysql_query($sql2);
        $images = array();
        $i      = 0;
        while ($row2 = mysql_fetch_array($res2)) {
            if ($row2['location'] != "") {
                $i++;
                $images['img' . $i] = "https://" . $_SERVER['SERVER_NAME'] . "/uploads/" . $row2['location'];
            }
        }
        
        
        $postingByArray    = array(
            "Farmer",
            "Individual",
            "Agent",
            "Retail",
            "Wholesaler",
            "Company"
        );
        $postingBy         = $postingByArray[$addetails['postingby']];
        $quantityTypeArray = array(
            "",
            "Ea",
            "Kg",
            "Qt",
            "T",
            "Ltr",
            "Oth"
        );
        $quantityType      = $quantityTypeArray[$addetails['quantityType']];
        $modeArray         = array(
            "Selling",
            "Buying"
        );
        $mode              = $modeArray[$addetails['mode']];
        $timestamp         = strtotime($addetails['date']);
        $ViewsDetails      = $addetails['views'];
        if ($addetails['views'] == "" || $addetails['views'] == 0) {
            $addetails['views'] = 0;
            
        } else {
            $addetails['views'] = $addetails['views'] + 1;
            
        }
        $conn1 = mysql_connect ("dandmudik.ipagemysql.com","varicoinuser","8-&q ICHhW 0*&Z x|4u }_%] b\H1uSer") or die ("unable to connect with the database");
	               mysql_select_db ("varicoin_vari",$conn1)or die ("unable to select database");
        
        $update = mysql_query("UPDATE  `posts` SET  `views` = " . $addetails['views'] . " WHERE  `id` =" . $postid . "");
        
        //	echo "UPDATE  `posts` SET  `views` = ".$addetails['views']." WHERE  `id` =".$postid."";
        $row_array['status'] = 1;
        $path                = "https://" . $_SERVER['SERVER_NAME'] . "/uploads/" . $row2['location'];
        $row_array['data']   = array(
            "id" => $addetails['id'],
            "subject" => $addetails['subject'],
            "mode" => $mode,
            "description" => $addetails['message'],
            "postingBy" => $postingBy,
            "minPrice" => $addetails['minprice'],
            "maxPrice" => $addetails['price'],
            "quantity" => $addetails['quantity'],
            "quantityType" => $quantityType,
            "first_name" => $user_data['first_name'],
            "last_name" => $user_data['last_name'],
            "contact" => $user_data['mobile_num'],
            "Postedon" => date("d/m/Y", $timestamp),
            "views" => $addetails['views'],
            "address" => $user_data['contact_info'],
            "images" => $images
        );
        
        
        
        
        
        
        echo json_encode($row_array);
        
        
         $conn1 = mysql_connect ("dandmudik.ipagemysql.com","varicoinuser","8-&q ICHhW 0*&Z x|4u }_%] b\H1uSer") or die ("unable to connect with the database");
	     mysql_select_db ("varicoin_vari",$conn1)or die ("unable to select database");
        $postview = mysql_query("INSERT INTO  `recent_actions` (  `postid` ,  `actionid` ,  `date` ,  `actionby` ) 
																VALUES(	 " . $postid . ",  4,  '" . date('Y-m-d H:i:s') . "',  0
																);");
        
    }
    
    function selling($args, $page, $limit)
    {
        
        $row_array = array();
        
        $data         = json_decode(file_get_contents('php://input'));
        $category     = $data->category;
        $sub_category = $data->sub_category;
        $item         = $data->item;
        $location     = $data->location;
        $type         = $data->type;
        
        
         $conn2 =mysql_connect ("dandmudik.ipagemysql.com","varicoinguest","8-&q ICHhW 0*&Z x|4u }_%] b\H1gUeSt") or die ("unable to connect with the database");
     
	   mysql_select_db ("varicoin_vari",$conn2)or die ("unable to select database");
        if($location!="")
		{
			
        $catquery = mysql_query("SELECT * 
								
								FROM view_all_ads
								WHERE itemid IN ($item)
								AND mode IN (0) 
								
								ORDER BY  `date` DESC 
								limit $page,$limit ");
								 
						 
		 $catSubquery = mysql_query("SELECT * 
								
								FROM view_all_ads
								WHERE subcategoryid=$sub_category
								AND mode IN (0) 
								
								ORDER BY  `date` DESC 
								limit $page,$limit
								 ");							
								 
        $catquery_count = mysql_query("SELECT * 
								
								FROM view_all_ads
								WHERE itemid IN ($item)
								AND mode IN (0) 
								
								ORDER BY  `id`
								 ");
		 $catsubquery_count = mysql_query("SELECT * 
								
								FROM view_all_ads
								WHERE subcategoryid=$sub_category
								AND mode IN (0) 
								
								ORDER BY  `id`
								 ");	
		}		
			
		else
		{
					 $catquery = mysql_query("SELECT * 
								
								FROM view_all_ads
								WHERE itemid IN ($item)
								AND mode IN (0)
								
								ORDER BY  `date` DESC 
								limit $page,$limit
								 ");
								 
		 $catSubquery = mysql_query("SELECT * 
								
								FROM view_all_ads
								WHERE subcategoryid=$sub_category
								AND mode IN (0)
								
								ORDER BY  `date` DESC 
								limit $page,$limit
								 ");							
								 
        $catquery_count = mysql_query("SELECT * 
								
								FROM view_all_ads
								WHERE itemid IN ($item)
								AND mode IN (0)
								
								ORDER BY  `id`
								 ");
		 $catsubquery_count = mysql_query("SELECT * 
								
								FROM view_all_ads
								WHERE subcategoryid=$sub_category
								AND mode IN (0) 
								
								ORDER BY  `id`
								 ");	
		}
        
        
        $catcount = mysql_num_rows($catquery);
		$catSubcount = mysql_num_rows($catSubquery);
		$catTotalCount = mysql_num_rows($catquery_count);
		$catsubTotalCount = mysql_num_rows($catsubquery_count);
        if ($catsubTotalCount)
            $row_array['status'] = 1;
        else
            $row_array['status'] = 0;
        
        
        
       
        if ($catcount != 0) {
			 $row_array['count'] = $catcount;
		    $row_array['totalCount'] = $catTotalCount;
            while ($catdetails = mysql_fetch_array($catquery)) {
				
                
                $sql2 = "SELECT  location FROM `uploads` where postid=" . $catdetails['id'] . " ";
                $res2 = mysql_query($sql2);
                while ($row2 = mysql_fetch_array($res2)) {
                    if ($row2['location'] != "") {
                        break;
                    }
                }
                
                if ($catdetails['date'] != "") {
                    //echo "<pre>";
                    // echo   $catdetails['date'];
                    
                    $var         = $catdetails['date'];
                    $datefrmt    = str_replace('/', '-', $var);
                    $newdatefrmt = date('d-m-Y', strtotime($datefrmt));
                    $source      = $newdatefrmt;
                    $date        = new DateTime($source);
                    $posted_date = $date->format('jS F, Y');
                    
                    
                    
                }
                
                $locationq     = mysql_query("SELECT  name FROM `constituencies` where id='" . $catdetails['constituencyid'] . "' ");
                $locationr     = mysql_fetch_array($locationq);
                $locationCount = mysql_num_rows($locationq);
                
                if ($locationCount == 1)
                    $location_name = $locationr['name'];
                else
                    $location_name = $catdetails['assemblyid'];
                $timestamp = strtotime($catdetails['date']);
                $modeArray = array(
                    "Buying",
                    "Selling"
                );
                if($catdetails['mode']==1)
                $mode = 'Selling';
			    else
                 $mode = 'Selling';
                $postingByArray    = array(
                    "Farmer",
                    "Individual",
                    "Agent",
                    "Retail",
                    "Wholesaler",
                    "Company"
                );
                $postingBy         = $postingByArray[$catdetails['postingby']];
                $quantityTypeArray = array(
                    "",
                    "Ea",
                    "Kg",
                    "Qt",
                    "T",
                    "Ltr",
                    "Oth"
                );
                $quantityType      = $quantityTypeArray[$catdetails['quantityType']];
				$type   = " ";
                if ($catdetails['minPrice']) {
                    $images = array(
                        "img1" => "https://" . $_SERVER['SERVER_NAME'] . "/uploads/" . $row2['location']
                    );
                    $type   = "Ads";
					$row_array['data'][] = array(
                    "id" => $catdetails['id'],
                    "subject" => $catdetails['title'],
                    "mode" => $mode,
                    "postingBy" => $postingBy,
                    "minPrice" => $catdetails['minPrice'],
                    "maxPrice" => $catdetails['price'],
                    "quantity" => $catdetails['quantity'],
                    "quantityType" => $quantityType,
                    "Postedon" => $posted_date,
                    "location" => $location_name,
                    "postType" => $type,
                    "images" => $images
                  );
                } else {
                    $images = array(
                        "img1" => "https://" . $_SERVER['SERVER_NAME'] . "/images/Sms-Ads-Icon.png"
                    );
                    $type   = "SMS";
					$row_array['data'][] = array(
                    "smsid" => $catdetails['id'],
                    "subject" => $catdetails['title'],
                    "mode" => $mode,
                    "postingBy" => $postingBy,
                    "quantity" => $catdetails['quantity'],
                    "quantityType" => $quantityType,
                    "Postedon" => $posted_date,
                    "location" => $location_name,
                    "postType" => $type,
                    "images" => $images
                  );
					
                } 
                
                
                
            }
            
            
            
            
            
        }
        
        
         else if ($sub_category != 0 && $catSubcount!=0) {
			 $row_array['count'] = $catSubcount;
		    $row_array['totalCount'] = $catsubTotalCount;
            $catquery = mysql_query("SELECT * 
								
								FROM view_all_ads
								WHERE subcategoryid=$sub_category
								AND mode IN (0)
								
								ORDER BY  `date` DESC 
								limit $page,$limit");
            
            $catcount = mysql_num_rows($catquery);
			
            while ($catdetails = mysql_fetch_array($catquery)) {
				
                
                $sql2 = "SELECT  location FROM `uploads` where postid=" . $catdetails['id'] . " ";
                $res2 = mysql_query($sql2);
                while ($row2 = mysql_fetch_array($res2)) {
                    if ($row2['location'] != "") {
                        break;
                    }
                }
                
                if ($catdetails['date'] != "") {
                    //echo "<pre>";
                    // echo   $catdetails['date'];
                    
                    $var         = $catdetails['date'];
                    $datefrmt    = str_replace('/', '-', $var);
                    $newdatefrmt = date('d-m-Y', strtotime($datefrmt));
                    $source      = $newdatefrmt;
                    $date        = new DateTime($source);
                    $posted_date = $date->format('jS F, Y');
                    
                    
                    
                }
                
                $locationq     = mysql_query("SELECT  name FROM `constituencies` where id='" . $catdetails['constituencyid'] . "' ");
                $locationr     = mysql_fetch_array($locationq);
                $locationCount = mysql_num_rows($locationq);
                
                if ($locationCount == 1)
                    $location_name = $locationr['name'];
                else
                    $location_name = $catdetails['assemblyid'];
                $timestamp = strtotime($catdetails['date']);
                $modeArray = array(
                    "Buying",
                    "Selling"
                );
                if($catdetails['mode']==1)
                $mode = 'Selling';
			    else
                 $mode = 'Selling';
                $postingByArray    = array(
                    "Farmer",
                    "Individual",
                    "Agent",
                    "Retail",
                    "Wholesaler",
                    "Company"
                );
                $postingBy         = $postingByArray[$catdetails['postingby']];
                $quantityTypeArray = array(
                    "",
                    "Ea",
                    "Kg",
                    "Qt",
                    "T",
                    "Ltr",
                    "Oth"
                );
                $quantityType      = $quantityTypeArray[$catdetails['quantityType']];
				$type   = " ";
                if ($catdetails['minPrice']) {
                    $images = array(
                        "img1" => "https://" . $_SERVER['SERVER_NAME'] . "/uploads/" . $row2['location']
                    );
                    $type   = "Ads";
					$row_array['data'][] = array(
                    "id" => $catdetails['id'],
                    "subject" => $catdetails['title'],
                    "mode" => $mode,
                    "postingBy" => $postingBy,
                    "minPrice" => $catdetails['minPrice'],
                    "maxPrice" => $catdetails['price'],
                    "quantity" => $catdetails['quantity'],
                    "quantityType" => $quantityType,
                    "Postedon" => $posted_date,
                    "location" => $location_name,
                    "postType" => $type,
                    "images" => $images
                  );
                } else {
                    $images = array(
                        "img1" => "https://" . $_SERVER['SERVER_NAME'] . "/images/Sms-Ads-Icon.png"
                    );
                    $type   = "SMS";
					$row_array['data'][] = array(
                    "id" => $catdetails['id'],
                    "subject" => $catdetails['title'],
                    "mode" => $mode,
                    "postingBy" => $postingBy,
                    "quantity" => $catdetails['quantity'],
                    "quantityType" => $quantityType,
                    "Postedon" => $posted_date,
                    "location" => $location_name,
                    "postType" => $type,
                    "images" => $images
                  );
					
                } 
                
                
                
            }
            
            
            
        }
        
     
        
        else {
            $row_array = array(
                'status' => 0,
                'error' => 401,
                'error_msg' => 'Unauthorized'
            );
            
            	$date = date('d-m-Y h:i:s');
				$logtext = "Route : Selling\n Date : ".$date."\n " . json_encode($row_array) . "\n";
				$myFile  = "log.txt";
				$fh = fopen($myFile, 'a') or die("can't open file");
				fwrite($fh, $logtext);
				fclose($fh);
				
				if ($logtext != '') {
					$log = json_decode($response, true);
					foreach ($log as $v) {
						echo $v . "<br/>";
					}
				}
            
            
        }
        
        
        
        echo json_encode($row_array);
        
        
    }
    
    function buying($args, $page, $limit)
    {
        
       $conn2 =mysql_connect ("dandmudik.ipagemysql.com","varicoinguest","8-&q ICHhW 0*&Z x|4u }_%] b\H1gUeSt") or die ("unable to connect with the database");
       mysql_select_db ("varicoin_vari",$conn2)or die ("unable to select database");
      $row_array = array();
        
        $data         = json_decode(file_get_contents('php://input'));
        $category     = $data->category;
        $sub_category = $data->sub_category;
        $item         = $data->item;
        $location     = $data->location;
        $type         = $data->type;
        
         if($location!="")
		{
			
        $catquery = mysql_query("SELECT * 
								
								FROM view_all_ads
								WHERE itemid IN ($item)
								AND mode IN (1) 
								
								ORDER BY  `date` DESC 
								limit $page,$limit ");
								 
						 
		 $catSubquery = mysql_query("SELECT * 
								
								FROM view_all_ads
								WHERE subcategoryid=$sub_category
								AND mode IN (1) 
								
								ORDER BY  `date` DESC 
								limit $page,$limit
								 ");							
								 
        $catquery_count = mysql_query("SELECT * 
								
								FROM view_all_ads
								WHERE itemid IN ($item)
								AND mode IN (1) 
								
								ORDER BY  `id`
								 ");
		 $catsubquery_count = mysql_query("SELECT * 
								
								FROM view_all_ads
								WHERE subcategoryid=$sub_category
								AND mode IN (1)
								
								ORDER BY  `id`
								 ");	
		}		
			
		else
		{
			 $catquery = mysql_query("SELECT * 
								
								FROM view_all_ads
								WHERE itemid IN ($item)
								AND mode IN (1)
								
								ORDER BY  `date` DESC 
								limit $page,$limit
								 ");
								 
		 $catSubquery = mysql_query("SELECT * 
								
								FROM view_all_ads
								WHERE subcategoryid=$sub_category
								AND mode IN (1)
								
								ORDER BY  `date` DESC 
								limit $page,$limit
								 ");							
								 
        $catquery_count = mysql_query("SELECT * 
								
								FROM view_all_ads
								WHERE itemid IN ($item)
								AND mode IN (1)
								
								ORDER BY  `id`
								 ");
		 $catsubquery_count = mysql_query("SELECT * 
								
								FROM view_all_ads
								WHERE subcategoryid=$sub_category
								AND mode IN (1) 
								
								ORDER BY  `id`
								 ");	
		}
        $catcount = mysql_num_rows($catquery);
		
		$catSubcount = mysql_num_rows($catSubquery);
		$catTotalCount = mysql_num_rows($catquery_count);
		$catsubTotalCount = mysql_num_rows($catsubquery_count);
        if ($catsubTotalCount)
            $row_array['status'] = 1;
        else
            $row_array['status'] = 0;
        
        
        
       
        if ($catcount != 0) {
			
			 $row_array['count'] = $catcount;
		    $row_array['totalCount'] = $catTotalCount;
            while ($catdetails = mysql_fetch_array($catquery)) {
				
                
                $sql2 = "SELECT  location FROM `uploads` where postid=" . $catdetails['id'] . " ";
                $res2 = mysql_query($sql2);
                while ($row2 = mysql_fetch_array($res2)) {
                    if ($row2['location'] != "") {
                        break;
                    }
                }
                
                if ($catdetails['date'] != "") {
                    //echo "<pre>";
                    // echo   $catdetails['date'];
                    
                    $var         = $catdetails['date'];
                    $datefrmt    = str_replace('/', '-', $var);
                    $newdatefrmt = date('d-m-Y', strtotime($datefrmt));
                    $source      = $newdatefrmt;
                    $date        = new DateTime($source);
                    $posted_date = $date->format('jS F, Y');
                    
                    
                    
                }
                
                $locationq     = mysql_query("SELECT  name FROM `constituencies` where id='" . $catdetails['constituencyid'] . "' ");
                $locationr     = mysql_fetch_array($locationq);
                $locationCount = mysql_num_rows($locationq);
                
                if ($locationCount == 1)
                    $location_name = $locationr['name'];
                else
                    $location_name = $catdetails['assemblyid'];
                $timestamp = strtotime($catdetails['date']);
                $modeArray = array(
                    "Buying",
                    "Selling"
                );
                if($catdetails['mode']==1)
                $mode = 'Selling';
			    else
                 $mode = 'Selling';
                $postingByArray    = array(
                    "Farmer",
                    "Individual",
                    "Agent",
                    "Retail",
                    "Wholesaler",
                    "Company"
                );
                $postingBy         = $postingByArray[$catdetails['postingby']];
                $quantityTypeArray = array(
                    "",
                    "Ea",
                    "Kg",
                    "Qt",
                    "T",
                    "Ltr",
                    "Oth"
                );
                $quantityType      = $quantityTypeArray[$catdetails['quantityType']];
				$type   = " ";
                if ($catdetails['minPrice']) {
                    $images = array(
                        "img1" => "https://" . $_SERVER['SERVER_NAME'] . "/uploads/" . $row2['location']
                    );
                    $type   = "Ads";
					$row_array['data'][] = array(
                    "id" => $catdetails['id'],
                    "subject" => $catdetails['title'],
                    "mode" => $mode,
                    "postingBy" => $postingBy,
                    "minPrice" => $catdetails['minPrice'],
                    "maxPrice" => $catdetails['price'],
                    "quantity" => $catdetails['quantity'],
                    "quantityType" => $quantityType,
                    "Postedon" => $posted_date,
                    "location" => $location_name,
                    "postType" => $type,
                    "images" => $images
                  );
                } else {
                    $images = array(
                        "img1" => "https://" . $_SERVER['SERVER_NAME'] . "/images/Sms-Ads-Icon.png"
                    );
                    $type   = "SMS";
					$row_array['data'][] = array(
                    "smsid" => $catdetails['id'],
                    "subject" => $catdetails['title'],
                    "mode" => $mode,
                    "postingBy" => $postingBy,
                    "quantity" => $catdetails['quantity'],
                    "quantityType" => $quantityType,
                    "Postedon" => $posted_date,
                    "location" => $location_name,
                    "postType" => $type,
                    "images" => $images
                  );
					
                } 
                
                
                
            }
            
            
            
            
            
        }
        
        
         else if ($sub_category != 0 && $catSubcount!=0) {
			
			 $row_array['count'] = $catSubcount;
		    $row_array['totalCount'] = $catsubTotalCount;
            $catquery = mysql_query("SELECT * 
								
								FROM view_all_ads
								WHERE subcategoryid=$sub_category
								AND mode IN (1)
								
								ORDER BY  `date` DESC 
								limit $page,$limit");
            
            $catcount = mysql_num_rows($catquery);
			
            while ($catdetails = mysql_fetch_array($catquery)) {
				
                
                $sql2 = "SELECT  location FROM `uploads` where postid=" . $catdetails['id'] . " ";
                $res2 = mysql_query($sql2);
                while ($row2 = mysql_fetch_array($res2)) {
                    if ($row2['location'] != "") {
                        break;
                    }
                }
                
                if ($catdetails['date'] != "") {
                    //echo "<pre>";
                    // echo   $catdetails['date'];
                    
                    $var         = $catdetails['date'];
                    $datefrmt    = str_replace('/', '-', $var);
                    $newdatefrmt = date('d-m-Y', strtotime($datefrmt));
                    $source      = $newdatefrmt;
                    $date        = new DateTime($source);
                    $posted_date = $date->format('jS F, Y');
                    
                    
                    
                }
                
                $locationq     = mysql_query("SELECT  name FROM `constituencies` where id='" . $catdetails['constituencyid'] . "' ");
                $locationr     = mysql_fetch_array($locationq);
                $locationCount = mysql_num_rows($locationq);
                
                if ($locationCount == 1)
                    $location_name = $locationr['name'];
                else
                    $location_name = $catdetails['assemblyid'];
                $timestamp = strtotime($catdetails['date']);
                $modeArray = array(
                    "Buying",
                    "Selling"
                );
                if($catdetails['mode']==1)
                $mode = 'Selling';
			    else
                 $mode = 'Selling';
                $postingByArray    = array(
                    "Farmer",
                    "Individual",
                    "Agent",
                    "Retail",
                    "Wholesaler",
                    "Company"
                );
                $postingBy         = $postingByArray[$catdetails['postingby']];
                $quantityTypeArray = array(
                    "",
                    "Ea",
                    "Kg",
                    "Qt",
                    "T",
                    "Ltr",
                    "Oth"
                );
                $quantityType      = $quantityTypeArray[$catdetails['quantityType']];
				$type   = " ";
                if ($catdetails['minPrice']) {
                    $images = array(
                        "img1" => "https://" . $_SERVER['SERVER_NAME'] . "/uploads/" . $row2['location']
                    );
                    $type   = "Ads";
					$row_array['data'][] = array(
                    "id" => $catdetails['id'],
                    "subject" => $catdetails['title'],
                    "mode" => $mode,
                    "postingBy" => $postingBy,
                    "minPrice" => $catdetails['minPrice'],
                    "maxPrice" => $catdetails['price'],
                    "quantity" => $catdetails['quantity'],
                    "quantityType" => $quantityType,
                    "Postedon" => $posted_date,
                    "location" => $location_name,
                    "postType" => $type,
                    "images" => $images
                  );
                } else {
                    $images = array(
                        "img1" => "https://" . $_SERVER['SERVER_NAME'] . "/images/Sms-Ads-Icon.png"
                    );
                    $type   = "SMS";
					$row_array['data'][] = array(
                    "id" => $catdetails['id'],
                    "subject" => $catdetails['title'],
                    "mode" => $mode,
                    "postingBy" => $postingBy,
                    "quantity" => $catdetails['quantity'],
                    "quantityType" => $quantityType,
                    "Postedon" => $posted_date,
                    "location" => $location_name,
                    "postType" => $type,
                    "images" => $images
                  );
					
                } 
                
                
                
            }
            
            
            
        }
        
     
        
        else {
            $row_array = array(
                'status' => 0,
                'error' => 401,
                'error_msg' => 'Unauthorized'
            );
            
            	$date = date('d-m-Y h:i:s');
				$logtext = "Route : Selling\n Date : ".$date."\n " . json_encode($row_array) . "\n";
				$myFile  = "log.txt";
				$fh = fopen($myFile, 'a') or die("can't open file");
				fwrite($fh, $logtext);
				fclose($fh);
				
				if ($logtext != '') {
					$log = json_decode($response, true);
					foreach ($log as $v) {
						echo $v . "<br/>";
					}
				}
            
            
        }
        
        
        
        echo json_encode($row_array);
        
    }
    
    
    function cat_search($args, $page, $limit)
    {
        
        
        $data         = json_decode(file_get_contents('php://input'));
        $category     = $data->category;
        $sub_category = $data->sub_category;
        $item         = $data->item;
        $location     = $data->location;
        $type         = $data->type;
		$conn2 =mysql_connect ("dandmudik.ipagemysql.com","varicoinguest","8-&q ICHhW 0*&Z x|4u }_%] b\H1gUeSt") or die ("unable to connect with the database");
   
    
	 mysql_select_db ("varicoin_vari",$conn2)or die ("unable to select database");
       
        $catquery = mysql_query("select * from view_all_ads where itemid=" . $item . "  order by id desc limit $page,$limit");
        
        $catcount = mysql_num_rows($catquery);
       
        if ($catcount != 0) {
            $row_array['status'] = 1;
            while ($catdetails = mysql_fetch_array($catquery)) {
                
                $sql2 = "SELECT  location FROM `uploads` where postid=" . $catdetails['id'] . " ";
                $res2 = mysql_query($sql2);
                while ($row2 = mysql_fetch_array($res2)) {
                    if ($row2['location'] != "") {
                        break;
                    }
                }
                
                if ($catdetails['date'] != "") {
                    //echo "<pre>";
                    // echo   $catdetails['date'];
                    
                    $var         = $catdetails['date'];
                    $datefrmt    = str_replace('/', '-', $var);
                    $newdatefrmt = date('d-m-Y', strtotime($datefrmt));
                    $source      = $newdatefrmt;
                    $date        = new DateTime($source);
                    $posted_date = $date->format('jS F, Y');
                    
                    
                    
                }
                $timestamp                               = strtotime($catdetails['date']);
                $modeArray                               = array(
                    "Selling",
                    "Buying"
                );
                $mode                                    = $modeArray[$catdetails['mode']];
                $postingByArray                          = array(
                    "Farmer",
                    "Individual",
                    "Agent",
                    "Retail",
                    "Wholesaler",
                    "Company"
                );
                $postingBy                               = $postingByArray[$catdetails['postingby']];
                $quantityTypeArray                       = array(
                    "",
                    "Ea",
                    "Kg",
                    "Qt",
                    "T",
                    "Ltr",
                    "Oth"
                );
                $quantityType                            = $quantityTypeArray[$catdetails['quantityType']];
                $images 						         = array(
                    "img1" => "https://" . $_SERVER['SERVER_NAME'] . "/uploads/" . $row2['location']
                );
                $row_array['data'][] = array(
                    "id" => $catdetails['id'],
                    "subject" => $catdetails['title'],
                    "mode" => $mode,
                    "postingBy" => $postingBy,
                    "minPrice" => $catdetails['minPrice'],
                    "maxPrice" => $catdetails['price'],
                    "quantity" => $catdetails['quantity'],
                    "quantityType" => $quantityType,
                    "Postedon" => $posted_date,
                    "location" => $catdetails['assembly'],
					"images"   => $images
                );
                
                
            }
          
        }
        
        
        else if ($sub_category != 0) {
            $row_array['status'] = 1;
            $catquery            = mysql_query("select * from view_all_ads where subcategoryid=" . $subcategory . "  order by id desc limit $page,$limit");
            
            $catcount = mysql_num_rows($catquery);
            while ($catdetails = mysql_fetch_array($catquery)) {
                
                $sql2 = "SELECT  location FROM `uploads` where postid=" . $catdetails['id'] . " ";
                $res2 = mysql_query($sql2);
                while ($row2 = mysql_fetch_array($res2)) {
                    if ($row2['location'] != "") {
                        break;
                    }
                }
                
                if ($catdetails['date'] != "") {
                    //echo "<pre>";
                    // echo   $catdetails['date'];
                    
                    $var         = $catdetails['date'];
                    $datefrmt    = str_replace('/', '-', $var);
                    $newdatefrmt = date('d-m-Y', strtotime($datefrmt));
                    $source      = $newdatefrmt;
                    $date        = new DateTime($source);
                    $posted_date = $date->format('jS F, Y');
                    
                    
                    
                }
                $timestamp                               = strtotime($catdetails['date']);
                $modeArray                               = array(
                    "Selling",
                    "Buying"
                );
                $mode                                    = $modeArray[$catdetails['mode']];
                $postingByArray                          = array(
                    "Farmer",
                    "Individual",
                    "Agent",
                    "Retail",
                    "Wholesaler",
                    "Company"
                );
                $postingBy                               = $postingByArray[$catdetails['postingby']];
                $quantityTypeArray                       = array(
                    "",
                    "Ea",
                    "Kg",
                    "Qt",
                    "T",
                    "Ltr",
                    "Oth"
                );
                $quantityType                            = $quantityTypeArray[$catdetails['quantityType']];
                $images								     = array(
                    "img1" => "https://" . $_SERVER['SERVER_NAME'] . "/uploads/" . $row2['location']
                );
                $row_array['data'][] = array(
                    "id" => $catdetails['id'],
                    "subject" => $catdetails['title'],
                    "mode" => $mode,
                    "postingBy" => $postingBy,
                    "minPrice" => $catdetails['minPrice'],
                    "maxPrice" => $catdetails['price'],
                    "quantity" => $catdetails['quantity'],
                    "quantityType" => $quantityType,
                    "Postedon" => $posted_date,
                    "location" => $catdetails['assembly'],
					"images"   => $images
                );
                
                
            }
            
            
            
            
            
        }
        
        
        else if ($category != 0) {
            $row_array['status'] = 1;
            $catquery            = mysql_query("select * from view_all_ads where main_category_id=" . $category . "  order by id desc limit $page,$limit");
            
            $catcount = mysql_num_rows($catquery);
            while ($catdetails = mysql_fetch_array($catquery)) {
                
                $sql2 = "SELECT  location FROM `uploads` where postid=" . $catdetails['id'] . " ";
                $res2 = mysql_query($sql2);
                while ($row2 = mysql_fetch_array($res2)) {
                    if ($row2['location'] != "") {
                        break;
                    }
                }
                
                if ($catdetails['date'] != "") {
                    //echo "<pre>";
                    // echo   $catdetails['date'];
                    
                    $var         = $catdetails['date'];
                    $datefrmt    = str_replace('/', '-', $var);
                    $newdatefrmt = date('d-m-Y', strtotime($datefrmt));
                    $source      = $newdatefrmt;
                    $date        = new DateTime($source);
                    $posted_date = $date->format('jS F, Y');
                    
                    
                    
                }
                $timestamp                               = strtotime($catdetails['date']);
                $modeArray                               = array(
                    "Selling",
                    "Buying"
                );
                $mode                                    = $modeArray[$catdetails['mode']];
                $postingByArray                          = array(
                    "Farmer",
                    "Individual",
                    "Agent",
                    "Retail",
                    "Wholesaler",
                    "Company"
                );
                $postingBy                               = $postingByArray[$catdetails['postingby']];
                $quantityTypeArray                       = array(
                    "",
                    "Ea",
                    "Kg",
                    "Qt",
                    "T",
                    "Ltr",
                    "Oth"
                );
                $quantityType                            = $quantityTypeArray[$catdetails['quantityType']];
                $row_array['data']['images'][]           = array(
                    "img1" => "https://" . $_SERVER['SERVER_NAME'] . "/uploads/" . $row2['location']
                );
                $row_array['data'][] = array(
                    "id" => $catdetails['id'],
                    "subject" => $catdetails['title'],
                    "mode" => $mode,
                    "postingBy" => $postingBy,
                    "minPrice" => $catdetails['minPrice'],
                    "maxPrice" => $catdetails['price'],
                    "quantity" => $catdetails['quantity'],
                    "quantityType" => $quantityType,
                    "Postedon" => $posted_date,
                    "location" => $catdetails['assembly']
                );
                
                
            }
            
            
            
            
            
        }
        
        else {
            $row_array = array(
                'status' => 0,
                'error' => 401,
                'error_msg' => 'Unauthorized'
            );
            
            
				$date = date('d-m-Y h:i:s');
				$logtext = "Route : cat_search\n Date : ".$date."\n " . json_encode($row_array) . "\n";
				$myFile  = "log.txt";
				$fh = fopen($myFile, 'a') or die("can't open file");
				fwrite($fh, $logtext);
				fclose($fh);
				
				if ($logtext != '') {
					$log = json_decode($response, true);
					foreach ($log as $v) {
						echo $v . "<br/>";
					}
				}
            
        }
        
        
        echo json_encode($row_array);
        
        
       
        
    }
    function recent_actions($args)
    {
        
        
        
        $conn2 =mysql_connect ("dandmudik.ipagemysql.com","varicoinguest","8-&q ICHhW 0*&Z x|4u }_%] b\H1gUeSt") or die ("unable to connect with the database");
           mysql_select_db ("varicoin_vari",$conn2)or die ("unable to select database");
				
        
        $return_arr    = array();
        $a             = array();
        $d             = array();
        $actions_query = "SELECT * FROM view_recent_actions";
        $actions_res   = mysql_query($actions_query);
        while ($actions_row = mysql_fetch_array($actions_res)) {
            $row_array                 = array();
            $row_array['subject']      = $actions_row['subject'];
            $row_array['category']     = $actions_row['category'];
            $row_array['constituency'] = $actions_row['name'];
            $row_array['district']     = $actions_row['district_name'];
            $row_array['type']         = $actions_row['type'];
            $row_array['action']       = $actions_row['action'];
            
            $b = array_push($return_arr, $row_array);
        }
        
        
        
        
        echo json_encode($return_arr);
        
    }
    function recent_ads_more($args, $page, $limit)
    {
        
        
        
        $conn2 =mysql_connect ("dandmudik.ipagemysql.com","varicoinguest","8-&q ICHhW 0*&Z x|4u }_%] b\H1gUeSt") or die ("unable to connect with the database");
        mysql_select_db ("varicoin_vari",$conn2)or die ("unable to select database");
        
        $return_arr    = array();
        $row_array     = array();
        $a             = array();
        $d             = array();
        $actions_query = "SELECT * FROM posts order by id desc limit $page,$limit";
        $actions_res   = mysql_query($actions_query);
        $action_count  = mysql_num_rows($actions_res);
        if ($action_count > 0) {
            $row_array['status'] = 1;
            while ($actions_row = mysql_fetch_array($actions_res)) {
                
                $itemquery     = mysql_query("select category from categories where id='" . $actions_row['cropid'] . "'");
                $itemdata      = mysql_fetch_array($itemquery);
                $districtquery = mysql_query("select name from states where id='" . $actions_row['districtid'] . "'");
                $districtdata  = mysql_fetch_array($districtquery);
                $assemblyquery = mysql_query("select name from constituencies where id='" . $actions_row['assemblyid'] . "'");
                $assemblydata  = mysql_fetch_array($assemblyquery);
                
                $modeArray         = array(
                    "Selling",
                    "Buying"
                );
                $mode              = $modeArray[$actions_row['mode']];
                $postingByArray    = array(
                    "Farmer",
                    "Individual",
                    "Agent",
                    "Retail",
                    "Wholesaler",
                    "Company"
                );
                $postingBy         = $postingByArray[$actions_row['postingby']];
                $quantityTypeArray = array(
                    "",
                    "Ea",
                    "Kg",
                    "Qt",
                    "T",
                    "Ltr",
                    "Oth"
                );
                $quantityType      = $quantityTypeArray[$actions_row['quantityType']];
                
                $sql2 = "SELECT  location FROM `uploads` where postid=" . $actions_row['id'] . " ";
                $res2 = mysql_query($sql2);
                while ($row2 = mysql_fetch_array($res2)) {
                    if ($row2['location'] != "") {
                        break;
                    }
                }
                
                $var                 = $actions_row['date'];
                $datefrmt            = str_replace('/', '-', $var);
                $newdatefrmt         = date('d-m-Y', strtotime($datefrmt));
                $source              = $newdatefrmt;
                $date                = new DateTime($source);
                $posted_date         = $date->format('jS F, Y');
                $images['img1']      = "https://" . $_SERVER['SERVER_NAME'] . "/uploads/" . $row2['location'];
                $row_array['data'][] = array(
                    'id' => $actions_row['id'],
                    'subject' => $actions_row['subject'],
                    'minPrice' => $actions_row['minprice'],
                    'maxPrice' => $actions_row['price'],
                    'quantity' => $actions_row['quantity'],
                    'quantityType' => $quantityType,
                    'item' => $itemdata['category'],
                    'constituency' => $actions_row['name'],
                    'district' => $districtdata['name'],
                    'location' => $actions_row['location'],
                    'mode' => $mode,
                    'postingBy' => $postingBy,
                    'createdon' => $posted_date,
                    'timestamp' => strtotime($posted_date),
                    'images' => $images
                );
                             
                
                
            }
        } else {
            $row_array = array(
                'status' => 0,
                'error' => 401,
                'error_msg' => 'Unauthorized'
            );
				$date = date('d-m-Y h:i:s');
				$logtext = "Route : recent_ads_more\n Date : ".$date."\n " . json_encode($row_array) . "\n";
				$myFile  = "log.txt";
				$fh = fopen($myFile, 'a') or die("can't open file");
				fwrite($fh, $logtext);
				fclose($fh);
				
				if ($logtext != '') {
					$log = json_decode($response, true);
					foreach ($log as $v) {
						echo $v . "<br/>";
					}
				}
        }
        
        
        
        
        echo json_encode($row_array);
        
    }
    
    function postSmAds($args)
    {
        
        $return_arr = array();
        $row_array  = array();
        $a          = array();
        $d          = array();
        
        $data     = json_decode(file_get_contents('php://input'));
        $mobile   = $data->mobile;
        $message  = $data->message;
        $location = $data->location;
        $name     = $data->devicedetails[0]->name;
        $os       = $data->devicedetails[1]->os;
        $id       = $data->devicedetails[2]->id;
        $email    = $data->devicedetails[3]->email;
        $date     = date("Y-m-d H:i:s");
        
         $conn1 = mysql_connect ("dandmudik.ipagemysql.com","varicoinuser","8-&q ICHhW 0*&Z x|4u }_%] b\H1uSer") or die ("unable to connect with the database");
	    mysql_select_db ("varicoin_vari",$conn1)or die ("unable to select database");
        $insert = mysql_query("INSERT INTO  `sms_posts_mobile` ( `mobile` ,  `message` ,  `location` ,  `email` ,  `device_name` ,  `device_os` ,  `device_id` ,  `created_date` ) 
VALUES ('" . $mobile . "',  '" . $message . "',  '" . $location . "',  '" . $email . "',  '" . $name . "',  '" . $os . "', '" . $id . "',  '" . $date . "')");
        
        if ($insert) {
            $row_array['status'] = 1;
        } else {
            $row_array = array(
                'status' => 0,
                'error' => 401,
                'error_msg' => 'Unauthorized'
            );
			
				$date = date('d-m-Y h:i:s');
				$logtext = "Route : postSmAds\n Date : ".$date."\n " . json_encode($row_array) . "\n";
				$myFile  = "log.txt";
				$fh = fopen($myFile, 'a') or die("can't open file");
				fwrite($fh, $logtext);
				fclose($fh);
				
				if ($logtext != '') {
					$log = json_decode($response, true);
					foreach ($log as $v) {
						echo $v . "<br/>";
					}
				}
        }
        
        
        echo json_encode($row_array);
        
    }
    function sms_ads($args, $page, $limit)
    {
        
        
        $a = array();
        $d = array();
        
       $conn2 =mysql_connect ("dandmudik.ipagemysql.com","varicoinguest","8-&q ICHhW 0*&Z x|4u }_%] b\H1gUeSt") or die ("unable to connect with the database");
        mysql_select_db ("varicoin_vari",$conn2)or die ("unable to select database");
        
        
        $row_array['status'] = 1;
        
        
        $viewedsmsq     = mysql_query("select * from sms_posts group by title order by id desc limit $page,$limit");
        $viewedsmscount = mysql_num_rows($viewedsmsq);
        if ($viewedsmscount > 0) {
            while ($viewedsmsd = mysql_fetch_array($viewedsmsq)) {
                
                
                $districtq = mysql_query("select name from states where id='" . $viewedsmsd['district'] . "'");
                $districtd = mysql_fetch_array($districtq);
                if ($viewedsmsd['title'] != "") {
                    $row_array['data'][] = array(
                        'smsid' => $viewedsmsd['id'],
                        'title' => $viewedsmsd['title'],
                        'item' => $viewedsmsd['item'],
                        'location' => $viewedsmsd['location'],
                        'district' => $districtd['name'],
                        'mode' => $viewedsmsd['mode'],
                        'phone' => $viewedsmsd['number'],
                        'createdon' => date('jS F, Y', strtotime($viewedsmsd['createdon'])),
                        'timestamp' => strtotime($viewedsmsd['createdon'])
                    );
                }
                
                
                
            }
        } else {
            $row_array = array(
                'status' => 0,
                'error' => 401,
                'error_msg' => 'Unauthorized'
            );
				$date = date('d-m-Y h:i:s');
				$logtext = "Route : sms_ads\n Date : ".$date."\n " . json_encode($row_array) . "\n";
				$myFile  = "log.txt";
				$fh = fopen($myFile, 'a') or die("can't open file");
				fwrite($fh, $logtext);
				fclose($fh);
				
				if ($logtext != '') {
					$log = json_decode($response, true);
					foreach ($log as $v) {
						echo $v . "<br/>";
					}
				}
        }
        
        
        
        
        
        
        echo json_encode($row_array);
        
    }
    
    function sms_ads_details($args)
    {
        
        $data       = json_decode(file_get_contents('php://input'));
        $smsid      = $data->smsid;
        $return_arr = array();
        $row_array  = array();
        $a          = array();
        $d          = array();
        
        $conn2 =mysql_connect ("dandmudik.ipagemysql.com","varicoinguest","8-&q ICHhW 0*&Z x|4u }_%] b\H1gUeSt") or die ("unable to connect with the database");
   
    
	     mysql_select_db ("varicoin_vari",$conn2)or die ("unable to select database");
        
        
        
        $viewedsmsq = mysql_query("select * from view_sms_posts where id=" . $smsid . " ");
        $viewedsmsd = mysql_fetch_array($viewedsmsq);
        $viewedsmscount = mysql_num_rows($viewedsmsq);
        
         if ($viewedsmscount > 0) {
        $row_array['status'] = 1;
        
        $row_array['data']['smsid'] = $viewedsmsd['id'];
        $row_array['data']['title'] = $viewedsmsd['title'];
        
        $row_array['data']['category']    = $viewedsmsd['category'];
        $row_array['data']['subcategory'] = $viewedsmsd['subcategory'];
        $row_array['data']['item']        = $viewedsmsd['item'];
        $row_array['data']['state']       = $viewedsmsd['state_name'];
        $row_array['data']['district']    = $viewedsmsd['district_name'];
        $row_array['data']['location']    = $viewedsmsd['location'];
        $row_array['data']['Postedon']    = $viewedsmsd['createdon'];
        $row_array['data']['views']       = $viewedsmsd['views'];
        $row_array['data']['type']        = $viewedsmsd['MODE'];
        $row_array['data']['phone']       = $viewedsmsd['number'];
        
        $viewedsmsAd = $viewedsmsd['views'] + 1;
        
        
        
        
        
        
        $smsview = mysql_query("INSERT INTO  `recent_actions` (  `postid` ,  `actionid` ,  `date` ,  `actionby` ) 
																VALUES(	 " . $smsid . ", 14,  '" . date('Y-m-d H:i:s') . "',  0
																);");
        
        $update = mysql_query("UPDATE  `view_sms_posts` SET  `views` =  '" . $viewedsmsAd . "' WHERE  `id` ='" . $viewedsmsd['id'] . "'");
		 }
		 else
		 {
			 $row_array = array(
                'status' => 0,
                'error' => 401,
                'error_msg' => 'Unauthorized'
            );
				$date = date('d-m-Y h:i:s');
				$logtext = "Route : sms_ads_details\n Date : ".$date."\n " . json_encode($row_array) . "\n";
				$myFile  = "log.txt";
				$fh = fopen($myFile, 'a') or die("can't open file");
				fwrite($fh, $logtext);
				fclose($fh);
				
				if ($logtext != '') {
					$log = json_decode($response, true);
					foreach ($log as $v) {
						echo $v . "<br/>";
					}
				}
		 }
        
        
        
        
        echo json_encode($row_array);
        
    }
    
    function reply_ads($args, $page, $limit)
    {
        
        
        
        $conn2 =mysql_connect ("dandmudik.ipagemysql.com","varicoinguest","8-&q ICHhW 0*&Z x|4u }_%] b\H1gUeSt") or die ("unable to connect with the database");
   
    
	             mysql_select_db ("varicoin_vari",$conn2)or die ("unable to select database");
        
        $return_arr    = array();
        $row_array     = array();
        $a             = array();
        $d             = array();
        $actions_query = "SELECT * FROM replies order by postedon desc limit $page,$limit";
        $actions_res   = mysql_query($actions_query);
        $reply_count   = mysql_num_rows($actions_res);
        if ($reply_count > 0) {
            $row_array['status'] = 1;
            while ($views_row = mysql_fetch_array($actions_res)) {
                
                $sql3 = "SELECT  * FROM `posts` where id=" . $views_row['postid'] . " ";
                $res3 = mysql_query($sql3);
                $row3 = mysql_fetch_array($res3);
                
                $sql2 = "SELECT  location FROM `uploads` where postid=" . $row3['id'] . " ";
                $res2 = mysql_query($sql2);
                while ($row2 = mysql_fetch_array($res2)) {
                    if ($row2['location'] != "") {
                        break;
                    }
                }
                $itemquery         = mysql_query("select category from categories where id='" . $row3['cropid'] . "'");
                $itemdata          = mysql_fetch_array($itemquery);
                $districtquery     = mysql_query("select name from states where id='" . $row3['districtid'] . "'");
                $districtdata      = mysql_fetch_array($districtquery);
                $assemblyquery     = mysql_query("select name from constituencies where id='" . $row3['assemblyid'] . "'");
                $assemblydata      = mysql_fetch_array($assemblyquery);
                $postingByArray    = array(
                    "Farmer",
                    "Individual",
                    "Agent",
                    "Retail",
                    "Wholesaler",
                    "Company"
                );
                $postingBy         = $postingByArray[$row3['postingby']];
                $quantityTypeArray = array(
                    "",
                    "Ea",
                    "Kg",
                    "Qt",
                    "T",
                    "Ltr",
                    "Oth"
                );
                $quantityType      = $quantityTypeArray[$row3['quantityType']];
                $modeArray         = array(
                    "Selling",
                    "Buying"
                );
                $mode              = $modeArray[$row3['mode']];
                
                $var         = $row3['date'];
                $datefrmt    = str_replace('/', '-', $var);
                $newdatefrmt = date('d-m-Y', strtotime($datefrmt));
                $source      = $newdatefrmt;
                $date        = new DateTime($source);
                $posted_date = $date->format('jS F, Y');
                
                if ($row3['id']) {
                    $row_array['data'][] = array(
                        'id' => $row3['id'],
                        'subject' => $row3['subject'],
                        'minPrice' => $views_row['mode_minprice'],
                        'maxPrice' => $views_row['mode_price'],
                        'quantity' => $row3['quantity'],
                        'quantityType' => $quantityType,
                        'item' => $itemdata['category'],
                        'constituency' => $assemblydata['name'],
                        'district' => $districtdata['name'],
                        'location' => $row3['location'],
                        'mode' => $mode,
                        'postingBy' => $postingBy,
                        'createdon' => $posted_date,
                        'timestamp' => strtotime($posted_date),
                        "images" => array(
                            "img1" => "https://" . $_SERVER['SERVER_NAME'] . "/uploads/" . $row2['location']
                        )
                    );
                }
                
                
                
            }
        }
        
        else {
            $row_array = array(
                'status' => 0,
                'error' => 404,
                'error_msg' => 'No Data'
            );
			
				$date = date('d-m-Y h:i:s');
				$logtext = "Route : reply_ads\n Date : ".$date."\n " . json_encode($row_array) . "\n";
				$myFile  = "log.txt";
				$fh = fopen($myFile, 'a') or die("can't open file");
				fwrite($fh, $logtext);
				fclose($fh);
				
				if ($logtext != '') {
					$log = json_decode($response, true);
					foreach ($log as $v) {
						echo $v . "<br/>";
					}
				}
        }
        
        
        
        
        echo json_encode($row_array);
        
    }
    
    function viewed_ads($args, $page, $limit)
    {
        
        
        
        $conn2 =mysql_connect ("dandmudik.ipagemysql.com","varicoinguest","8-&q ICHhW 0*&Z x|4u }_%] b\H1gUeSt") or die ("unable to connect with the database");
          mysql_select_db ("varicoin_vari",$conn2)or die ("unable to select database");
        
        $return_arr   = array();
        $row_array    = array();
        $a            = array();
        $d            = array();
        $views_query  = "select id,minPrice,price,mode from  view_all_ads where classification like '%ads%' order by id desc limit $page,$limit";
        $views_res    = mysql_query($views_query);
        $viewed_count = mysql_num_rows($views_res);
        if ($viewed_count > 0) {
            $row_array['status'] = 1;
            while ($views_row = mysql_fetch_array($views_res)) {
                
                  $conn2 =mysql_connect ("dandmudik.ipagemysql.com","varicoinguest","8-&q ICHhW 0*&Z x|4u }_%] b\H1gUeSt") or die ("unable to connect with the database");
                  mysql_select_db ("varicoin_vari",$conn2)or die ("unable to select database");
                
                $sql3 = "SELECT  * FROM `posts` where id=" . $views_row['id'] . " ";
                $res3 = mysql_query($sql3);
                $row3 = mysql_fetch_array($res3);
                
                $sql2 = "SELECT  location FROM `uploads` where postid=" . $row3['id'] . " ";
                $res2 = mysql_query($sql2);
                while ($row2 = mysql_fetch_array($res2)) {
                    if ($row2['location'] != "") {
                        break;
                    }
                }
                $itemquery         = mysql_query("select category from categories where id='" . $row3['cropid'] . "'");
                $itemdata          = mysql_fetch_array($itemquery);
                $districtquery     = mysql_query("select name from states where id='" . $row3['districtid'] . "'");
                $districtdata      = mysql_fetch_array($districtquery);
                $assemblyquery     = mysql_query("select name from constituencies where id='" . $row3['assemblyid'] . "'");
                $assemblydata      = mysql_fetch_array($assemblyquery);
                $postingByArray    = array(
                    "Farmer",
                    "Individual",
                    "Agent",
                    "Retail",
                    "Wholesaler",
                    "Company"
                );
                $postingBy         = $postingByArray[$row3['postingby']];
                $quantityTypeArray = array(
                    "",
                    "Ea",
                    "Kg",
                    "Qt",
                    "T",
                    "Ltr",
                    "Oth"
                );
                $quantityType      = $quantityTypeArray[$row3['quantityType']];
                $modeArray         = array(
                    "Selling",
                    "Buying"
                );
                $mode              = $modeArray[$views_row['mode']];
                
                $var         = $row3['date'];
                $datefrmt    = str_replace('/', '-', $var);
                $newdatefrmt = date('d-m-Y', strtotime($datefrmt));
                $source      = $newdatefrmt;
                $date        = new DateTime($source);
                $posted_date = $date->format('jS F, Y');
                
                
                if ($row3['subject']) {
                    $row_array['data'][] = array(
                        'id' => $row3['id'],
                        'subject' => $row3['subject'],
                        'minPrice' => $views_row['minPrice'],
                        'maxPrice' => $views_row['price'],
                        'quantity' => $row3['quantity'],
                        'quantityType' => $quantityType,
                        'item' => $itemdata['category'],
                        'constituency' => $assemblydata['name'],
                        'district' => $districtdata['name'],
                        'location' => $row3['location'],
                        'mode' => $mode,
                        'postingBy' => $postingBy,
                        'createdon' => $posted_date,
                        'timestamp' => strtotime($posted_date),
                        "images" => array(
                            "img1" => "https://" . $_SERVER['SERVER_NAME'] . "/uploads/" . $row2['location']
                        )
                    );
                }
            }
            
        } else {
            $row_array = array(
                'status' => 0,
                'error' => 404,
                'error_msg' => 'No Data'
            );
				$date = date('d-m-Y h:i:s');
				$logtext = "Route : viewed_ads\n Date : ".$date."\n " . json_encode($row_array) . "\n";
				$myFile  = "log.txt";
				$fh = fopen($myFile, 'a') or die("can't open file");
				fwrite($fh, $logtext);
				fclose($fh);
				
				if ($logtext != '') {
					$log = json_decode($response, true);
					foreach ($log as $v) {
						echo $v . "<br/>";
					}
				}
        }
        
        
        
        echo json_encode($row_array);
        
    }
    function post_sms_ads($args)
    {
        
        
         $conn1 = mysql_connect ("dandmudik.ipagemysql.com","varicoinuser","8-&q ICHhW 0*&Z x|4u }_%] b\H1uSer") or die ("unable to connect with the database");
	     mysql_select_db ("varicoin_vari",$conn1)or die ("unable to select database");
        
        $return_arr = array();
        $row_array  = array();
        $a          = array();
        $d          = array();
        
        $data    = json_decode(file_get_contents('php://input'));
        $postid  = $data->postid;
        $subject = $data->subject;
        $message = $data->message;
        $cropid  = $data->item;
        $type    = $data->type;
        
        $userid = $data->userid;
        
        $name      = $data->devicedetails[0]->name;
        $os        = $data->devicedetails[1]->os;
        $id        = $data->devicedetails[2]->id;
        $email     = $data->devicedetails[3]->email;
        $password  = $data->devicedetails[4]->password;
        $postsmsad = mysql_query("INSERT INTO  `sendsms` ( `postid` ,  `subject` ,  `message` ,  `cropid` ,  `updatedon` ,  `postedon` ,  `status` ,  `type` ,  `mode` ) VALUES (" . $postid . ",  '" . $subject . "',  '" . $message . "',  " . $cropid . ",  '" . date("Y-m-d H:i:s") . "',  '" . date("Y-m-d H:i:s") . "',  '0',  '1',  " . $type . ");");
        if ($postsmsad)
            $row_array['status'] = "success";
        else
            $row_array['status'] = "Fail";
        
        $b = array_push($return_arr, $row_array);
        
        
        $smssent = mysql_query("INSERT INTO  `recent_actions` (  `postid` ,  `actionid` ,  `date` ,  `actionby` ) 
																VALUES(	 " . $postid . ",  15,  '" . date('Y-m-d H:i:s') . "',  0
																);");
        
        
        echo json_encode($return_arr);
        
    }
    
    function viewed_sms_ads($args, $page, $limit)
    {
        
        
        
        $conn2 =mysql_connect ("dandmudik.ipagemysql.com","varicoinguest","8-&q ICHhW 0*&Z x|4u }_%] b\H1gUeSt") or die ("unable to connect with the database");
   
    
	 mysql_select_db ("varicoin_vari",$conn2)or die ("unable to select database");
        
        
        $return_arr       = array();
        $row_array        = array();
        $a                = array();
        $d                = array();
        $views_sms_query  = "select postid from view_actions where actionid=14 order by date desc limit $page,$limit";
        $views_sms_res    = mysql_query($views_sms_query);
        $viewed_sms_count = mysql_num_rows($views_sms_res);
        if ($viewed_sms_count > 0) {
            $row_array['status'] = 1;
            while ($views_sms_row = mysql_fetch_array($views_sms_res)) {
                
                $viewedsmsq = mysql_query("select * from sms_posts where id=" . $views_sms_row['postid'] . " order by id desc");
                while ($viewedsmsd = mysql_fetch_array($viewedsmsq)) {
                    
                    
                    
                    if ($viewedsmsd['id']) {
                        $row_array['data'][] = array(
                            'smsid' => $viewedsmsd['id'],
                            'title' => $viewedsmsd['title'],
                            'item' => $viewedsmsd['item'],
                            'district' => $viewedsmsd['district'],
                            'location' => $viewedsmsd['location'],
                            'mode' => $viewedsmsd['mode'],
                            'phone' => $viewedsmsd['number'],
                            'createdon' => date('jS F, Y', strtotime($viewedsmsd['createdon'])),
                            'timestamp' => strtotime($viewedsmsd['createdon'])
                        );
                    }
                    
                    
                }
                
            }
        } else {
            $row_array = array(
                'status' => 0,
                'error' => 404,
                'error_msg' => 'No Data'
            );
				$date = date('d-m-Y h:i:s');
				$logtext = "Route : viewed_sms_ads\n Date : ".$date."\n " . json_encode($row_array) . "\n";
				$myFile  = "log.txt";
				$fh = fopen($myFile, 'a') or die("can't open file");
				fwrite($fh, $logtext);
				fclose($fh);
				
				if ($logtext != '') {
					$log = json_decode($response, true);
					foreach ($log as $v) {
						echo $v . "<br/>";
					}
				}
        }
        
        
        
        
        echo json_encode($row_array);
        
    }
    
    function viewed_sms_ads_details($args)
    {
        
        $data       = json_decode(file_get_contents('php://input'));
        $smsid      = $data->smsid;
        $return_arr = array();
        $row_array  = array();
        $a          = array();
        $d          = array();
        
        
        
        $conn2 =mysql_connect ("dandmudik.ipagemysql.com","varicoinguest","8-&q ICHhW 0*&Z x|4u }_%] b\H1gUeSt") or die ("unable to connect with the database");
   
    
	    mysql_select_db ("varicoin_vari",$conn2)or die ("unable to select database");
        
        
        $viewedsmsq       = mysql_query("select * from view_sms_posts where id=" . $smsid . " ");
        $viewedsmsd       = mysql_fetch_array($viewedsmsq);
        $viewed_sms_count = mysql_num_rows($viewedsmsq);
        
        
        if ($viewed_sms_count > 0) {
            $row_array['status'] = 1;
            $row_array['data']   = array(
                'smsid' => $viewedsmsd['id'],
                'title' => $viewedsmsd['title'],
                'item' => $viewedsmsd['item'],
                'district' => $viewedsmsd['district'],
                'location' => $row_array['location'],
                'mode' => $viewedsmsd['mode'],
                'phone' => $viewedsmsd['number'],
                'createdon' => $viewedsmsd['createdon'],
                'timestamp' => strtotime($viewedsmsd['createdon'])
            );
        } else {
            $row_array = array(
                'status' => 0,
                'error' => 404,
                'error_msg' => 'No Data'
            );
				$date = date('d-m-Y h:i:s');
				$logtext = "Route : viewed_sms_ads_details\n Date : ".$date."\n " . json_encode($row_array) . "\n";
				$myFile  = "log.txt";
				$fh = fopen($myFile, 'a') or die("can't open file");
				fwrite($fh, $logtext);
				fclose($fh);
				
				if ($logtext != '') {
					$log = json_decode($response, true);
					foreach ($log as $v) {
						echo $v . "<br/>";
					}
				}
        }
        
        
        
        echo json_encode($row_array);
        
    }
    function sent_sms_ads($args, $page, $limit)
    {
        
        
        $conn2 =mysql_connect ("dandmudik.ipagemysql.com","varicoinguest","8-&q ICHhW 0*&Z x|4u }_%] b\H1gUeSt") or die ("unable to connect with the database");
   
    
	     mysql_select_db ("varicoin_vari",$conn2)or die ("unable to select database");
        
        
        $return_arr       = array();
        $row_array        = array();
        $a                = array();
        $d                = array();
        $views_sms_query  = "select postid,postedon from sendsms where type=1 order by postedon desc limit $page,$limit";
        $views_sms_res    = mysql_query($views_sms_query);
        $viewed_sms_count = mysql_num_rows($views_sms_res);
        if ($viewed_sms_count > 0) {
            $row_array['status'] = 1;
            while ($views_sms_row = mysql_fetch_array($views_sms_res)) {
                
                $viewedsmsq = mysql_query("select * from view_sms_posts where id=" . $views_sms_row['postid'] . " order by id desc");
                while ($viewedsmsd = mysql_fetch_array($viewedsmsq)) {
					
					  $var         = $viewedsmsd['createdon'];
                    $datefrmt    = str_replace('/', '-', $var);
                    $newdatefrmt = date('d-m-Y', strtotime($datefrmt));
                    $source      = $newdatefrmt;
                    $date        = new DateTime($source);
                    $posted_date = $date->format('jS F, Y');
                    
                    $row_array['data'][] = array(
                        'smsid' => $viewedsmsd['id'],
                        'title' => $viewedsmsd['title'],
                        'category' => $viewedsmsd['category'],
                        'subcategory' => $viewedsmsd['subcategory'],
                        'item' => $viewedsmsd['item'],
                        'district' => $viewedsmsd['district'],
                        'location' => $viewedsmsd['location'],
                        'mode' => $viewedsmsd['MODE'],
                        'phone' => $viewedsmsd['number'],
                        'createdon' => $posted_date,
                        'timestamp' => strtotime($views_sms_row['postedon'])
                    );
                    
                    
                }
                
            }
        } else {
            $row_array = array(
                'status' => 0,
                'error' => 404,
                'error_msg' => 'No Data'
            );
				$date = date('d-m-Y h:i:s');
				$logtext = "Route : sent_sms_ads\n Date : ".$date."\n " . json_encode($row_array) . "\n";
				$myFile  = "log.txt";
				$fh = fopen($myFile, 'a') or die("can't open file");
				fwrite($fh, $logtext);
				fclose($fh);
				
				if ($logtext != '') {
					$log = json_decode($response, true);
					foreach ($log as $v) {
						echo $v . "<br/>";
					}
				}
        }
        
        
        
        
        echo json_encode($row_array);
        
    }
    
    function sent_sms_ads_details($args)
    {
        
        $data       = json_decode(file_get_contents('php://input'));
        $smsid      = $data->smsid;
        $return_arr = array();
        $row_array  = array();
        $a          = array();
        $d          = array();
        
        
        $conn2 =mysql_connect ("dandmudik.ipagemysql.com","varicoinguest","8-&q ICHhW 0*&Z x|4u }_%] b\H1gUeSt") or die ("unable to connect with the database");
   
    
	    mysql_select_db ("varicoin_vari",$conn2)or die ("unable to select database");
        
        
        $viewedsmsq       = mysql_query("select * from view_sms_posts where id=" . $smsid . " ");
        $viewedsmsd       = mysql_fetch_array($viewedsmsq);
        $viewed_sms_count = mysql_num_rows($viewedsmsq);
        if ($viewed_sms_count > 0) {
            
            $row_array['status'] = 1;
            
            
            
            $row_array['data'] = array(
                'smsid' => $viewedsmsd['id'],
                'title' => $viewedsmsd['title'],
                'category' => $viewedsmsd['category'],
                'subcategory' => $viewedsmsd['subcategory'],
                'item' => $viewedsmsd['item'],
                'district' => $viewedsmsd['district'],
                'location' => $row_array['location'],
                'mode' => $viewedsmsd['MODE'],
                'phone' => $viewedsmsd['number'],
                'Postedon' => $viewedsmsd['createdon'],
                'timestamp' => strtotime($views_sms_row['postedon'])
            );
        } else {
            $row_array = array(
                'status' => 0,
                'error' => 404,
                'error_msg' => 'No Data'
            );
				$date = date('d-m-Y h:i:s');
				$logtext = "Route : sent_sms_ads_details\n Date : ".$date."\n " . json_encode($row_array) . "\n";
				$myFile  = "log.txt";
				$fh = fopen($myFile, 'a') or die("can't open file");
				fwrite($fh, $logtext);
				fclose($fh);
				
				if ($logtext != '') {
					$log = json_decode($response, true);
					foreach ($log as $v) {
						echo $v . "<br/>";
					}
				}
        }
        
        
        
        echo json_encode($row_array);
        
    }
    function states($args)
    {
        
        
        
         $conn2 =mysql_connect ("dandmudik.ipagemysql.com","varicoinguest","8-&q ICHhW 0*&Z x|4u }_%] b\H1gUeSt") or die ("unable to connect with the database");
           mysql_select_db ("varicoin_vari",$conn2)or die ("unable to select database");
        
        $return_arr          = array();
        $row_array           = array();
        $a                   = array();
        $d                   = array();
        $sql1                = "SELECT * FROM states where parentid=1 order by name";
        $res1                = mysql_query($sql1);
        $constituencies      = array();
        $row_array['status'] = 1;
        $i                   = 0;
        while ($row1 = mysql_fetch_array($res1)) {
            
            $j                             = 0;
            $row_array['data'][$i]['id']   = $row1['id'];
            $row_array['data'][$i]['name'] = $row1['name'];
            
            $conn2 =mysql_connect ("dandmudik.ipagemysql.com","varicoinguest","8-&q ICHhW 0*&Z x|4u }_%] b\H1gUeSt") or die ("unable to connect with the database");
   
    
	        mysql_select_db ("varicoin_vari",$conn2)or die ("unable to select database");
            
            
            
            $sql2 = "SELECT * FROM states where parentid=" . $row1['id'] . " order by name";
            $res2 = mysql_query($sql2);
            while ($row2 = mysql_fetch_array($res2)) {
                
                $constituencies = array();
                $sql3           = "SELECT * FROM constituencies where parent_name=" . $row2['id'] . " order by name";
                $res3           = mysql_query($sql3);
                while ($row3 = mysql_fetch_array($res3)) {
                    $constituencies[] = array(
                        'id' => $row3['id'],
                        'constituency' => $row3['name']
                    );
                }
                
                $row_array['data'][$i]['districts'][$j] = array(
                    'id' => $row2['id'],
                    'district' => $row2['name'],
                    'constituencies' => $constituencies
                );
                $j++;
                
                /*$a['id'] = $row2['id'];
                $a['district'] = $row2['name'];*/
                
            }
            
            $i++;
        }
        
        echo json_encode($row_array);
        
    }
    function categories_list($args)
    {
        
        
        
        $conn2 =mysql_connect ("dandmudik.ipagemysql.com","varicoinguest","8-&q ICHhW 0*&Z x|4u }_%] b\H1gUeSt") or die ("unable to connect with the database");
   
    
	          mysql_select_db ("varicoin_vari",$conn2)or die ("unable to select database");
        
        $return_arr          = array();
        $a                   = array();
        $d                   = array();
        $sql1                = "SELECT * FROM categories where parentid=0 order by category";
        $res1                = mysql_query($sql1);
        $row_array           = array();
        $row_array['status'] = 1;
        $i                   = 0;
        while ($row1 = mysql_fetch_array($res1)) {
            
            $j = 0;
            
            $row_array['data'][$i]['id']       = $row1['id'];
            $row_array['data'][$i]['category'] = $row1['category'];
            
            $sql2 = "SELECT * FROM categories where parentid=" . $row1['id'] . " order by category ";
            $res2 = mysql_query($sql2);
            while ($row2 = mysql_fetch_array($res2)) {
                
                $items = array();
                $sql3  = "SELECT * FROM categories where parentid=" . $row2['id'] . " order by category";
                $res3  = mysql_query($sql3);
                while ($row3 = mysql_fetch_array($res3)) {
                    $items[] = array(
                        'id' => $row3['id'],
                        'item' => $row3['category']
                    );
                }
                if ($row2['category']) {
                    $row_array['data'][$i]['sub_categories'][$j] = array(
                        'id' => $row2['id'],
                        'Sub_category' => $row2['category'],
                        'items' => $items
                    );
                    $j++;
                }
                
                
                /*$a['id'] = $row2['id'];
                $a['district'] = $row2['name'];*/
                
            }
            $i++;
            
            
        }
        
        echo json_encode($row_array);
        
    }
    function ads($args, $page, $limit)
    {
        $row_array = array();
        $images    = array();
        
        $conn2 =mysql_connect ("dandmudik.ipagemysql.com","varicoinguest","8-&q ICHhW 0*&Z x|4u }_%] b\H1gUeSt") or die ("unable to connect with the database");
   
    
	             mysql_select_db ("varicoin_vari",$conn2)or die ("unable to select database");
        
        
        $return_arr = array();
        
        $sql1      = "SELECT id,subject,`minPrice`, quantityType,quantity,mode,date FROM `posts` order by id desc limit 0,$limit ";
        $res1      = mysql_query($sql1);
        $ads_count = mysql_num_rows($res1);
        if ($ads_count > 0) {
            
            $row_array['status'] = 1;
            
            while ($row1 = mysql_fetch_array($res1)) {
                
                $sql2 = "SELECT  location FROM `uploads` where postid=" . $row1['id'] . " ";
                $res2 = mysql_query($sql2);
                while ($row2 = mysql_fetch_array($res2)) {
                    if ($row2['location'] != "") {
                        break;
                    }
                }
                
                $quantityTypeArray = array(
                    "",
                    "Ea",
                    "Kg",
                    "Qt",
                    "T",
                    "Ltr",
                    "Oth"
                );
                $quantityType      = $quantityTypeArray[$row1['quantityType']];
                $quantity          = $row1['quantity'];
                $modeArray         = array(
                    "Selling",
                    "Buying"
                );
                $mode              = $modeArray[$row1['mode']];
                
                $var         = $row1['date'];
                $datefrmt    = str_replace('/', '-', $var);
                $newdatefrmt = date('d-m-Y H:i:s', strtotime($datefrmt));
                $source      = $newdatefrmt;
                $date        = new DateTime($source);
                $posted_date = $date->format('jS F, Y');
                
                $images['img1'] = "https://" . $_SERVER['SERVER_NAME'] . "/uploads/" . $row2['location'];
                
                $row_array['data'][] = array(
                    'id' => $row1['id'],
                    'title' => $row1['subject'],
                    'minPrice' => $row1['minPrice'],
                    'quantity' => $row1['quantity'],
                    'quantityType' => $quantityType,
                    'mode' => $mode,
                    'phone' => $row1['number'],
                    'Postedon' => $posted_date,
                    'timestamp' => strtotime($newdatefrmt),
                    "images" => $images
                );
                
                
                
                
                
                
                
            }
        } else {
            $row_array = array(
                'status' => 0,
                'error' => 404,
                'error_msg' => 'No Data'
            );
				$date = date('d-m-Y h:i:s');
				$logtext = "Route : Ads\n Date : ".$date."\n " . json_encode($row_array) . "\n";
				$myFile  = "log.txt";
				$fh = fopen($myFile, 'a') or die("can't open file");
				fwrite($fh, $logtext);
				fclose($fh);
				
				if ($logtext != '') {
					$log = json_decode($response, true);
					foreach ($log as $v) {
						echo $v . "<br/>";
					}
				}
        }
        
        echo json_encode($row_array);
        
        
        /* $date = date("Y-m-d H:i:s");
        $logtext = "Request----".$date."------" ."\n";
        $logtext .= "Response----".json_encode($return_arr);
        $myFile = "log.txt";
        $fh = fopen($myFile, 'a') or die("can't open file");
        fwrite($fh, $logtext);
        fclose($fh);
        
        if ($logtext != '') {
        $log = json_decode($logtext, true);
        foreach ($log as $v) {
        echo $v . "<br/>";
        }
        }*/
        
    }
    function mode($args)
    {
        
        
        $return_arr = array();
        
        
        $row_array                     = array();
        $row_array['status']           = 1;
        /* 	$row_array['Mode'] = array(array("id"=>0,"name"=>"Selling"),array("id"=>1,"name"=>"Buying"),array("id"=>2,"name"=>"Closed")); */
        $row_array['data'][0]['User']  = array(
            array(
                "id" => 0,
                "name" => "Farmer"
            ),
            array(
                "id" => 1,
                "name" => "Individual"
            ),
            array(
                "id" => 2,
                "name" => "Agent"
            ),
            array(
                "id" => 3,
                "name" => "Retail"
            ),
            array(
                "id" => 4,
                "name" => "Wholesaler"
            ),
            array(
                "id" => 5,
                "name" => "Company"
            )
        );
        $row_array['data'][0]['Price'] = array(
            array(
                "id" => 1,
                "name" => "Each"
            ),
            array(
                "id" => 2,
                "name" => "Kilograms"
            ),
            array(
                "id" => 3,
                "name" => "Quintal"
            ),
            array(
                "id" => 4,
                "name" => "Tons"
            ),
            array(
                "id" => 5,
                "name" => "Litre"
            ),
            array(
                "id" => 6,
                "name" => "Others"
            )
        );
        
        
        
        
        
        
        
        
        
        echo json_encode($row_array);
        
    }
    function categories($args)
    {
        
        
        
        	$conn2 =mysql_connect ("dandmudik.ipagemysql.com","varicoinguest","8-&q ICHhW 0*&Z x|4u }_%] b\H1gUeSt") or die ("unable to connect with the database");
   
    
	 mysql_select_db ("varicoin_vari",$conn2)or die ("unable to select database");
        
        $return_arr = array();
        
        $sql = mysql_query("SELECT 
   						   COUNT(IF(`main_category_id`=1,1,null)) as 'CROPS',
						   COUNT(IF(`main_category_id`=369,1,null)) as 'FLOWERS & NURSERY',
						   COUNT(IF(`main_category_id`=3,1,null)) as 'ANIMAL PRODUCTS',
						   COUNT(IF(`main_category_id`=360,1,null)) as 'VEGETABLES',
						   COUNT(IF(`main_category_id`=345,1,null)) as 'MEDICAL PLANTS',
						   COUNT(IF(`main_category_id`=2,1,null)) as 'FRUITS',
						   COUNT(IF(`main_category_id`=6,1,null)) as 'PRODUCTS',	
						   COUNT(IF(`main_category_id`=4,1,null)) as 'MANURE & WASTE',
						   COUNT(IF(`main_category_id`=319,1,null)) as 'MACHINE',	
						   COUNT(IF(`main_category_id`=303,1,null)) as 'ORGANIC & NATURAL'
						FROM view_posts;");
        $row = mysql_fetch_assoc($sql);
        array_push($return_arr, $row);
        
        echo json_encode($return_arr);
        
    }
    function items($args, $id)
    {
        
        
        
        $conn2 =mysql_connect ("dandmudik.ipagemysql.com","varicoinguest","8-&q ICHhW 0*&Z x|4u }_%] b\H1gUeSt") or die ("unable to connect with the database");
   
    
	 mysql_select_db ("varicoin_vari",$conn2)or die ("unable to select database");
        
        $return_arr = array();
        $a          = array();
        $sql1       = "select id,category,list from (
						select catid,group_concat(category) as list from (
						SELECT ct.id as catid,group_concat(cat.id order by cat.id asc) as parent FROM `categories` ct
						join categories cat on cat.parentid = ct.id
						group by ct.id) X
						join categories catg on find_in_set(id,parent)
						group by catid)Y
						join categories catge on catge.id = Y.catid where id IN(" . $id . ") ORDER BY category";
        $res1       = mysql_query($sql1);
        
        while ($row1 = mysql_fetch_array($res1)) {
            //$a['parentid'] = $row1['parentid'];
            $d['parentitem'] = $row1['category'];
            
            $c   = array_push($return_arr, $d);
            $arr = explode(',', $row1['list']);
            for ($i = 0; $i < count($arr); $i++) {
                $a['categoryitem'] = $arr[$i];
                $b                 = array_push($return_arr, $a);
                
            }
            
            
            
        }
        echo json_encode($return_arr);
        
    }
    function vari_items($args)
    {
        
        
        $conn2 =mysql_connect ("dandmudik.ipagemysql.com","varicoinguest","8-&q ICHhW 0*&Z x|4u }_%] b\H1gUeSt") or die ("unable to connect with the database");
   
    
	 mysql_select_db ("varicoin_vari",$conn2)or die ("unable to select database");
        
        
        $return_arr = array();
        $a          = array();
        $sql1       = "select id,category,list from (
						select catid,group_concat(category) as list from (
						SELECT ct.id as catid,group_concat(cat.id order by cat.id asc) as parent FROM `categories` ct
						join categories cat on cat.parentid = ct.id
						group by ct.id) X
						join categories catg on find_in_set(id,parent)
						group by catid)Y
						join categories catge on catge.id = Y.catid where parentid not IN(-1,0,1) order by category";
        $res1       = mysql_query($sql1);
        
        while ($row1 = mysql_fetch_array($res1)) {
            //$a['parentid'] = $row1['parentid'];
            $d['parentitem'] = $row1['category'];
            
            $c   = array_push($return_arr, $d);
            $arr = explode(',', $row1['list']);
            for ($i = 0; $i < count($arr); $i++) {
                $a['categoryitem'] = $arr[$i];
                $b                 = array_push($return_arr, $a);
                
            }
            
            
            
        }
        
        
        echo json_encode($return_arr);
        
    }
    
    function constituencies($args, $cid, $cname)
    {
        
        
        
        $conn2 =mysql_connect ("dandmudik.ipagemysql.com","varicoinguest","8-&q ICHhW 0*&Z x|4u }_%] b\H1gUeSt") or die ("unable to connect with the database");
   
    
	 mysql_select_db ("varicoin_vari",$conn2)or die ("unable to select database");
        
        $return_arr = array();
        $a          = array();
        $d          = array();
        $sql1       = "select id,name,parentid from states where id IN(" . $cid . ") ORDER BY name";
        $res1       = mysql_query($sql1);
        
        while ($row1 = mysql_fetch_array($res1)) {
            
            //$a['parentid'] = $row1['parentid'];
            $d['constname'] = $row1['name'];
            
            $c = array_push($return_arr, $d);
            
            
            $sql2 = "select * from constituencies where parent_name=" . $row1['id'] . " ORDER BY name";
            $res2 = mysql_query($sql2);
            
            while ($row2 = mysql_fetch_array($res2)) {
                $a['const_name'] = $row2['name'];
                
                $b = array_push($return_arr, $a);
                
            }
            
            
            
        }
        
        echo json_encode($return_arr);
        
    }
    function constituency($args)
    {
        
        
        
        $conn2 =mysql_connect ("dandmudik.ipagemysql.com","varicoinguest","8-&q ICHhW 0*&Z x|4u }_%] b\H1gUeSt") or die ("unable to connect with the database");
   
    
	 mysql_select_db ("varicoin_vari",$conn2)or die ("unable to select database");
        
        $return_arr = array();
        $a          = array();
        $d          = array();
        $sql1       = "select id,name,parentid from states where parentid not IN(0) ORDER BY name limit 139";
        $res1       = mysql_query($sql1);
        
        while ($row1 = mysql_fetch_array($res1)) {
            
            //$a['parentid'] = $row1['parentid'];
            $d['constname'] = $row1['name'];
            
            $c = array_push($return_arr, $d);
            
            
            $sql2 = "select * from constituencies where parent_name=" . $row1['id'] . " ORDER BY name";
            $res2 = mysql_query($sql2);
            
            while ($row2 = mysql_fetch_array($res2)) {
                $a['const_name'] = $row2['name'];
                
                $b = array_push($return_arr, $a);
                
            }
            
            
            
        }
        
        echo json_encode($return_arr);
        
    }
    
    
    
}

class status
{
    function failure($arg)
    {
        $response         = array();
        $response['code'] = '404 not found';
        if ($arg == 'xappidxcmd') {
            $response['status'] = 'Wrong API ID or Command';
        } else if ($arg == 'nopostvar') {
            $response['status'] = 'Bad request';
        } else if ($arg == 'nocmdfnd') {
            $response['status'] = 'No Command Found';
        } else if ($arg == 'noappiidfnd') {
            $response['status'] = 'No APIID Found';
        } else if ($arg == 'notfound') {
            $response['status'] = 'Not Found';
        }
        $response = json_encode($response, true);
        
        $logtext = "" . json_encode($log) . "\n";
        $myFile  = "log.txt";
        $fh = fopen($myFile, 'a') or die("can't open file");
        fwrite($fh, $logtext);
        fclose($fh);
        
        if ($logtext != '') {
            $log = json_decode($response, true);
            foreach ($log as $v) {
                echo $v . "<br/>";
            }
        }
        return $response;
        
    }
    function success()
    {
        $response           = array();
        $response['code']   = '200';
        $response['status'] = 'Success';
        $response           = json_encode($response, true);
        
        $logtext = "" . json_encode($response) . "\n";
        $myFile  = "log.txt";
        $fh = fopen($myFile, 'a') or die("can't open file");
        fwrite($fh, $logtext);
        fclose($fh);
        
        if ($logtext != '') {
            $log = json_decode($logtext, true);
            foreach ($log as $v) {
                echo $v . "<br/>";
            }
        }
        return $response;
    }
    
    /*$logtext = "" . json_encode($log) . "\n";
    $myFile = "log.txt";
    $fh = fopen($myFile, 'a') or die("can't open file");
    fwrite($fh, $logtext);
    fclose($fh);
    
    if ($logtext != '') {
    $log = json_decode($logtext, true);
    foreach ($log as $v) {
    echo $v . "<br/>";
    }
    }*/
}
?>
