<?php
$to      = 'nikileshrolla@gmail.com';
$subject = 'You got a reply for ad http://vari.co.in/post.php?postid=';
$message = 'You got a reply from (Name)' ."\r\n".' Mobile Number :';
$headers = 'From: Vari Team <nikileshrolla@gmail.com >' . "\r\n" .
    'Reply-To: nikileshrolla@gmail.com' . "\r\n" .
    'X-Mailer: PHP/' . phpversion();


$mail = mail($to, $subject, $message, $headers);
if($mail)
	echo "success";
else
	echo "Fail";
?>