<?php
$data = json_decode( file_get_contents('php://input') );
include_once('db.php');

$smsQuery = mysql_query("select id from sms_posts where number='".$data->mobile ."'  and title='".$data->message."'");

$rowsms  = mysql_fetch_array($smsQuery);
$smsFirebaseQuery = mysql_query("select id from sms_posts_firebase where number='".$data->mobile."' and message='".$data->message."' and item=".$data->item."");
$rowsmsFirebase  = mysql_fetch_array($smsFirebaseQuery);

//$sms_info = mysql_num_rows($smsQuery);
$sms_info = mysql_num_rows($smsFirebaseQuery);

$dsql = mysql_query("select id from states where name like '%".$data->district."%' limit 1");
$drow = mysql_fetch_array($dsql);

$isql = mysql_query("select id from categories where category like '%".$data->item."%' limit 1");
$irow = mysql_fetch_array($isql);
if($sms_info < 1)
{

$time = strtotime($data->date);
	$date = date('Y-m-d H:i:s', $time);
/*$insert = mysql_query("INSERT INTO  `sms_posts` (`number` ,  `title` ,  `item` ,  `district` ,  `location` ,  `other` ,  `user_id` ,  `createdon`, `mode` ,  `views` )VALUES ( '".$data->mobile."',  '".$data->message."',  ".$irow[0].",  ".$drow[0].",  '".$data->location."', NULL ,  '14', '".$date."', 'Selling',  '1');");*/
		 $insert = mysql_query("INSERT INTO  `sms_posts_firebase` (`smsid`,`message` ,  `item` ,  `sub_category` ,  `category` ,  `location` ,  `district` ,  `state` ,  `price` ,  `pricemode` ,  `quantity` ,  `otherpricemode` ,  `othersoldby` , `soldby` ,  `name` ,  `mobile` ,  `date` ) VALUES (".$rowsms['id'].",'".$data->message."',  '".$data->item."',  '".$data->subcat."',  '".$data->cat."',  '".$data->location."',  '".$data->district."',  '".$data->state."',  '".$data->price."',  '".$data->pricemode."','".$data->quantity."', '".$data->otherpricemode."', '".$data->othersoldby."',  '".$data->soldby."',  '".$data->name."', '".$data->mobile."', '".$data->date."');"); 
		
		if($insert)
		{
		
			echo "1 Row Inserted";
	
		}
	
}

else
{
	$time = strtotime($data->date);
	$date = date('Y-m-d H:i:s', $time);
	$update = mysql_query("UPDATE  `sms_posts` SET  `createdon` =  '".$date."' WHERE  `id` =".$rowsms['id']." LIMIT 1 ;");
	if($update)
		{
		
			echo "1 Row Updated";
	
		}
/* 	$update = mysql_query("UPDATE  `sms_posts_firebase` SET  `smsid` =  ".$rowsms['id']." WHERE  `id` =".$rowsmsFirebase['id']." LIMIT 1 ;"); */
}
	
	








?>