<?php

$conn2 =mysql_connect ("dandmudik.ipagemysql.com","varicoinguest","8-&q ICHhW 0*&Z x|4u }_%] b\H1gUeSt") or die ("unable to connect with the database");
   
    
	 mysql_select_db ("varicoin_vari",$conn2)or die ("unable to select database");
	 
	  
?>	  