<?php
@session_start();
class ajax {

    function __construct() {
        include("includes/paths.php");
        include_once($includesPath . "db.class.php");
        $this->db = new Db();
    }
    
    public function getContact($postid, $postType){
    	if(!empty($postType) && $postType=='sms'){
    		$contact=$this->db->getvalue("select number from sms_posts where id='{$postid}'");
    	} else {
    		$contact=$this->db->getvalue("select contact_info from posts where id='{$postid}'");
    	}
        
        if($contact){
            return $contact;
        }else{
        	return 'No Contact Found';
        }
    } 
    
    
    public function getDistricts($stateid){
    	
        $arr= $this->db->getRecords("name, id", "states", "WHERE parentid='{$stateid}'");
        return json_encode($arr);
    }

    
    public function getAssemblies($districtids){
        
        $records = $this->db->getRecords("constituencyid, constituency, district, districtid", "view_locations", "where districtid IN ({$districtids}) order by districtid;");
        $recordCount = count($records);
        for($i=0;$i<$recordCount;$i++){
            if(!in_array($records[$i]['district'], $dummyArr)){
                $dummyArr[] = $records[$i]['district'];
                $districtArr['districts'][] = array($records[$i]['district'], $records[$i]['districtid']);
            }
            $assembliesArr['assemblies'][$records[$i]['districtid']][] = array($records[$i]['constituency'], $records[$i]['constituencyid']);
        }
        return array($districtArr, $assembliesArr);
    }
    
}
