<?php
@session_start();
class forms
{
	function __construct()
	{
		include("includes/paths.php");
		include($includesPath."db.class.php");
		$this->db = new Db();
	}
	public function mainCategory($select)
	{
		$x='<select name="categoryid[]" title="Press Ctrl to select Sub categories."  id="categoryid" class="fld1" onChange="javascript:getSubCategories(this.value)"><option value="">Select the Category/Sub Category</option>';
		$result=$this->db->getStates("select id,category from categories where parentid='0' order by category");
		while($re=mysql_fetch_row($result))
			{		
			$x.="<optgroup id='optGrp1' label='$re[1]'>";
			$result1=$this->db->getStates("select id,category from categories where parentid='$re[0]' order by category");
			while($re1=mysql_fetch_row($result1))
				{
				if($re1[0]==$select)	
				$x.="<option title='Press Ctrl to select Sub categories.' value=$re1[0] selected=selected>".$re1[1]."</option>";
			else
				$x.="<option title='Press Ctrl to select Sub categories.' value=$re1[0]>".$re1[1]."</option>";
			
				}
			$x.="</optgroup>";
			}
		 $x.='</select>';
		return $x;
	}
	
	public function MainCategories($select)
	{
		$x='<select name="categoryid" id="categoryid" class="fld1" onChange="javascript:getSubCategories(this.value)"><option value="">Select the Category/Sub Category</option>';
		$result=$this->db->getStates("select id,category from categories where parentid='0' order by category");
		while($re=mysql_fetch_row($result))
			{		
			$x.="<optgroup id='optGrp1' label='$re[1]'>";
			$result1=$this->db->getStates("select id,category from categories where parentid='$re[0]' order by category");
			while($re1=mysql_fetch_row($result1))
				{
				if($re1[0]==$select)	
				$x.="<option value=$re1[0] selected=selected>".$re1[1]."</option>";
			else
				$x.="<option value=$re1[0]>".$re1[1]."</option>";
			
				}
			}
		 $x.='</select>';
		return $x;
	}
	
	public function subCategory($id,$select)
	{

		$x='<select title="Press Ctrl to select multiple items."  name="cropid[]" id="cropid" class="fld1" multiple="" size="3">';
		for($i=0;$i<sizeof($id);$i++){
		
			$result1=$this->db->getStates("select category,id from categories where id={$id[$i]} order by category");
			while($res2 = mysql_fetch_row($result1)){
				$x.="<optgroup id='optGrp1' label='{$res2[0]}'>";
				$cate = $res2[1];
			}
			
			$result=$this->db->getStates("select id,category from categories where parentid={$id[$i]} order by category");
			while($re=mysql_fetch_row($result))
			{
				if($re[0]==$select)	
					$x.="<option title='Press Ctrl to select multiple items.' value=$re[0]_$cate selected=selected >".$re[1]."</option>";
				else
					$x.="<option title='Press Ctrl to select multiple items.' value=$re[0]_$cate>".$re[1]."</option>";
			}
			$x.='</optgroup>';
		}
		 $x.='</select><span style="color: #767676; line-height: 14px; font-size: 10px;">Press Ctrl to select multiple items.</span>';
		return $x;
	}
	
	public function assembly($district, $select)
	{
		$x='<select name="assemblyid" class="fld1">';
		for($i=0;$i<sizeof($district);$i++){
			$result1=$this->db->getvalue("select name from states where id='{$district}' order by name");
			$x.="<optgroup id='optGrp1' label='{$result1}'>";
			$result=$this->db->getStates("select id,name from constituencies where parent_name='{$district}' order by name");
			while($re=mysql_fetch_row($result))
			{
				if($re[0]==$select)	
					$x.="<option value=$re[0]_$district selected=selected >".$re[1]."</option>";
				else
					$x.="<option value=$re[0]_$district>".$re[1]."</option>";
			}
			$x.='</optgroup>';
		}
     $x.='</select></label></td></tr>';
	return $x;
	}
	
	public function subItems($id,$select)
	{
		$x='<select name="cropid" id="cropid" class="fld1">';
		$result=$this->db->getStates("select id,category from categories where parentid={$id} order by category");
		while($re=mysql_fetch_row($result))
		{
			if($re[0]==$select)	
				$x.="<option value=$re[0] selected=selected >".$re[1]."</option>";
			else
				$x.="<option value=$re[0]>".$re[1]."</option>";
		}	
		 $x.='</select>';
		return $x;
	}
	
	public function state($select)
	{
	$x='<select title="Press Ctrl to select multiple districts."  name="districtid[]" id="districtid" class="fld1" onChange="javascript:getAssemblies(this.value)"><option value="">Select the District</option>';
	$result=$this->db->getStates("select id,name from states where parentid='1' order by name");
	while($re=mysql_fetch_row($result))
		{		
		$x.="<optgroup id='optGrp1' label='$re[1]'>";
		$result1=$this->db->getStates("select id,name from states where parentid='$re[0]' order by name");
		while($re1=mysql_fetch_row($result1))
			{
			if($re1[0]==$select)	
			$x.="<option title='Press Ctrl to select multiple districts.'  value=$re1[0] selected=selected >".$re1[1]."</option>";
			else
			$x.="<option title='Press Ctrl to select multiple districts.' value=$re1[0]>".$re1[1]."</option>";
		
			}
		$x.="</optgroup>";
		}
     $x.='</select>';
	return $x;
	}
	
	
	public function states($select)
	{
	$x='<select name="districtid" id="districtid" class="fld1" onChange="javascript:getAssemblies(this.value)"><option value="">Select the District</option>';
	$result=$this->db->getStates("select id,name from states where parentid='1' order by name");
	while($re=mysql_fetch_row($result))
		{		
		$x.="<optgroup id='optGrp1' label='$re[1]'>";
		$result1=$this->db->getStates("select id,name from states where parentid='$re[0]' order by name");
		while($re1=mysql_fetch_row($result1))
			{
			if($re1[0]==$select)	
			$x.="<option title='Press Ctrl to select multiple districts.'  value=$re1[0] selected=selected >".$re1[1]."</option>";
			else
			$x.="<option title='Press Ctrl to select multiple districts.' value=$re1[0]>".$re1[1]."</option>";
		
			}
		$x.="</optgroup>";
		}
     $x.='</select>';
	return $x;
	}
	
	public function assemblies($district, $select)
	{
	$x='<select title="Press Ctrl to select Assemblies." name="assemblyid[]" id="assemblyid" class="fld1" multiple="" size="10">';
	for($i=0;$i<sizeof($district);$i++){
	
		$result1=$this->db->getvalue("select name from states where id='{$district[$i]}' order by name");
		$x.="<optgroup id='optGrp1' label='{$result1}'>";
		$result=$this->db->getStates("select id,name from constituencies where parent_name='{$district[$i]}' order by name");
		while($re=mysql_fetch_row($result))
		{
			if($re[0]==$select)	
				$x.="<option title='Press Ctrl to select Assemblies.' value=$re[0]_$district[$i] selected=selected >".$re[1]."</option>";
			else
				$x.="<option title='Press Ctrl to select Assemblies.' value=$re[0]_$district[$i]>".$re[1]."</option>";
		}
		$x.='</optgroup>';
	}
     $x.='</select><span style="color: #767676; line-height: 14px; font-size: 10px;">Press Ctrl to select Assemblies.</span></label></td></tr>';
	return $x;
	
	}
	public function getValues($postid)
		{
		return $this->db->getvalues("select 
					posts.userid
					,posts.assemblyid
					,posts.districtid
					,posts.categoryid
					,posts.cropid
					,posts.subject
					,posts.message
					,posts.price
					,posts.quantity
					,posts.location
					,posts.contact_info
					,posts.mode 
					,uploads.name
					,uploads.id
					from 
					posts
					LEFT JOIN uploads ON (uploads.postid=posts.id AND uploads.type=1)
					where posts.id='$postid' LIMIT 1");
		}
	
	public function getContact($postid, $mode){
		
		$contact=$this->db->getvalue("select contact_info from posts where id='{$postid}'");
		if($contact){
			return $contact;
		}
	
	}
	
}

