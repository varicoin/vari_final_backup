<?php
@session_start();
class market {

    function __construct() {
        include("includes/paths.php");
        include($includesPath . "db.class.php");
        $this->db = new Db();
    }

	  
	public function subItems($id,$select)
	{
		$x='<select name="cropid" class="fld1">';			
		$result=$this->db->getStates("select id,category from categories where parentid={$id} order by category");
		while($re=mysql_fetch_row($result))
		{
			if($re[0]==$select)	
				$x.="<option value=$re[0] selected=selected >".$re[1]."</option>";
			else
				$x.="<option value=$re[0]>".$re[1]."</option>";
		}	
		 $x.='</select>';
		return $x;
	}
	
	
    public function getCategoryName($id) {
        return $this->db->getvalue("select category from categories where id='$id'");
    }

    public function getState($id) {
        return $this->db->getvalue("select name from states where id='$id'");
    }

    public function subCategoryid($categoryid) {
        return $this->db->getvalue("select id from categories where parentid='$categoryid' order by category LIMIT 1");
    }

    public function getId($name, $field) {
        return $this->db->getvalue("select $field from states where image_name='$name'");
    }

    
	public function assemblies($district, $select)
	{
		$x='<select name="assemblyid" class="fld1">';
		$x.="<option value=''>Select Assembly</option>";
	
		$result1=$this->db->getvalue("select name from states where id='{$district}' order by name");
		
		$result=$this->db->getStates("select id,name from constituencies where parent_name='{$district}' order by name");
		while($re=mysql_fetch_row($result))
		{
			if($re[0]==$select)	
				$x.="<option value=$re[0]_$district[$i] selected=selected >".$re[1]."</option>";
			else
				$x.="<option value=$re[0]_$district[$i]>".$re[1]."</option>";
		}
	
     $x.='</select></label></td></tr>';
	return $x;
	}
	
	public function getImages($id) {
        $result = $this->db->getStates("SELECT
                id
                ,name
                ,CONCAT('market_uploads/',location)
                FROM
                    market_uploads
                WHERE
                    marketid={$id} AND type=0");
        while ($re = mysql_fetch_row($result)) {
            $arr[] = array($re[1], $re[2], $re[0]);
        }
        return $arr;
    }
	
	public function getVideos($id){
		$result = $this->db->getStates("SELECT
                id
                ,name
                FROM
                    market_uploads
                WHERE
                    marketid={$id} AND type=1");
        while ($re = mysql_fetch_row($result)) {
            $arr[] = array($re[0],$re[1]);
        }
        return $arr;
	}   
    

    public function state($select) {
        $x = '<select name="districtid" id="districtid" class="fld1" onChange="javascript:getAssembly(this.value)">';
        $result = $this->db->getStates("select id,name from states where parentid='1' order by name");
		$x.="<option value='' selected=selected >Select State/District</option>";
        while ($re = mysql_fetch_row($result)) {
            $x.="<optgroup id='optGrp1' label='$re[1]'>";
			$result1=$this->db->getStates("select id,name from states where parentid='$re[0]' order by name");
			while($re1=mysql_fetch_row($result1))
			{
				if($re1[0]==$select)	
					$x.="<option value=$re1[0] selected=selected >".$re1[1]."</option>";
				else
					$x.="<option value=$re1[0]>".$re1[1]."</option>";			
			}
			$x.="</optgroup>";
        }
        $x.='</select>';
        return $x;
    }

    
    public function MainCategories($select)
	{
		$x='<select name="categoryid" id="marketcategoryid" class="fld1"><option value="">Select the Category/Sub Category</option>';
		$result=$this->db->getStates("select id,category from categories where parentid='0' order by category");
		while($re=mysql_fetch_row($result))
			{		
			$x.="<optgroup id='optGrp1' label='$re[1]'>";
			$result1=$this->db->getStates("select id,category from categories where parentid='$re[0]' order by category");
			while($re1=mysql_fetch_row($result1))
				{
				if($re1[0]==$select)	
				$x.="<option title='Press Ctrl to select Sub Categories.' value=$re1[0] selected=selected>".$re1[1]."</option>";
			else
				$x.="<option title='Press Ctrl to select Sub Categories.' value=$re1[0]>".$re1[1]."</option>";			
				}
			}
		 $x.='</select>';
		return $x;
	}   

	public function categoriesList(){
		$list = '';
		$strQuery = "select id,category from categories where parentid='0' order by category";
		$resultSet = $this->db->getStates( $strQuery );
		while($record = mysql_fetch_row( $resultSet ) ) {
			$list .= "<a href='market.php?mode=category&category={$record[0]}'><li>{$record[1]}</li></a>";
		}
		return $list;
	}
	public function getComments($postid) {
        $x = '';
        $result = $this->db->getStates("select u.id,u.comment,s.first_name,DATE_FORMAT(u.posted_on,'%d/%m/%Y'),u.rating from market_comments u,users s where u.posted_by=s.id and u.posid={$postid} order by u.posted_on");
        $counts['+ve'] = 0;
        $counts['-ve'] = 0;
        $counts['neutral'] = 0;
        $color['-ve'] = 'red';
        $color['neutral'] = 'blue';
        $color['+ve'] = 'green';
        while ($re = mysql_fetch_row($result)) {
            $rating = ($re[4]==1)?'+ve':(($re[4]==0)?'neutral':'-ve');

            $counts[$rating]++;
            $x.='<div style="clear:both;"></div>
					<div style="background:url(images/comment_shadow.png) no-repeat left top;height:21px;width:905px;background-color:none;"></div>
					<div class="market_box_left" style="width:100%;">
						<div class="line_black">
							<span style="border-radius:10px;line-height:18px;text-align:justify;">
								<span style="color:'.$color[$rating].';">
								<strong style="color:#060;margin-bottom:0px;padding-bottom:0px;">'.$re[2].' on '.$re[3].'</strong>
                                                                  <b>  <span style="text-align:left;color:'.$color[$rating].';margin-left:300px;">'.$rating.'</span>  <br />
								'.$re[1].'</b></span></span></p>
						</div>
					</div>';
    	}
        $y = '<span style="text-align:left;color:green;margin-left:500px;">+ve('.$counts['+ve'].')</span>&nbsp;&nbsp;&nbsp;
            <span style="text-align:left;color:blue;">neutral('.$counts['neutral'].')
                </span>&nbsp;&nbsp;&nbsp;<span style="text-align:left;color:red;">-ve('.$counts['-ve'].')</span>';
        return array($x, $y);
    }

    public function getRatingSum($postid) {
        $x = '';
        $result = $this->db->getStates("select u.rating from market_comments u,users s where u.posted_by=s.id and u.posid={$postid} order by u.posted_on");
        $counts['+ve'] = 0;
        $counts['-ve'] = 0;
        $counts['neutral'] = 0;
        while ($re = mysql_fetch_row($result)) {
			$rating = ($re[0]==1)?'+ve':(($re[0]==0)?'neutral':'-ve');
            $counts[$rating]++;

    	}
        $y = '<img src="html/market/images/feedback-pos.png" height="28" width="28" title="Positive" />'.$counts['+ve'].'&nbsp;
					<img src="html/market/images/feedback-nut.png" height="28" width="28" title="Neutral" />'.$counts['neutral'].'&nbsp;
					<img src="html/market/images/feedback-neg.png" height="28" width="28" title="Negative" />'.$counts['-ve'].'';
        return $y;
    }
	
	
	public function getPost($id) {
			$arr=null;
            
        $result = $this->db->getStates("select u.id,CONCAT(u.id,'. ',u.subject)
		                               ,u.message
									   ,u.contact_info
									   ,u.contact_address
									   ,u.price
									   ,u.quantity
									   ,u.postedby
									   ,u.postedon
									   ,u.stock
									   ,u.cropid
									   ,u.views
									   ,u.mode
		                               ,CONCAT('<a href=index.php>India</a><a>',u.state_name,'</a><a>',u.district,'</a><a>',u.constituency,'</a><a >Categories</a><a >',u.category,'</a><a>',u.subcategory,'</a><a >',u.crop,'</a>') AS link,IF(u.mode='Selling',u.offer_price,'&nbsp;') from market_view_list u,users s where u.id='$id' and s.id=u.userid");
			
			
		$result1 = $this->db->getStates("UPDATE market SET views=views+1 where id='$id'");
		if(mysql_num_rows($result)<1){
			$x= '<h2 style="font-size:12px;font-weight:bold;font-family:tahoma;border-bottom:1px dashed;padding-bottom:3px;">Post not found</h2>';
		}
		else{
			while ($re = mysql_fetch_row($result)) {
				if(isset($_SESSION['isAdmin']) && $_SESSION['isAdmin']==TRUE){
					$linkforEdit = "<a href='marketEdit.php?postid={$id}'>Edit</a>";
				}
				else{
					$linkforEdit = '&nbsp;';
				}
                                
                                $arr[0] = trim($re[5]);
                                $arr[1] = trim($re[6]);
                                $arr[2] = trim($re[3]);
                                $arr[3] = trim($re[4]);
                                $arr[4] = trim($re[8]);
                                $arr[5] = trim($re[11]);
                                $arr[6] = trim($re[2]);
                                $arr[7] = trim($re[1]);
                                $arr[8] = trim($re[9]);
                                $arr[9] = trim($re[12]);
                                //$arr[10] = trim($re[12]);
                                $arr[10] = $this->getRatingSum($id);
                                $arr[11] = trim($re[10]);
                                $arr[12] = trim($re[13]);
                                $arr[13] = trim($re[7]);
                                $arr[14] = trim($re[14]);
                                $arr[15] = (trim($re[9])=='Open' || trim($re[9])=='Instock')?'blue':'red';
                                //$arr[12] = $this->getRatingSum($id);				
             $i++;
			}
		}
        
        return $arr;
    }
	
	public function marketList($mode=null, $id=null,$html='list',$limit=''){
		
		$records = 0;
		switch($mode){
			case 'crop':
				$strQuery = "SELECT id, SUBSTRING(subject,1,24), SUBSTRING(price,1,24), location, mode,SUBSTRING(offer_price,1,24), userid from market_view_list WHERE cropid={$id} GROUP BY id {$limit};";
				$resultSet = $this->db->getStates( $strQuery );
				$records = mysql_num_rows($resultSet);
				$welcomeText = "Market Advertisements found!";
				break;
			case 'category':
				$strQuery = "SELECT id, SUBSTRING(subject,1,24), SUBSTRING(price,1,24), location, mode,SUBSTRING(offer_price,1,24), userid from market_view_list WHERE categoryid={$id} GROUP BY id {$limit};";
				$resultSet = $this->db->getStates( $strQuery );	
				$records = mysql_num_rows($resultSet);
				$welcomeText = "No Market Advertisements found!";
				break;
			case 'low':
				$strQuery = "SELECT id, SUBSTRING(subject,1,24), SUBSTRING(price,1,24), location, mode,SUBSTRING(offer_price,1,24), userid from market_view_list WHERE division=2 GROUP BY id {$limit};";
				$resultSet = $this->db->getStates( $strQuery );	
				$records = mysql_num_rows($resultSet);
				$welcomeText = "Low Price Market Advertisements found!";
				break;
			case 'bumper':
				$strQuery = "SELECT id, SUBSTRING(subject,1,24), SUBSTRING(price,1,24), location, mode,SUBSTRING(offer_price,1,24), userid  from market_view_list WHERE division=1 GROUP BY id {$limit};";
				$resultSet = $this->db->getStates( $strQuery );	
				$records = mysql_num_rows($resultSet);
				$welcomeText = "Bumper Offer Market Advertisements found!";
				break;
			case 'new':
				$strQuery = "SELECT id, SUBSTRING(subject,1,24), SUBSTRING(price,1,24), location, mode,SUBSTRING(offer_price,1,24), userid  from market_view_list  GROUP BY id ORDER BY postedon {$limit};";
				$resultSet = $this->db->getStates( $strQuery );	
				$records = mysql_num_rows($resultSet);
				$welcomeText = "Most Recent Market Advertisements found!";
				break;
			case 'list':
				$strQuery = "SELECT id, SUBSTRING(subject,1,24), SUBSTRING(price,1,24), location, mode,SUBSTRING(offer_price,1,24), userid  from market_view_list GROUP BY id {$limit};";
				$resultSet = $this->db->getStates( $strQuery );
				$welcomeText = "Recent Market Advertisements";
		}
		if($mode==null || $records<1 && $html=='list'){
			$strQuery = "SELECT id, SUBSTRING(subject,1,24), SUBSTRING(price,1,24), location, mode,SUBSTRING(offer_price,1,24), userid from market_view_list GROUP BY id {$limit};";
			$resultSet = $this->db->getStates( $strQuery );
			$welcomeText = ($mode==null)?"Recent Market Advertisements":"No Market Advertisements found!";
		}
		if($html=='list'){
			$htmlContent = '<div class="right-heading">'.$welcomeText.'</div>
				<div class="main_products">';
			while($record = mysql_fetch_row( $resultSet ) ) {
                                $style=($record[4]=='Buying')?' style="color:green !important;text-decoration:none !important;"':'';
				$htmlContent .= "<div class='items'>
					
						<h2>{$record[1]}</h2>
						<p><img src='market_uploads/{$record[3]}' alt='Image' height='148' width='186' /></p>
						<h1{$style}>{$record[2]}</h1>
						<div class='details-but'><a href='marketpost.php?postid={$record[0]}'>{$record[4]}</a>";
				$htmlContent .= ($_SESSION['isAdmin']==TRUE || ($_SESSION['isMarketAccess']==true && $_SESSION['userid']==$record['6']))?" &nbsp; / &nbsp;<a href='marketEdit.php?postid={$record[0]}'>Edit</a> &nbsp; / &nbsp;<a href='market_submit.php?postid={$record[0]}&action=delete'>Delete</a>":'';
				$htmlContent .= "</div>
					</div>";
			}	
				$htmlContent .= '</div>';
		}elseif($html=='horizontal'){
			$htmlContent='';
			while($record = mysql_fetch_row( $resultSet ) ) {
				 $style=($record[4]=='Buying')?' style="color:green !important;text-decoration:none !important;"':'';
				$htmlContent.="<div class='items market_items_horizantal'>
					<h2>{$record[1]}<a href='marketpost.php?postid={$record[0]}'><img src='market_uploads/{$record[3]}' height='148' width='186' style='float:left;margin-right:0px;' class='img_market_Item' /></a></h2><h1 $style><span>{$record[2]}</span><br  /></h1>				
				</div>";
			}
		}elseif($html=='vertical'){
			$htmlContent='';
			while($record = mysql_fetch_row( $resultSet ) ) {
				$htmlContent .= "<div class='right_items'>
				  <p>{$record[1]}</p>
				  <a href='marketpost.php?postid={$record[0]}'><img src='market_uploads/{$record[3]}' height='111' width='109' /></a>
				  
				  <p><span style='text-decoration: line-through;'>{$record[2]}</span><br  />
					<span  style='font-weight:bold;color:#CC0000;'>{$record[5]}</span></p>
					</div>";
			}
		}
		return $htmlContent;
	}
	
	public function viewAds($mode,$arrVal,$stock_value){
		if(in_array($arrVal, array('new','low','bumper'))){
			$stock = " AND stock='{$stock_value}' ";
		}else{
			$stock='';
		}
		$strQuery = "SELECT id, SUBSTRING(subject,1,24), message, price, offer_price, stock, category, location, name from market_view_list WHERE mode='{$mode}'{$stock}GROUP BY id ORDER BY postedon LIMIT 10";
		$resultSet = $this->db->getStates( $strQuery );
		while($record = mysql_fetch_row( $resultSet ) ) {
			$html .= "<div style='padding:4px;text-align:left;border-bottom:#dbdbdb 1px solid;'>
					<table width='98%' border='0' cellspacing='0' cellpadding='0'>
					  <tr>
						<td width='32%' rowspan='2' valign='top'><img src='market_uploads/{$record[7]}' width='62' height='61' alt='{$record[8]}' /></td>
						<td colspan='3' style='font-size:15px;'><b>{$record[1]}</b></td>
					  </tr>
					  <tr>
						<td width='30%' style='font-size:16px;'>&nbsp;</td>
						<td width='2%'>&nbsp;</td>
						<td width='36%'><a href='marketpost.php?postid={$record[0]}'><img src='html/market/images/but-best-{$mode}.jpg' width='77' height='25' alt='Details'  style='margin-top:4px;'/></a></td>
					  </tr>
					</table>
				  </div>";
		}
		return $html;
		
	}
	
	public function getValues($postid)
	{
		return $this->db->getvalues("select 
					market.userid
					,market.assemblyid
					,market.districtid
					,market.subcategoryid
					,market.cropid
					,market.subject
					,market.message
					,market.price
					,market.quantity
					,market.location
					,market.contact_info
					,market.mode 
					,market.offer_price
					,market.stock
					,market.division
					,market.postedby
					from 
					market
					where market.id='$postid' LIMIT 1");
	}
	
	function getLeftCategoryList($sel=null,$menu=null,$cropid=null){
		
		$str='';
		$strQry1 = "SELECT id,category FROM categories WHERE parentid=0 ORDER BY category;";
		$resultSet1 = $this->db->getStates( $strQry1 );
		$i=1;
		while($record1 = mysql_fetch_row( $resultSet1 ) ) {
			if($sel==$record1[1] && $sel!=null){$selected='selected';}else{$selected='non-selected';}
			$str .= '<li>
				<h3 class="head selected"><a href="javascript:Sibllings('.$i.');">'.trim($record1[1]).'</a></h3>
				<ul id="xtraMenu'.$i.'" class="'.$selected.'">
					<li>
                    	<ul class="submenu">';
			$strQry2 = "SELECT id,category FROM categories WHERE parentid={$record1[0]} ORDER BY category;";
			$resultSet2 = $this->db->getStates( $strQry2 );
			while($record2 = mysql_fetch_row( $resultSet2 ) ) {
				if($menu==$record2[1] && $menu!=null){$selected_menu=' selected';}else{$selected_menu=' non-selected';}
				$str .= '<li>
                                <h4 class="head'.$selected.'"><a href="javascript:nextSibllings('.$record2[0].');">'.trim($record2[1]).'</a></h4>
                                <ul id="submenu'.$record2[0].'" class="'.$selected_menu.'">';
				$strQry3 = "SELECT id,category FROM categories WHERE parentid={$record2[0]} ORDER BY category;";
				$resultSet3 = $this->db->getStates( $strQry3 );
				while($record3 = mysql_fetch_row( $resultSet3 ) ) {
					if($cropid==$record3[0] && $cropid!=null){
						$str .= '<li><b><a href="market.php?mode=crop&crop='.$record3[0].'&sel='.trim($record1[1]).'&menu='.trim($record2[1]).'">'.$record3[1].'</a></b></li>';
					}else{
						$str .= '<li><a href="market.php?mode=crop&crop='.$record3[0].'&sel='.trim($record1[1]).'&menu='.trim($record2[1]).'">'.$record3[1].'</a></li>';
					}
				}
				$str .= '</ul>
                            </li>';
			}
			if($i==''){$i=1;}
			$i++;
			$str .= '</ul>
                    </li>
				</ul>
			</li>';
		}
		return $str;
	}
        public function viewAllPosts($districtid, $assemblyid, $subcategoryid, $cropid) {
        $strAssembly = null;
        $strCrop = null;
        $condition = "";
        $ampersand = false;
        if (!empty($districtid)) {
            $condition = "districtid IN ($districtid)";
            $ampersand = true;
        }
        if (!empty($assemblyid)) {
            $condition .= ($ampersand==TRUE)?' AND ':'';
			$assemblyid = explode(",",$assemblyid);
			for($i=0;$i<sizeof($assemblyid);$i++)
			{
				$assembly = explode("_",$assemblyid[$i]);
				$strAssembly .= $assembly[0].',';
			}
			$strAssembly = substr($strAssembly,0,strlen($strAssembly)-1);
            $condition .= "assemblyid IN ($strAssembly)";

            $ampersand = true;
        }
        if (!empty($subcategoryid)) {
            $condition .= ($ampersand==TRUE)?' AND ':'';
            $condition .= "categoryid IN ($subcategoryid)";
            $ampersand = true;
        }
        if (!empty($cropid)) {
            $condition .= ($ampersand==TRUE)?' AND ':'';
			$cropid = explode(",",$cropid);
			for($i=0;$i<sizeof($cropid);$i++) {
				$crop = explode("_",$cropid[$i]);
				$strCrop .= $crop[0].',';
			}
			$strCrop = substr($strCrop,0,strlen($strCrop)-1);
            $condition .= "cropid IN ($strCrop)";
        }
		$strQry = "SELECT 
				DISTINCT(id)
				,CONCAT('<a href=marketpost.php?postid=', id,'>',subject, '<\/a>' ) AS subject
                ,state_name AS first_name
                ,postedon AS date
                ,crop AS category
                ,constituency AS name
                ,district AS district_name
                ,mode AS type
                ,CONCAT( '<a href=marketpost.php?postid=', id, '>View<\/a>' ) AS action
                FROM
                market_view_list
                WHERE
            {$condition}
                ORDER BY postedon desc";
        $result = $this->db->getStates( $strQry );

        $arrPosts = array();
        $i=0;
        while ($record = mysql_fetch_assoc($result)) {
            $arrPosts[$i] = $record;
            $i++;
        }

        $json = json_encode($arrPosts);
        return $json;
    }

    public function viewAllPostIdPosts($postid){
        $strQry = "SELECT 
				CONCAT('<a href=marketpost.php?postid=', id,'>',subject, '<\/a>' ) AS subject
                ,state_name AS first_name
                ,postedon AS date
                ,crop AS category
                ,constituency AS name
                ,district AS district_name
                ,mode AS type
                ,CONCAT( '<a href=marketpost.php?postid=', id, '>View<\/a>' ) AS action
                FROM
                market_view_list
                WHERE
                id LIKE '%$postid'
				GROUP BY id
                ORDER BY postedon desc";
        $result = $this->db->getStates( $strQry );
		//echo $strQry;

        $arrPosts = array();
        $i=0;
        while ($record = mysql_fetch_assoc($result)) {
            $arrPosts[$i] = $record;
            $i++;
        }

        $json = json_encode($arrPosts);
        return $json;
    }
	
	public function getContact($postid, $mode){
		
		$contact=$this->db->getvalue("select contact_info from market where id='{$postid}'");
		if($contact){
			return $contact;
		}
	
	}

}