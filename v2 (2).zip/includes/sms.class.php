<?php
@session_start();
class sms {

    function __construct() {
        include("includes/paths.php");
        include_once($includesPath . "db.class.php");
        $this->db = new Db();
    }
    
    public function smsPostInsert($record){
    	$strQry = "'','".$record[0]."','".$record[1]."','".$record[2]."','".$record[3]."','".$record[5]."','','".$_SESSION['userid']."',now(),'".$record[4]."','0'";
    	$smsid = $this->db->fnInsert('sms_posts', $strQry);
    	if($smsid){
            return $smsid;
    	}
    	else{
    		return false;
    	}
    }
    
    public function sendMessage($message,$phone){
    	//Please Enter Your Details
    	return $this->db->smsDb($phone,$message);
    }
    
    public function getSMSPost($id,$template) {
        $arr = null;
        $i=0;
         $y = $this->getRatingSum($id);
		 $currentURL =  "http://{$_SERVER['HTTP_HOST']}{$_SERVER['REQUEST_URI']}";
        $result = $this->db->getStates("select id,CONCAT(id,'. ',title),number,createdon,item,district_name,mode,views,state_name,location,cropid,districtid from view_sms_posts where id='$id' LIMIT 1");
		$result1 = $this->db->getStates("UPDATE sms_posts SET views=views+1 where id='$id'");
		if(mysql_num_rows($result)<1){
			$x = '<h2 style="font-size:12px;font-weight:bold;font-family:tahoma;border-bottom:1px dashed;padding-bottom:3px;">Post not found</h2>';
		}
		else{
			while ($re = mysql_fetch_row($result)) {
                               // $template->replace('@title@', $re[1]);
				  $rand = rand(15,456);
				$salt = md5(time().$rand);
				
				$arr[0] = '<div class="line_black">
                <p><span style="color:#4d7100;"><strong>Message : </strong></span><br />'.trim($re[1]).'</p></div>';
                                $arr[2] = $re[9];
				$arr[1] = '<div class="line_black">
            	<p style="text-align:center;"><strong><a href="market.php?mode=crop&crop='.$re[5].'"><img src="css/images/market.jpg" width="219" height="28" alt="Market" /><a></strong>
                    <a target="_blank" href="http://www.facebook.com/share.php?u='.$currentURL.'" style="margin-left: 25px; margin-right: 15px;"><img src="css/fb_share.jpg" alt="fb share" height="25px"></a>
                        <a href="https://twitter.com/share" class="twitter-share-button" data-size="large" data-text="'.$re[1].' #vari #agriculture" data-url="'.$currentURL.'" data-hashtags="pfLu3dOJxvd1C75KnOTm5rcrJsYbFCNrbSldtEyaJtA">Tweet</a>
<script>!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0];if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src="//platform.twitter.com/widgets.js";fjs.parentNode.insertBefore(js,fjs);}}(document,"script","twitter-wjs");</script>
</p></div>
                <div class="box_Inner">
                <p><span style="color:#4d7100;"><strong>AD mode :</strong>&nbsp;&nbsp;<b>SMS POST</b></span><br />'.trim($re[6]).'</p></div>
                <div class="box_Inner">
                                <p><span style="color:#4d7100;"><strong>Item :</strong></span><br />'.trim($re[4]).'</p></div>
                <div class="box_Inner">
                                <p><span style="color:#4d7100;"><strong>State:</strong></span><br />'.trim($re[8]).'</p></div>
                <div class="box_Inner">
                                <p><span style="color:#4d7100;"><strong>District :</strong></span><br />'.trim($re[5]).'</p></div>
                <div class="box_Inner">
                                <p><span style="color:#4d7100;"><strong>Location:</strong></span><br />'.trim($re[9]).'</p></div>
                <div class="box_Inner">
                                <p id="coninfo"><span style="color:#4d7100;"><strong>Number :</strong></span><br /> <br /><img id="spamimage" src="CaptchaSecurity.php?salt='.$salt.'" height="41" width="60"/> <br> <input style="color:#000000 !important;" type="text" size="7" name="securitycode"> &nbsp;&nbsp; <b>Enter captcha for</b><a href="javascript:void(0);" onclick=javascript:getnumber("'.$salt.'","'.$id.'") style="display: block; margin-left: 102px;">Contact Information</a></p></div>
                <div class="box_Inner">
                                <p><span style="color:#4d7100;"><strong>Posted On :</strong></span><br />'.trim($re[3]).'</p></div>
                <div class="box_Inner">
                                <p><span style="color:#4d7100;"><strong>Post ID :</strong></span><br />'.trim($re[0]).'</p></div>
                                <div class="box_Inner">
                                <p><span style="color:#4d7100;"><strong>Total Post views :</strong></span><br />'.trim($re[7]).'</p></div>
                <div><a href="smsfeedback.php?postid='.trim($re[0]).'"><img src="css/images/feedback.jpg" width="97" height="28" alt="feed back" /></a>'.$y.'</div>
                            </div>';
				$i++;
				$arr[2] = $re[10];
				$arr[3] = $re[12];
				$arr[4] = (trim($re[6])=='Buying')?'Selling':'Buying';
			}
		}
               
        return $arr;
    }

    public function getMarketposts(){

         '<li>
		<div class="items">
                	<h2>Mango Pickel</h2>
                    <p><img src="images/item-3.jpg" height="148" width="186" /></p>
                    <h1>$29.25</h1>
                    <a href="#"><div class="cart-button">Add to Cart</div></a>
                    <div class="details-but"><a href="#">Details</a></div>
                </div>
	</li>';

    }

    public function getRatingSum($postid) {
        $yux = '';
        $result = $this->db->getStates("select rating from sms_comments where posid={$postid}");
        $counts['+ve'] = 0;
        $counts['-ve'] = 0;
        $counts['neutral'] = 0;
        while ($re = mysql_fetch_row($result)) {
            $rating = ($re[0]==1)?'+ve':(($re[0]==0)?'neutral':'-ve');
            $counts[$rating]++;
    	}
        $y = '<b><img src="html/market/images/feedback-pos.png" height="28" width="28" title="Positive" />'.$counts['+ve'].'&nbsp;
            <img src="html/market/images/feedback-nut.png" height="28" width="28" title="Neutral" />'.$counts['neutral'].'&nbsp;
			<img src="html/market/images/feedback-neg.png" height="28" width="28" title="Negative" />'.$counts['-ve'].'</b>';
        return $y;
    }

    public function getSMSComments($postid) {
        $x = '';
        $result = $this->db->getStates("select u.id,u.comment,s.first_name,DATE_FORMAT(u.posted_on,'%d/%m/%Y'),u.rating from sms_comments u,users s where u.posted_by=s.id and u.posid={$postid} order by u.posted_on");
        $counts['+ve'] = 0;
        $counts['-ve'] = 0;
        $counts['neutral'] = 0;
        $color['-ve'] = 'red';
        $color['neutral'] = 'blue';
        $color['+ve'] = 'green';
        while ($re = mysql_fetch_row($result)) {
            $rating = ($re[4]==1)?'+ve':(($re[4]==0)?'neutral':'-ve');
            $counts[$rating]++;
            $x.='<div style="clear:both;"></div>
					<div style="background:url(images/comment_shadow.png) no-repeat left top;height:21px;width:905px;background-color:none;"></div>
					<div class="market_box_left" style="width:100%;">
						<div class="line_black">
							<span style="border-radius:10px;line-height:18px;text-align:justify;">
								<span style="color:'.$color[$rating].';">
								<strong style="color:#060;margin-bottom:0px;padding-bottom:0px;">'.$re[2].' on '.$re[3].'</strong>
                                                                   <b> <span style="text-align:left;color:'.$color[$rating].';margin-left:300px;">'.$rating.'</span>  <br />
								'.$re[1].'</b></span></span></p>
						</div>
					</div>';
    	}
        $y = '<span style="text-align:left;color:green;margin-left:500px;">+ve('.$counts['+ve'].')</span>&nbsp;&nbsp;&nbsp;
            <span style="text-align:left;color:blue;">neutral('.$counts['neutral'].'</span>&nbsp;&nbsp;&nbsp;
                <span style="text-align:left;color:red;">-ve('.$counts['-ve'].')</span>';
        return array($x, $y);
    }


        public function marketList($mode=null, $id=null){

		$records = 0;
		if($mode == 'crop'){
			$strQuery = "SELECT id, subject, message, price, offer_price, stock, category, location, name,mode from market_view_list WHERE cropid={$id} GROUP BY id ";
			$resultSet = $this->db->getStates( $strQuery );
			$records = mysql_num_rows($resultSet);
			//$welcomeText = "No Posts found!";
		}
		elseif($mode == 'category'){
			$strQuery = "SELECT id, subject, message, price, offer_price, stock, category, location, name,mode from market_view_list WHERE categoryid={$id} GROUP BY id";
			$resultSet = $this->db->getStates( $strQuery );
			$records = mysql_num_rows($resultSet);
			//$welcomeText = "No Posts found!";
		}elseif($mode=='random'){
                         $strQuery = "SELECT id, subject, message, price, offer_price, stock, category, location, name,mode from market_view_list  ORDER BY RAND() LIMIT 4";
			$resultSet = $this->db->getStates( $strQuery );
			$records = mysql_num_rows($resultSet);
			//$welcomeText = "No Posts found!";
                }
		if($mode==null || $records<1){
			$strQuery = "SELECT id, subject, message, price, offer_price, stock, category, location, name,mode from market_view_list  ORDER BY RAND() LIMIT 4";
			$resultSet = $this->db->getStates( $strQuery );
			$welcomeText = ($mode==null)?"Recent Posts":"No Posts found";
		}
		$htmlContent = null;
		while($record = mysql_fetch_row( $resultSet ) ) {
                        if($mode=='random'){
                            $htmlContent .= '<div class="items">
                                    <h2>'.$record[1].'</h2>
                                <p><img src="market_uploads/'.$record[7].'" height="148" width="186" /></p>
                                <h1>'.$record[4].'</h1>
                                <a href="#"></a>
                                <div class="details-but"><a href="marketpost.php?postid='.$record[0].'">'.$record[9].'</a></div>
                            </div>';
																
                         }else{
			$htmlContent .= '<li>
                            <div class="items">
                                    <h2>'.$record[1].'</h2>
                                <p><img src="market_uploads/'.$record[7].'" height="148" width="186" /></p>
                                <h1>'.$record[4].'</h1>
                                <a href="#"></a>
                                <div class="details-but"><a href="marketpost.php?postid='.$record[0].'">'.$record[9].'</a></div>
                            </div>
                    </li>';
                    }

		}
		return $htmlContent;
	}


    public function getSMSPosts(){
        $strQry = <<<Qry
                 SELECT id
                ,CONCAT( "<a href=smspost.php?postid=", id,">",title, "<\/a>" ) AS title
                ,item AS item
                ,district_name
                ,'xxxx' AS phone
                ,createdon AS date
                ,CONCAT( "<a href=smspost.php?postid=", id,">View<\/a>" ) AS action
                ,location AS location
                ,state_name
                FROM view_sms_posts  ORDER BY s.createdon DESC
Qry;
        $result = $this->db->getStates($strQry);
        $i = 0;
        $arrPosts = array();

        while ($record = mysql_fetch_assoc($result)) {
            $arrPosts[$i] = $record;
            $i++;
        }
        $json = json_encode($arrPosts);
        return $json;
    }
	 public function RecentSMSPosts($limit,$districtid,$categoryid,$mode,$postid){

        switch ($mode){
            case 'recent':
                $districtid = '';
                $categoryid = '';
                break;
            case 'districts':
                $districtid = 'WHERE  districtid IN ('.$districtid.') ';
                $categoryid = '';
                break;
            case 'district':
                $districtid = 'WHERE  districtid='.$districtid.' ';
                $categoryid = '';
                break;
            case 'crop':
                $districtid = 'WHERE  districtid='.$districtid.' AND ';
                $categoryid = 'cropid IN ('.$categoryid.') ';
                 break;
             case 'assembly':
                 $districtid = '';
                 $categoryid = 'WHERE  cropid IN ('.$categoryid.')';
                 break;
             case 'userid':
                 $districtid = '';
                 $categoryid = 'WHERE userid='.$_SESSION['userid'].'';
                 
                 break;
        }
       
        $x = null;
        $strQry = <<<Qry
                SELECT id
                ,CONCAT( "<a href=smspost.php?postid=", id,">",title, "<\/a>" ) AS title
                ,item AS item
                ,district_name
                ,'xxxx' AS phone
                ,createdon AS date
                ,CONCAT( "<a href=smspost.php?postid=", id,">View<\/a>" ) AS action
                ,mode AS type
                ,location AS location
                ,state_name
                FROM view_sms_posts
                $districtid $categoryid 
                ORDER BY createdon DESC
                LIMIT $limit
Qry;
		$result = $this->db->getStates($strQry);
        $i = 0;
        $arrPosts = array();
        
        while ($record = mysql_fetch_assoc($result)) {
            if($record['id']!=$postid){
				$arrPosts[$i] = $record;
				$i++;
			}
        }
        $json = json_encode($arrPosts);
        return $json;        
    }
    public function getContact($postid, $mode){
		
		$contact=$this->db->getvalue("select number from sms_posts where id='{$postid}'");
		if($contact){
			return $contact;
		}
	
	}

}

?>