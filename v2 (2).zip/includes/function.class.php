<?php
@session_start();

class functions {

    function __construct() {
        include("includes/db.class.php");
        $this->db = new Db();
    }

    public function uniqueEmail($email) {
        $result = $this->db->rows("select id,first_name from users where email='$email'");
        if($result==1){
            return true;
        }
        else{
            return false;
        }
    }

    public function insertAction($lTableName, $lValues, $lFlds="") {
        $z = $this->db->fnInsert($lTableName, $lValues, $lFlds = "");
        if ($z) {
            unset($assoc);
            //echo "<script>window.alert('Sucess')</script>";
        }
        else{
		
        }
            //echo "<script>window.alert('Fail')</script>";
        return $z;
    }

    public function editAction($lTableName, $str, $lValue) {
        $z = $this->db->formedit($str, $lTableName, $lValue);
        if ($z) {
            //echo "<script>window.alert('Sucess')</script>";
        }
        else
            //echo "<script>window.alert('Fail')</script>";
        return $z;
    }

    public function deleteAction($lTableName, $lValue) {
        $z = $this->db->rowDelete($lTableName, $lValue);
        if ($z) {
            //echo "<script>window.alert('Sucess')</script>";
        }
        else
            //echo "<script>window.alert('Fail')</script>";
        return $z;
    }

    public function checkUserlogin($email, $password) {
        $result = $this->db->rows("select id,first_name from users where email='$email' AND password='$password'");
        if ($result > 0) {
	    $_SESSION['isMarketAccess'] = false;
            $result1 = $this->db->getValues("select id,first_name,last_name,mode from users where email='$email' AND password='$password'");
	    if($result1[3]==2){
	        $_SESSION['isMarketAccess'] = true;
	    }
            $_SESSION['username'] = $result1[1] . " " . $result1[2];
            $_SESSION['userid'] = $result1[0];
            return true;
        }
        else {
            return false;
        }
    }

    public function startPassword($email, $code) {
        $result = $this->db->runSQL("update users set activationcode='$code' where email='$email'");
        if ($result) {
            return "success";
        }
        else
            return "fail";
    }

    public function resetPassword($email, $code) {
        $result = $this->db->rows("select * from users where email='$email' and activationcode='$code'");
        if ($result > 0)
            return true;
        else
            return false;
    }

    public function changePassword($code, $email, $password) {
        $result = $this->db->runSQL("update users set password='" . md5($password) . "' where email='$email' and activationcode='$code'");
        if ($result) {
            $this->db->runSQL("update users set activationcode='' where email='$email' and password='" . md5($password) . "'");
            return true;
        }
        else
            return false;
    }

    public function changePassword1($old_password, $new_password, $userid) {
        $result = $this->db->runSQL("update users set password='" . md5($new_password) . "' where password='" . md5($old_password) . "' and id='$userid'");
        if ($result)
            return true;
        else
            return false;
    }

    function generateCode() {
        $possible = '$%^23456789abcdefghjkmnpqrstuvwxyzABCDEFGHIJKLMNPQRSTUVWXYZ';
        $code = '';
        $i = 0;
        while ($i < 16) {
            $code .= substr($possible, mt_rand(0, strlen($possible) - 1), 1);
            $i++;
        }
        return $code;
    }

    public function SetSessions($email) {
        $re = $this->db->getStates("select id,first_name,last_name,contact_person,contact_info,mobile_num,mode from users where email='$email' LIMIT 1;");
        while ($result = mysql_fetch_row($re)) {
            
            $_SESSION['id'] = $result[0];
            $_SESSION['userid'] = $result[0];
            $_SESSION['fname'] = $result[1];
            $_SESSION['lname'] = $result[2];
            $_SESSION['fcontact'] = $result[3];
            $_SESSION['faddress'] = $result[4];
            $_SESSION['username'] = $result[1] . " " . $result[2];
            $_SESSION['fmobile'] = $result[5];
            $_SESSION['fmode'] = $result[6];
        }
    }
	
	public function getEmails($cropid, $mode, $userid){
		$strQry = "SELECT group_concat(email separator ','),item FROM view_posts WHERE cropid={$cropid} AND mode!={$mode} AND userid!={$userid}";
		return $this->db->getvalues($strQry);
	}
	
	public function getEmailsCount($cropid, $mode, $userid){
		$strQry = "SELECT count(DISTINCT(email)),item FROM view_posts WHERE cropid={$cropid} AND mode!={$mode} AND userid!={$userid}";
		return $this->db->getvalues($strQry);
	}
	
	public function getAssemblyDistrict($assemblyid, $districtid){
		$strQry = "SELECT u.name,d.name FROM states u,constituencies d WHERE d.id={$assemblyid} AND u.id={$districtid}";
		return $this->db->getValues($strQry);

	}
        
    public function getEmail($postid) {
        $re = $this->db->runSQL("select u.email from users u,posts p where u.id=p.userid AND p.id={$postid} LIMIT 1");
        while ($result = mysql_fetch_row($re)) {
            $email = $result[0];
        }
        return $email;
    }
    public function getOneValue($fields,$tblName,$name,$cond) {
        return $this->db->getvalue("select {$fields} from {$tblName} where {$cond}='$name'");
    }

}