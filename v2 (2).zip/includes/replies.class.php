<?php
@session_start();

class functions {

    function __construct() {
        include("includes/db.class.php");
        $this->db = new Db();
    }

    public function editAction($lTableName, $str, $lValue) {
        $z = $this->db->formedit($str, $lTableName, $lValue);
        if ($z) {
            //echo "<script>window.alert('Sucess')</script>";
        }
        else
            //echo "<script>window.alert('Fail')</script>";
        return $z;
    }
	
	public function editGroupAction($lTableName, $str, $lValue) {
        $z = $this->db->formedits($str, $lTableName, $lValue);
        if ($z) {
            //echo "<script>window.alert('Sucess')</script>";
        }
        else
            //echo "<script>window.alert('Fail')</script>";
        return $z;
    }

    
	
	public function sendRecords( $ids,$tblFlag=0 ) {
	
		$arr = array();
		if($tblFlag==0){
			$re = $this->db->runSQL("SELECT u.id,u.`postid`,u.`message`,u.`name`,u.`email`,u.`phone_number`,s.email,u.`mode_price`,u.`mode_quantity`,u.`mode_minprice` FROM `replies` u,view_posts s WHERE s.id=u.postid AND u.id IN ({$ids});");
		}else{
			$re = $this->db->runSQL("SELECT u.id,u.`postid`,u.`message`,u.`name`,u.`email`,u.`phone_number`,s.additional,u.`mode_price`,u.`mode_quantity`,u.`mode_minprice` FROM `replies` u,market s WHERE s.id=u.postid AND u.id IN ({$ids});");
		}
        while ($result = mysql_fetch_row($re)) {
            $arr[] = $result;
        }
        return $arr;
		
		
	}


        public function getPostReplies( $id, $isLoggedIn=true ) {
		
		$edit = (isSet($_SESSION['sessionid']))?"&nbsp;/&nbsp;<a href=postEdit.php?postid=',id,'>Edit</a>'":"'";
		
		$strQry = "SELECT id,concat('<input type=checkbox name=id[] value=',id,'_',type,' >') AS checkbox
			    ,message,name
                ,email
                ,phone_number
				,mode_minprice
				,mode_price
				,mode_quantity 
                ,CONCAT('<a href=post.php?postid=', postid, '>',postid, '<\/a>' ) AS postid
                ,CONCAT( '<a href=repliesSubmit.php?id=',id,'_',type, '&action=accept>Accept<\/a>&nbsp;/&nbsp;<a href=repliesSubmit.php?id=',id,'_',type,'&action=reject>Reject<\/a>',IF(postbyad=1,CONCAT('&nbsp;/&nbsp;<a href=submitasreply.php?id=',id,'>Ship It</a>'),'') ) AS action
                ,IF(type=1,'Classified',IF(type=2,'Market','SMS Reply')) AS type
				,posted_by AS date
                FROM
                replies	WHERE sent=0 ORDER BY posted_by desc;";
        $result = $this->db->getStates( $strQry );
		$arrPosts = array();
        $i=0;
        while ($record = mysql_fetch_assoc($result)) {
            $arrPosts[$i] = $record;
            $i++;
        }
        $json = json_encode($arrPosts);
        return $json;
    }

    public function RecentSMSPosts($limit,$districtid,$categoryid,$mode){

        switch ($mode){
            case 'recent':
                $districtid = '';
                $categoryid = '';
                break;
            case 'districts':
                $districtid = 's.district IN ('.$districtid.') AND ';
                $categoryid = '';
                break;
            case 'district':
                $districtid = 's.district='.$districtid.' AND ';
                $categoryid = '';
                break;
            case 'crop':
                $districtid = 's.district='.$districtid.' AND ';
                $categoryid = 's.category IN ('.$categoryid.') AND ';
                 break;
             case 'assembly':
                 $districtid = '';
                 $categoryid = 's.category IN ('.$categoryid.') AND ';
                 break;
             case 'userid':
                 $districtid = '';
                 $categoryid = 's.user_id='.$_SESSION['userid'].' AND ';
                 
                 break;
        }
        $x = null;
        $strQry = <<<Qry
                SELECT s.id
                ,CONCAT( "<a href=smspost.php?postid=", s.id,">",s.title, "<\/a>" ) AS title
                ,c.category AS item
                ,st.name AS district_name
                ,s.number AS phone
                ,DATE_FORMAT(s.createdon,'%d/%m/%Y') AS date
                ,CONCAT( "<a href=smspost.php?postid=", s.id,">View<\/a>" ) AS action
                FROM sms_posts s,categories c,states st
                WHERE $districtid $categoryid c.id=s.category AND st.id=s.district
                ORDER BY s.createdon DESC
                LIMIT $limit
Qry;
		
		$result = $this->db->getStates($strQry);
        $i = 0;
        $arrPosts = array();
        
        while ($record = mysql_fetch_assoc($result)) {
            $arrPosts[$i] = $record;
            $i++;
        }
        $json = json_encode($arrPosts);
        return $json;        
    }

}