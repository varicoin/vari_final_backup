<?php
@session_start();
/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of validateClass
 *
 * @author anjithkumar.garapati
 */
class validateClass {
    public $value;
    public $match;
    public static $pattern = '<[^>]*[a-z]*\"?[^>]*>';
    public $validArr = array();
    public function  __construct() {
        $this->value = null;
        $this->match = null;
    }

    public function checkFortags( $arr ){
        $len = count( $arr );
        if($len < 1){
            return 'Array size is zero';            
        }

        foreach($arr AS $index=>$value):
            if(preg_match($this->pattern, $value)):
                $this->validArr['error'] = true;
                $this->validArr[$index]['errMsg'] = 'No tags Should be present';
                $this->validArr['errElements'][] = $index;
            endif;
        endforeach;
        return $validArr;
    }

    public function isEmpty( $name, $value ){
        if(empty($value)){
            return true;
        }
        return false;
    }

    public function checkEmptyIndex($assocArr){
        $len = count( $assocArr );
        if($len<1){
            return 'empty Array';
        }
        foreach($assocArr AS $index => $value):
            if($this->isEmpty($index, $value)):
                $this->validArr['error'] = true;
                $this->validArr[$index]['errMsg'] = 'Field should not be Empty';
                $this->validArr['errElements'][] = $index;
            endif;
        endforeach;
    }

    
}
?>
