<?php
@session_start();
class question {

    function __construct() {
        include("includes/paths.php");
        include($includesPath . "db.class.php");
        $this->db = new Db();
    }

	public function getCategoryNames() {
		$x = '';
        $strQry = "select id,category,parentid from categories WHERE parentid=0 ORDER BY category";
		
		$arr = $this->db->getCategoriesArr( $strQry );
		$result = $this->db->getStates( $strQry );

        $arrPosts = array();
        $i=0;
        while ($record = mysql_fetch_assoc($result)) {
            $arrPosts[$i] = $record;
            $i++;
        }

		return $arrPosts;
		
    }
	
	public function getCategories() {

        $closing = 0;
        $x = null;
        $record_first = true;
        $link = 'questions.php?categoryid=';

        $result = $this->db->getStates("select id,category from categories where parentid=0 order by category");
        while ($re = mysql_fetch_row($result)) {            
            $image = "<div class='cate_img'><a href='$link$re[0]'><img src='images/{$re[1]}.jpg' height='67' width='66' /></a></div>";
			if ($closing / 2 == 0) {
				$x.="<tr>
						<td>&nbsp;</td>
						<td>{$image}<div class='cate_bg'><a href='$link$re[0]'>" . trim($re[1]) . " </a></div></td>";
				$closing = 2;
			} else {
				$x.="<td>&nbsp;</td>
						 <td>{$image}<div class='cate_bg'><a href='$link$re[0]'>" . trim($re[1]) . " </a></div></td>
						 <td>&nbsp;</td>
						 </tr>";
				$closing = 0;
			}
           
        }

        return $x;
    }
	
	public function getCategoryName( $id ) {
        return $this->db->getvalue("select category from categories where id='$id'");
    }
	
	public function getQuestionHomepage() {
		$x = '';
        $strQry = "select id,category,parentid from categories WHERE parentid NOT IN ('-1') ORDER BY category";
		$arr = $this->db->getCategoriesArr( $strQry );
		return $arr;	
		
    }
	
	public function getQuestions( $categoryid, $questionid ) {
		
		$x = '';
        $strQry = "SELECT 
					f.id AS id,
					f.message AS message, 
					u.first_name  AS name,
					DATE_FORMAT(f.updated_on,'%d/%m/%Y')  AS date
				FROM forum f, users u 
					WHERE u.id = f.userid AND f.categoryid = {$categoryid} 
				ORDER BY f.updated_on";
		
		$result = $this->db->getStates( $strQry );
		
        $arrQuestions = array();
        $i=0;
        while( $record = mysql_fetch_assoc( $result ) ) {		
			
            $arrQuestions[$i] = $record;
            $i++;			
        }
		
		$questionid = (empty($questionid))?$arrQuestions[0]['id']:$questionid;
		
		$strQry = "SELECT 
                                        f.id as id,
					f.reply AS reply, 
					DATE_FORMAT(f.updated_on,'%d/%m/%Y') AS date, 
					u.first_name  AS name
				FROM forum_replies f, users u 
					WHERE u.id = f.userid AND f.forumid = {$questionid} 
				ORDER BY f.updated_on";
		
		$result = $this->db->getStates( $strQry );
		$arrReplies = array();
        $i=0;
		while( $record = mysql_fetch_assoc( $result ) ) {		
			
            $arrReplies[$i] = $record;
            $i++;			
        }
		
		return array($arrQuestions, $arrReplies);
	
	}
	
	public function MainCategories($select)
	{
		$x = '<select name="categoryid" id="categoryid" required="required" class="fld1"><option value="">Select the Category</option>';
		$resultSet = $this->db->getStates("select id,category from categories where parentid='0' order by category");
		while($result = mysql_fetch_row($resultSet))
		{		
			if($result[0]==$select)	
				$x.="<option title='Press Ctrl to select category.' value=$result[0] selected=selected>".$result[1]."</option>";
			else
				$x.="<option title='Press Ctrl to select category.' value=$result[0]>".$result[1]."</option>";			
		}
		$x.='</select>';
		return $x;
	} 

}