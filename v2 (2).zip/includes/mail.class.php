<?php
@session_start();

class functions {

    function __construct() {
        include("includes/db.class.php");
        $this->db = new Db();
    }

    public function getPostReplies( $id, $isLoggedIn=true ) {
        $strQry = "SELECT CONCAT('<input type=checkbox name=id[] value=',mails.id,' >') AS id
        ,mails.postid AS post
		,mails.tomail as tomail
        , mails.subject AS subject
        , IF(mails.mode=0,'Classifieds',IF(mails.mode=1,'Market Ad', 'SMS Ad')) AS type
        , mails.added_date AS posted_on
        , CONCAT('<a href=mailaccept.php?id=',mails.id,'>Accept</a> / <a href=mailreject.php?id=',mails.id,'>Reject</a>') AS action 
        FROM 
            mailtracktbl mails
        WHERE 
            mails.status = '-1'
	    ORDER BY added_date DESC;";
        $result = $this->db->getStates( $strQry );
        $arrPosts = array();
        $i=0;
        while ($record = mysql_fetch_assoc($result)) {
            $arrPosts[$i] = $record;
            $i++;
        }
        $json = json_encode($arrPosts);
        return $json;
    }

    public function getMailRecord( $rowid, $isLoggedIn=true ) {
        $strQry = "SELECT mails.id
        ,mails.postid AS post
		,mails.tomail as tomail
        ,mails.subject AS subject
		,mails.message AS message
		,mails.ccmails AS ccmails
        ,IF(mails.mode=0,'Classifieds',IF(mails.mode=1,'Market Ad', 'SMS Ad')) AS type
        ,mails.added_date AS posted_on
        FROM 
            mailtracktbl mails
        WHERE
			mails.id = '{$rowid}' AND mails.status='-1' LIMIT 1;";
        $result = $this->db->getStates( $strQry );
		
		
        $arrPosts = array();
        while ($record = mysql_fetch_assoc($result)) {
			$type = $record['type'];
			switch($type){
				case 'Classifieds':
					$strModeQry = "SELECT cropid, mode from posts where id='{$record['post']}' LIMIT 1;";
					break;
				case 'Market Ad':
					$strModeQry = "SELECT cropid, IF(mode=0,1,0) AS mode from market where id='{$record['post']}' LIMIT 1;";
					break;
				case 'SMS Ad':
					$strModeQry = "SELECT item AS cropid, IF(mode='Selling',0,1) AS mode from sms_posts where id='{$record['post']}' LIMIT 1;";
					break;
			}
			$modeResult = $this->db->getStates( $strModeQry );
			while ($record2 = mysql_fetch_assoc($modeResult)) {
				$record['cropid'] = $record2['cropid'];
				$record['mode'] = $record2['mode'];				
			}
            $arrPosts[] = $record;
        }
        return $arrPosts[0];
    }
	
	public function getEmails($cropid, $mode, $userid){
		$strQry = "SELECT DISTINCT(email) AS email FROM view_posts WHERE cropid='{$cropid}' AND mode!='{$mode}'";
		$result = $this->db->getStates( $strQry );
		while( $record = mysql_fetch_assoc($result) ){
			$arrPosts[] = $record['email'];
		}
		return $arrPosts;
	}
	
    public function sendMail($tomail, $subject, $message, $ccmails=null){
        $headers = 'From: <do-not-reply@vari.co.in>' . "\r\n";
        $headers .= 'MIME-Version: 1.0' . "\r\n";
        $headers .= 'Content-type: text/html; charset=iso-8859-1;' . "\r\n";
        //$headers .= ($ccmails==null)?null:"Bcc:" . $ccmails . "\r\n";
		
		if($ccmails!=null){
			$arrCCmails = explode(",", $ccmails);
			$count = count($arrCCmails);
			for($i=0;$i<$count;$i++){
				mail($arrCCmails[$i], $subject, $message, $headers);
			}
		}
        if(mail($tomail, $subject, $message, $headers)){
            return true;
        }
        else{
            return false;
        }
		return true;
    }
	
	public function updateStatus($id, $status){
        $this->db->formedit("`status`='{$status}'", "mailtracktbl", $id);
    }
}