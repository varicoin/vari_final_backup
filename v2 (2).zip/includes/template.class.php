<?php
@session_start();
class Template {

    private $template;
    private $includes;
    private $headerHtml = 'header.html';
    private $footerHtml = 'footer.html';
    private $html;
    private $currentURL;
    private $login_email;
    public function Template($headerWithLogin=true, $homPage=true) {
	    ob_start();
        include("includes/paths.php");
		$login_email = 'signin';
        if (isset($_SESSION['sessionid'])) {
	        $login_email = $_SESSION['email'];
        }
        $this->includes = $includesPath;
        $this->html = $htmlPath;
        
        $dummyArr = explode("/",$_SERVER['SCRIPT_NAME']);
        $sizeOfArr = count($dummyArr)-1;
        $currentURL = $currentURL;
        $isBanner = ($dummyArr[$sizeOfArr] == 'index.php')?0:1;
         
	    require_once($this->html . 'htmlheader.html');
	    require_once($this->html . 'help.html');
        require_once($this->html . 'header.html');
        require_once($this->html . 'search.html');
        if($homPage){
        	require_once($this->html . 'map.html');
        }
	    $this->footerHtml = 'footer.html';
    }
	
    public function indexHtml($htmlFile, $data, $includes=null) {
        require_once($this->html . $htmlFile);
        require_once($this->html . $this->footerHtml);
   }
	

    public function marketHtml($htmlFile,$includes){
	
		$header_html = (isset($_SESSION['sessionid']))?'user_header.html':'guest_header.html';
		$this->template = file_get_contents(  $this->html.'market/'.$header_html);
        $this->template .= file_get_contents(  $this->html.'market/'.$htmlFile);
		if (isset($_SESSION['sessionid'])) {
            $this->template .= $this->replace("userReplace", $_SESSION['email'], $this->template);
            $this->template .= $this->replace("username", $_SESSION['username'], $this->template);
        }
        if(is_array($includes)){
            foreach($includes AS $key=>$jsInclude){
                $this->template .= file_get_contents($this->html .'market/'. $jsInclude.'.html');
            }
        }
    }

    public function publish() {
	    ob_end_flush();
    }

}

