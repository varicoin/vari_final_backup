<?php
@session_start();
class post {

    function __construct() {
        include("includes/paths.php");
        include_once($includesPath . "db.class.php");
        $this->db = new Db();
    }
    
    public function getPost($postid) {

    	$this->db->formedit("views=views+1","posts",$postid);
    	$postRecord  = $this->db->getRecords("id AS postid, username, state_name, assembly, district_name, category, subcategory, item, title, message, minPrice, price, quantity, quantityType, address, contact_info, mode, postingby, viewCount, editedon","view_posts","where id='$postid' LIMIT 1");
    	if(count($postRecord)==1){
    		$postImagesRecord = $this->db->getRecords("id,name,location", "uploads", "WHERE postid={$postid} AND type=0");
    	
    		foreach($postImagesRecord AS $id=>$arr) {
    			$postRecord[0]['images'][] = $arr;
    		}
    		return $postRecord;
    	}
    	return null;
    }
    
    
    public function getMyPost($postid) {
    	$postRecord = $this->db->getRecords("id AS postid, subject, quantityType AS txtQtyType, quantity, price,minprice,districtid,assemblyid,categoryid,cropid,message,location, contact_info AS mobile, mode, postingby","posts","where id='$postid' AND userid='{$_SESSION['userid']}' LIMIT 1");
    	if(count($postRecord)==1){
    		//$postVideoRecord = $this->db->getRecords("id,name", "uploads", "WHERE postid={$postid} AND type=1");
    		$postImagesRecord = $this->db->getRecords("id,name,location", "uploads", "WHERE postid={$postid} AND type=0 LIMIT 3;");
    
    		foreach($postImagesRecord AS $id=>$arr){
    			$postRecord[0]['images'][] = $arr;
    		}
    		/*if(count($postVideoRecord)==1){
    			$postRecord[0]['video'] = $postVideoRecord[0]['name'];
    			$postRecord[0]['videoid'] = $postVideoRecord[0]['id'];
    		}
    		*/
    		return $postRecord;
    	}
    	return null;
    }
    
    public function cleanData($arr){
    	foreach ($arr as $key=>$value) {
    	    $value = str_ireplace("number:"," ", $value);
    	    $arr[$key] = str_ireplace("string:"," ", $value);
    	}
    	return $arr;
    }
    
    public function validateRequiredData($arr){
    	$errors = array();
    if(empty($arr['subject'])){
    		$errors[] = 'Subject should not be empty';
    	}
    	if(empty($arr['txtQtyType'])){
    		$errors[] = '';
    	}
    	if(empty($arr['price'])){
    		$errors[] = '';
    	}
    	if($arr['minprice']){
    		$errors[] = '';
    	}
    	if($arr['districtid']){
    		$errors[] = '';
    	}
    	if($arr['txtQtyType']){
    		$errors[] = '';
    	}
    	if($arr['subject']){
    		$errors[] = '';
    	}
    	if($arr['txtQtyType']){
    		$errors[] = '';
    	}
    	return $errors;
    }
    
    public function imagesHandler($arr, $postid, $mode, $removedItems){
    	
    	include("includes/resize-class.php");
    	$types = array('jpg','gif','bmp','png','jpeg');
    	if($mode=='update'){
    		if(!empty($removedItems)){
    			$arrRemovedItems = explode(",", $removedItems);
    			foreach($arrRemovedItems AS $key=>$value){
    				list($val,$loc) = explode("_", $value);
    				$this->deleteRecord("uploads", "WHERE id='".$val."' AND postid='".$postid."'");
    				unlink("uploads/".$loc);
    				unlink("uploads/".$loc);
    			}
    		}
    	}
    	for($j=0;$j<sizeof($arr['image']['name']);$j++){
            if($arr['image']['name'][$j]!==""){
    			$arr1 = explode("/", mime_content_type($arr['image']['tmp_name'][$j]));
    			if($arr1[0]=='image'){
    				list($name,$extension) = explode('.',$arr['image']['name'][$j]);
    				$new_name = rand(111,9999999).time().rand(999,44444444).".{$extension}";
    				
    				if(in_array(strtolower($extension),$types)){
    					if(copy($arr['image']['tmp_name'][$j], 'thumbnails/'.$new_name)) {
    						$resizeObj = new resize('thumbnails/'.$new_name);
    						// *** 2) Resize image (options: exact, portrait, landscape, auto, crop)
    						$resizeObj->resizeImage(80, 78,'exact');
    						$resizeObj->saveImage('thumbnails/'.$new_name, 100);
    					}
    					@move_uploaded_file($arr['image']['tmp_name'][$j], "uploads/{$new_name}");
    					if(!empty($name) && !empty($new_name)){
    					    $str = "'','{$name}','{$new_name}',{$postid},now(),0";
    					    $this->insertRecord("uploads", $str);
    					}
    				}
    			}
    		}
    	}
    }
    
    public function editRecord($tableName,$fieldStr, $condtion){
    	
    	if($this->db->editRecord($fieldStr,$tableName,$condtion)){
    		return true;
    	}else{
    		return false;
    	}
    }
    
    public function insertRecord($tableName,$fieldStr){
    	$id = $this->db->fnInsert($tableName,$fieldStr);
    	if($id){
    		return $id;
    	}else{
    		return false;
    	}
    }
    
    public function deleteRecord($tableName,$condition){
    	return $this->db->deleteRecord($tableName,$condition);
    }
    
    public function getNewRecords() {
        $arr = null;
        /*$result = $this->db->getStates("select id,name,image_name from states where parentid='1' ORDER BY name");
        while ($re = mysql_fetch_row($result)) {
            $result2 = $this->db->getStates("select id,name,image_name from states where parentid='{$re[0]}'");
            while($re2 = mysql_fetch_row($result2)) {
				$arr[] = array('group' => $re[1],'name'=>$re2[1],'id'=>$re2[0]);
            }
        }
		$result = $this->db->getStates("SELECT id, category FROM `categories` where parentid='0' ORDER BY category");
        while ($re = mysql_fetch_assoc($result)) {
            $result2 = $this->db->getStates("SELECT id, category FROM `categories` where parentid='{$re['id']}' ORDER BY category");
            while($re2 = mysql_fetch_assoc($result2)){
                
               $arr[] = array('group' => $re['category'],'name'=>$re2['category'],'id'=>$re2['id']);
            }
            
        }
        */
		mysql_set_charset("utf8");
		$result = $this->db->getStates("select id,name,image_name from states where parentid='1' ORDER BY name");
        while ($re = mysql_fetch_row($result)) {
            $result2 = $this->db->getStates("select id,name,image_name from states where parentid='{$re[0]}'");
            while($re2 = mysql_fetch_row($result2)) {
				$result3 = $this->db->getStates("select id,name from constituencies where parent_name='{$re2[0]}'");
				while($re3 = mysql_fetch_row($result3)) {
				    $arr[$re2[0]][] = array('group' => $re2[1],'name'=>$re3[1],'id'=>$re3[0]);
				}
            }
        }
		
        return $arr;
        
    }
    
    public function getNewRecords2() {
        $arr = null;
        $dummyArr2 = array();
        $result = $this->db->getStates("SELECT id, category FROM `categories` where parentid='0' ORDER BY category");
        while ($re = mysql_fetch_assoc($result)) {
            $result2 = $this->db->getStates("SELECT id, category FROM `categories` where parentid='{$re['id']}' ORDER BY category");
            while($re2 = mysql_fetch_assoc($result2)){
                $result3 = $this->db->getStates("SELECT id, category FROM `categories` where parentid='{$re2['id']}' ORDER BY category");
                while($re3 = mysql_fetch_assoc($result3)){
                    $dummyArr2[$re2['id']][] = $re3;
                }
                $dummyArr[] = $re2;
            }
            $dummyArr = null;
        }
        $arr = $dummyArr2;
        return $arr;
    }
    
    public function getImages($id) {
        $arr = null;
        $result = $this->db->getStates("SELECT
                id
                ,name
                ,location
                FROM
                    uploads
                WHERE
                    postid={$id} AND type=0");
        while ($re = mysql_fetch_row($result)) {
            $arr[] = array($re[1], $re[2], $re[0]);
        }
        return $arr;
    }

	public function getVideos($id){
                $arr = null;
		$result = $this->db->getStates("SELECT
                id
                ,name
                FROM
                    uploads
                WHERE
                    postid={$id} AND type=1");
        while ($re = mysql_fetch_row($result)) {
            $arr[] = $re[1];
        }
        return $arr;
	}

    

    public function getComments($postid) {
        $x = '';
        $result = $this->db->getStates("select u.id,u.comment,s.first_name,DATE_FORMAT(u.posted_on,'%d/%m/%Y'),u.rating from comments u,users s where u.posted_by=s.id and u.posid={$postid} order by u.posted_on");
        $counts['+ve'] = 0;
        $counts['-ve'] = 0;
        $counts['neutral'] = 0;
        $color['-ve'] = 'red';
        $color['neutral'] = 'blue';
        $color['+ve'] = 'green';
        while ($re = mysql_fetch_row($result)) {
            $rating = ($re[4]==1)?'+ve':(($re[4]==0)?'neutral':'-ve');

            $counts[$rating]++;
            $x.='<div style="clear:both;"></div>
					<div style="background:url(images/comment_shadow.png) no-repeat left top;height:21px;width:905px;background-color:none;"></div>
					<div class="market_box_left" style="width:100%;">
						<div class="line_black">
							<span style="border-radius:10px;line-height:18px;text-align:justify;">
								<span style="color:'.$color[$rating].';">
								<strong style="color:#060;margin-bottom:0px;padding-bottom:0px;">'.$re[2].' on '.$re[3].'</strong>
                                                                  <b>  <span style="text-align:left;color:'.$color[$rating].';margin-left:300px;">'.$rating.'</span>  <br />
								'.$re[1].'</b></span></span></p>
						</div>
					</div>';
    	}
        $y = '<span style="text-align:left;color:green;margin-left:500px;">+ve('.$counts['+ve'].')</span>&nbsp;&nbsp;&nbsp;
            <span style="text-align:left;color:blue;">neutral('.$counts['neutral'].')
                </span>&nbsp;&nbsp;&nbsp;<span style="text-align:left;color:red;">-ve('.$counts['-ve'].')</span>';
        return array($x, $y);
    }

    public function getRatingSum($postid) {
        $x = '';
        $result = $this->db->getStates("select u.rating from comments u,users s where u.posted_by=s.id and u.posid={$postid} order by u.posted_on");
        $counts['+ve'] = 0;
        $counts['-ve'] = 0;
        $counts['neutral'] = 0;
        while ($re = mysql_fetch_row($result)) {
            $rating = ($re[0]==1)?'+ve':(($re[0]==0)?'neutral':'-ve');
            $counts[$rating]++;

    	}
        $y = '<img src="html/market/images/feedback-pos.png" height="28" width="28" title="Positive" />'.$counts['+ve'].'&nbsp;
            <img src="html/market/images/feedback-nut.png" height="28" width="28" title="Neutral" />'.$counts['neutral'].'&nbsp;<img src="html/market/images/feedback-neg.png" height="28" width="28" title="Negative" />'.$counts['-ve'].'';
        return $y;
    }

	public function getValues($postid)
	{
		return $this->db->getvalues("select id AS postid, username, state_name, location AS assembly, district_name, category, subcategory, item, title, title AS message, minPrice, price, quantity, quantityType, address, contact_info, mode, postingby, viewCount, editedon from view_posts where id='$postid' LIMIT 1");
	}
    
	public function getSMSPost($postid) {
		//$y = $this->getRatingSum($id);
		$this->db->formedit("views=views+1","sms_posts",$postid);
		
		$postRecord  = $this->db->getRecords("id AS postid, 'Vari Admin' AS username, state_name, location AS assembly, district_name, location AS address,category, subcategory, item, title,title AS message, MODE, views AS viewCount,createdon AS editedon","view_sms_posts","where id='$postid' LIMIT 1");
		if(count($postRecord)==1){
			
			return $postRecord;
		}
		return null;
	}
	public function getSMSPostFirebase($postid) {
	 $result =  $this->db->getRecords("price,pricemode, quantity,otherpricemode","sms_posts_firebase","where smsid='$postid'  LIMIT 1");
	
	  if(count($result)==1){
			
			return  $result;
		}
		return null;
	}

}