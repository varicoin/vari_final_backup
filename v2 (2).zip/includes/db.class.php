<?php
@session_start();
final class Db 
	{
        private $mhost		= "dandmudik.ipagemysql.com";
	    private $mdatabase= "varicoin_vari";
	    private $guser		= "varicoinguest";
	    private $gpassword	= "8-&q ICHhW 0*&Z x|4u }_%] b\H1gUeSt";
            private $mresultset	= NULL;
	    private static $gconnection = false; 
             private $iuser		= "varicoinuser";
	    private $ipassword	= "8-&q ICHhW 0*&Z x|4u }_%] b\H1uSer";
	    private static $iconnection = false; 
       
        
function __construct()
{
	if(!self::$gconnection)
	{
            
	    self::$gconnection = mysql_connect($this->mhost,$this->guser,$this->gpassword) or die('conntection failed');
            mysql_select_db($this->mdatabase,self::$gconnection);
            return self::$gconnection;
	}
	else
	{
		return self::$gconnection;
	}
}

function authorizedConstruct()
{
	if(!self::$iconnection)
	{
	    self::$iconnection = mysql_connect($this->mhost,$this->iuser,$this->ipassword) or die('conntections failed');
            mysql_select_db($this->mdatabase,self::$iconnection);
            return self::$iconnection;
	}
	else
	{
		return self::$iconnection;
	}
}

//for runsql connection
function runSQL($rsql)
{
    $result=mysql_query($rsql, self::$gconnection);
    
    return $result;
}

public function fnInsert($lTableName,$lValues,$lFlds="")
{

       if(!self::$iconnection)
	{
            $this->authorizedConstruct();
        }
	if($lFlds=="")
	{
		$lFields		= @mysql_list_fields($this->mdatabase,$lTableName,self::$gconnection);
		$lNumColumns	= @mysql_num_fields($lFields) or die();

		$lFieldName="";

		for($lIndex=0;$lIndex < $lNumColumns;$lIndex++)
		{
			if($lIndex == $lNumColumns-1)
				$lFieldName.=mysql_field_name($lFields,$lIndex);
			else
				$lFieldName.=mysql_field_name($lFields,$lIndex).",";
		}
		$lFflds=$lFieldName;
	}
	$lQry="insert into $lTableName (".$lFflds.") values (".$lValues.")";
	
	$this->mresultset = @mysql_query($lQry,self::$iconnection);
	if($this->mresultset){
            return mysql_insert_id();
        }
        else
        {
            return $this->mresultset;
        }
	
}

	function formedit($str,$tablename,$id)
        {
            if(!self::$iconnection)
    	    {
    		$this->authorizedConstruct();
    	    }
               
            $lQry="UPDATE `".$tablename."` SET ".$str." where id='".$id."' LIMIT 1;";
            if(mysql_query($lQry,self::$iconnection))
            return $lQry;
        }

        function formedits($str,$tablename,$ids)
        {
            $lQry="UPDATE `".$tablename."` SET ".$str." where id IN (".$ids.");";
            if(mysql_query($lQry,self::$iconnection)){
                return $lQry;
            } else{
                return $lQry;
            }
        }

	function rowDelete($tablename,$id)
        {
            $lQry="DELETE FROM `".$tablename."` where id='".$id."' LIMIT 1;";
            if(mysql_query($lQry,self::$iconnection))
            return $lQry;
        }
	function rows($rsql)
	{
            $result=mysql_query($rsql, self::$gconnection);
            return mysql_num_rows($result);
	}
	function getvalues($rsql)
	{
            $result=mysql_query($rsql, self::$gconnection);
            return mysql_fetch_array($result);
	}
	function getStates($rsql)
	{
            $result=mysql_query($rsql, self::$gconnection);
            return $result;
	}
	function getvalue($rsql)
	{
	$result=mysql_query($rsql, self::$gconnection);
	while ($row = mysql_fetch_array($result))
	   {
			return $row[0];
		}
	}
        public function getRecords($fields, $tableName, $conditions){
		$record = null;
		$records = array();
		$lQry = "SELECT {$fields} from {$tableName}";
		if(!empty($conditions)){
			$lQry .= " {$conditions}";
		}
		
		mysql_set_charset("utf8");
		$result=mysql_query($lQry, self::$gconnection);
		while ($record = mysql_fetch_assoc($result))
		{
			$records[] = $record;
		}
		return $records;
	}
	
	function editRecord($str,$tablename,$condition)
	{
		if(!empty($condition)){
			$lQry="UPDATE `".$tablename."` SET ".$str." {$condition}";
			
			if(mysql_query($lQry,self::$iconnection)){
				return true;
			}else{
				return false;
			}
		}else{
			return false;
		}
	}
	
	function deleteRecord($tableName,$condition){
		if(!empty($condition)){
			$lQry="DELETE FROM ".$tableName." {$condition}";
			
			if(mysql_query($lQry,self::$iconnection)){
				return true;
			}else{
				return false;
			}
		}else{
			return false;
		}
	}

        function smsDb($phone,$message){
		$user="varicoin"; //your username
		$password="82843074"; //your password
		$mobilenumbers="91{$phone}"; //enter Mobile numbers comma seperated
		$message = $message;//enter Your Message
		$senderid="SMSCountry"; //Your senderid
		$messagetype="N"; //Type Of Your Message
		$DReports="Y"; //Delivery Reports
		$url="http://www.smscountry.com/SMSCwebservice_Bulk.aspx";
		$message = urlencode($message);
		$ch = curl_init();
		if (!$ch){die("Couldn't initialize a cURL handle");}
		$ret = curl_setopt($ch, CURLOPT_URL,$url);
		curl_setopt ($ch, CURLOPT_POST, 1);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
		curl_setopt ($ch, CURLOPT_POSTFIELDS,
				"User=$user&passwd=$password&mobilenumber=$mobilenumbers&message=$message&sid=$senderid&mtype=$messagetype&DR=$DReports");
		$ret = curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		//If you are behind proxy then please uncomment below line and provide your proxy ip with port.
		// $ret = curl_setopt($ch, CURLOPT_PROXY, "PROXY IP ADDRESS:PORT");
		$curlresponse = curl_exec($ch); // execute
		if(curl_errno($ch))
			return 'curl error : '. curl_error($ch);
			if (empty($ret)) {
				// some kind of an error happened
				die(curl_error($ch));
				curl_close($ch); // close cURL handler
			} else {
				$info = curl_getinfo($ch);
				curl_close($ch); // close cURL handler
				//echo "";
				if($curlresponse){
					return true; //echo "Message Sent Succesfully" ;
				}
			}
	
	}
}