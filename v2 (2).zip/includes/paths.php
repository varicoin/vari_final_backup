<?php
@session_start();

$sitePath= $_SERVER['DOCUMENT_ROOT']."/";

$siteUrl= "http://".$_SERVER['HTTP_HOST']."/";

$htmlPath=$sitePath."html/";

$cssPath=$siteUrl."css/";

$jsPath=$siteUrl."js/";

$includesPath=$sitePath."includes/";

$imagesPath=$sitePath."images/";

$imagesUrl=$siteUrl."images/";

$currentURL =  "http://{$_SERVER['HTTP_HOST']}{$_SERVER['REQUEST_URI']}";

$_SESSION['error'] = (isSet($_SESSION['error']) || empty($_SESSION['error']))?'': $_SESSION['error'];

