<?php
@session_start();
class Admin {
    function __construct() {
        include("includes/paths.php");
        include_once($includesPath . "db.class.php");
        $this->db = new Db();
		$this->page = null;
		$this->strQry = null;
		$this->isMarket = false;
    }
	
	public function parseArray(){
		$result = $this->db->getStates($this->strQry);
        $arrPosts = array();
		$arrPosts['page'] = $this->page;
		$arrPosts['total'] = 150;
		$arrPosts['rows'] = array();
        while ($record = mysql_fetch_assoc($result)) {
			
		    if(isset($record['action']) &&  $record['action']!=null){
				$arrPosts['rows'][] = array(
				    'id' => $record['postid'],
				    'cell' => array($record['id'],$record['subject'], $record['postid'], $record['tomail'], $record['type'], $record['action'], $record['postedon'])
			    );
			}else{
				$arrPosts['rows'][] = array(
				    'id' => $record['postid'],
				    'cell' => array($record['id'], $record['postid'], $record['subject'], $record['message'], $record['tomail'], $record['type'], $record['action'], $record['postedon'])
			    );
			}
        }
        $json = json_encode($arrPosts);
        return $json;
	}
	
	public function getPostMails($page, $rp, $const, $mode) {
        $this->page = $page;
        $pageStart = ($page-1)*$rp;
       
        if($mode==0){
        	$tableName = "view_posts";
            $str = "posts.title AS subject
        	,posts.username
        	,posts.item
        	,posts.mode
        	,posts.itemid
        	,posts.editedon AS date
        	,posts.minPrice
        	,posts.price
        	,CONCAT(posts.state_name,' / ',posts.district_name,' / ',posts.assembly) as location";
			
			$records = $this->db->getRecords("mails.id
	        ,mails.postid AS postid
			,{$str}
	        ,mails.mode=0 AS type
	        ,mails.added_date AS posted_on "
			, ' mailtracktbl mails, '.$tableName.' posts', " where posts.id=mails.postid AND mails.status = '-1' AND mails.mode='$mode' ORDER BY mails.id ASC LIMIT $pageStart, $rp"
		);
        } if($mode==2){
        	$tableName = "view_sms_posts";
        	$str = "posts.title AS subject
        	,posts.item
        	,IF(posts.mode='Selling',0,1) AS mode
        	,posts.cropid AS itemid
        	,posts.location";
			
			$records = $this->db->getRecords("mails.id
	        ,mails.postid AS postid
			,{$str}
	        ,mails.mode=0 AS type
	        ,mails.added_date AS posted_on "
			, ' mailtracktbl mails, '.$tableName.' posts', " where posts.id=mails.postid AND mails.status = '-1' AND mails.mode='$mode' ORDER BY mails.id ASC LIMIT $pageStart, $rp"
		);
        }
        
		
        $i=0;
		foreach($records AS $index=>$arr){
			$ccmails = $this->db->getRecords("group_CONCAT(DISTINCT(posts.email),',') as ccmails, 
					group_CONCAT(DISTINCT(posts.contact_info),',') as ccphones"
					, ' view_posts posts', " where posts.itemid = '{$arr['itemid']}' AND posts.mode NOT IN ('{$arr['mode']}')"
			);
			
			$arr['mode'] = ($arr['mode']==0)?'Selling':'Buying';
			$ccphones = $this->db->getRecords("group_CONCAT(DISTINCT(posts.number),',') as ccphones"
					, ' view_sms_posts posts', " where posts.id NOT IN ({$arr['postid']}) AND posts.cropid = '{$arr['itemid']}' AND posts.MODE NOT IN ('{$arr['mode']}')"
			);
			$records[$index]['ccmails'] = $ccmails[0]['ccmails'];
			$records[$index]['ccphones'] = $ccmails[0]['ccphones'].','.$ccphones[0]['ccphones'];
			  $arr = explode(",,",$records[$index]['ccmails']);
			  $records[$index]['ccmails_count'] = count($arr);
			 
			$i++;
		}
	  
        $json = json_encode($records);
        return $json;
    }
    
    public function getReplyDetails($page, $rp, $const, $mode) {
    	$this->page = $page;
    	$pageStart = ($page-1)*$rp;
    	 
    	if($mode==1){
    		$tableName = "view_posts";
    		$str = "posts.email AS ccemail
        	,posts.contact_info AS ccphone
        	,posts.mode
        	,posts.itemid
        	,posts.editedon AS date
        	,posts.minPrice
        	,posts.price
        	,CONCAT(posts.state_name,' / ',posts.district_name,' / ',posts.assembly) as location";
    	}else{
    		$tableName = "view_sms_posts";
    		$str = "posts.number AS ccphone
      	 	,posts.item
        	,IF(posts.mode='Selling',0,1) AS mode
        	,posts.cropid AS itemid
        	,posts.location";
    	}
    
    
    	$records = $this->db->getRecords(
    			"DISTINCT(r.id),
    			r.message,
    			r.name,
    			r.email AS rmail,
    			r.phone_number,
    			r.mode_minprice,
    			r.mode_price,
    			r.mode_quantity,
    			r.postedon,
    			{$str},
    			r.postid",
    			"replies r, {$tableName} posts", " WHERE r.sent=0 AND r.type='$mode' AND posts.id=r.postid ORDER BY r.id desc LIMIT $pageStart,$rp");
    			 
    			$json = json_encode($records);
    			return $json;
    }
     
    public function getReplyRec($replyid){
    	$records = $this->db->getRecords(
    			"DISTINCT(r.id),
     			r.message,
     			r.name,
     			r.email AS rmail,
     			r.phone_number,
     			r.mode_minprice,
     			r.mode_price,
     			r.mode_quantity,
     			r.postedon,
     			r.postid",
    			"replies r", " WHERE r.id={$replyid} LIMIT 1");
    	return $records[0];
    }
     

   
    public function getPostsOnMobile($numbers, $page, $rp){
        $this->page = $page;
	$pageStart = ($page-1)*34;
          $strQry = <<<Qry
        SELECT CONCAT("<a href=post.php?postid=",id," target='_blank'>",id,"</a>") AS postid, id, title, email, username, item, state_name, district_name,assembly, minPrice, price, quantity, mode, umobile FROM `view_posts` WHERE umobile IN ({$numbers}) LIMIT $pageStart,34
Qry;
     
        $result = $this->db->getStates($strQry);
        $arrPosts = array();
		$arrPosts['page'] = $this->page;
		$arrPosts['total'] = 150;
		$arrPosts['rows'] = array();
        while ($record = mysql_fetch_assoc($result)) {
				$arrPosts['rows'][] = array(
				    'id' => $record['id'],
				    'cell' => array($record['postid'], $record['title'], $record['item'], $record['state_name'], $record['district_name'], $record['assembly'], $record['mode'], $record['umobile'], $record['minPrice'], $record['price'], $record['quantity'], $record['postedby'])
			    );
			
        }
        $json = json_encode($arrPosts);
        return $json;

    }
    public function getHelpRecords($page, $rp){
         $this->page = $page;
	$pageStart = ($page-1)*34;
          $strQry = <<<Qry
        SELECT id, name, emailid, question, details, phone, date FROM `help` WHERE status=0 LIMIT $pageStart,34
Qry;
     
        $result = $this->db->getStates($strQry);
        $arrPosts = array();
		$arrPosts['page'] = $this->page;
		$arrPosts['total'] = 150;
		$arrPosts['rows'] = array();
        while ($record = mysql_fetch_assoc($result)) {
				$arrPosts['rows'][] = array(
				    'id' => $record['id'],
				    'cell' => array($record['id'], $record['name'], $record['emailid'], $record['question'], $record['details'], $record['phone'], $record['date'])
			    );
			
        }
        $json = json_encode($arrPosts);
        return $json;
   }	 
   
   public function getPost( $id) {
       $postRecord = $this->db->getRecords("item,title AS subject,username AS postedBy,IF(mode=1,'Buying','Selling') AS mode,district_name,assembly","view_posts","where id='$id' LIMIT 1");
       return $postRecord[0];
   }
   
    public function getSmsPost( $id) {
		  $tableName="mailtracktbl";
		  $fieldStr = "status=1";
		  $condtion = $id;
	   $this->db->editRecord($fieldStr,$tableName,$condtion);
       $postRecord = $this->db->getRecords("item,title AS subject,userid AS postedBy,IF(MODE=1,'Buying','Selling') AS mode,district_name,location","view_sms_posts","where id='$id' LIMIT 1");
	 
       return $postRecord[0];
   }
   
   public function getAdminData($mode, $id) {
   	switch($mode){
   		case 'mails':
   			$manageRecord = $this->db->getRecords("postid,item,subject,postedByName,modeText,assembly,district_name,postingMode,cropid","view_posts_mails","where id='$id' AND status='-1' LIMIT 1");
   			if(count($manageRecord)==1){
	   			$manageRecord[0]['message'] = "Hi, <br>".$manageRecord[0]['postedByName']." has posted an ".$manageRecord[0]['modeText']." Ad under the Item ".$manageRecord[0]['item'].": ".$manageRecord[0]['subject']
	   			."<br> in Distict ".$manageRecord[0]['district_name'].' and in the assembly constituency '
	   			.$manageRecord[0]['assembly']." to view  <a href='http://vari.co.in/post.php?postid=" . $manageRecord[0]['postid']."'>http://vari.co.in/post.php?postid=".$manageRecord[0]['postid']."</a><br/><br/>
				Do you like the website, is it helpful to you and do you recommend it to your friend and do you have any feedback please send us an email to varicoin@yahoo.com
				<br/><br/>Regards<br/> www.vari.co.in";
   			}
   			//$Smsmessage="{$strMsg} Ad ({$cropname}) {$subject} Min ".strip_tags($minprice) ."- Max ".strip_tags($price)."per ".strip_tags($quantity)." {$postid} 'SMS to 9441851726, Min/Max price & location (PIN) to post SMS AD'";
   			break;
   		case 'sms':
   			$manageRecord = $this->db->getRecords("id AS postid, subject, quantityType AS txtQtyType, quantity, price,minprice,districtid,assemblyid,categoryid,cropid,message,location, contact_info AS mobile, mode, postingby","posts","where id='$postid' AND userid='{$_SESSION['userid']}' LIMIT 1");
   			break;
   	}
   	
   	if(is_array($manageRecord)){
   		$emailRecords = $this->db->getRecords("DISTINCT(email)", "view_posts", "WHERE mode!={$manageRecord[0]['postingMode']} AND cropid={$manageRecord[0]['cropid']}");
   		foreach($emailRecords AS $id=>$arr){
   			$dummyStr  .= $arr['email'].',';
   		}
   		$manageRecord[0]['to_be_sent'] = $dummyStr;
   		return $manageRecord;
   	}
   	return null;
   }
   
   public function sendMail($tomail, $subject, $message, $ccmails=null){
   	$headers = 'From: <do-not-reply@vari.co.in>' . "\r\n";
   	$headers .= 'MIME-Version: 1.0' . "\r\n";
   	$headers .= 'Content-type: text/html; charset=iso-8859-1;' . "\r\n";
   	//$headers .= ($ccmails==null)?null:"Bcc:" . $ccmails . "\r\n";
   
   	if($ccmails!=null){
   		$arrCCmails = explode(",", $ccmails);
   		$count = count($arrCCmails);
   		for($i=0;$i<$count;$i++){
   			mail($arrCCmails[$i], $subject, $message, $headers);
   		}
   	}
   	if(mail($tomail, $subject, $message, $headers)){
   		return true;
   	}
   	else{
   		return false;
   	}
   	return true;
   }
   
   public function sendSMS($message, $ccphones){
       $ccphones = explode(",", $ccphones);
	 
   	   foreach($ccphones AS $key=>$phone){
   		   if(!empty($phone) && $phone!=" "){
               $this->db->smsDb($phone,$message);
   		   }
   	   }
   }
   
   public function getAdminAction($arrValues) {
	   switch($arrValues['action']){
	   		case 'mails':
	   			$this->sendMail('anjithkumar.garapati@gmail.com', $arrValues['subject'], $arrValues['message'], $arrValues['to_be_sent']);
	   			$this->db->editRecord("status='0'",'mailtracktbl',"WHERE id={$arrValues['mailid']} LIMIT 1");
	   			break;
			case 'sms':
	   			$manageRecord = $this->db->getRecords("id AS postid, subject, quantityType AS txtQtyType, quantity, price,minprice,districtid,assemblyid,categoryid,cropid,message,location, contact_info AS mobile, mode, postingby","posts","where id='$postid' AND userid='{$_SESSION['userid']}' LIMIT 1");
	   			break;
	   }
	   return true;
   }
   
   public function updateStatus($mode, $condition, $id){
       switch($mode){
           case 'ads':
               $tablename = "mailtracktbl";
               if($condition == 'Accept'){
                   $str = "status=0";
               }else{
                   $str = "status=1";
               }
               break;
			case 'ads':
               $tablename = "mailtracktbl";
               if($condition == 'Accept'){
                   $str = "status=0";
               }else{
                   $str = "status=1";
               }
               break;   
           case 'replies':
               $tablename = "replies";
               if($condition == 'Accept'){
                   $str = "sent=1";
           	   }else{
           	       $str = "sent='-1'";
           	   }
           	break;
       }
       return $this->db->formedit($str,$tablename,$id);
   }
   
}