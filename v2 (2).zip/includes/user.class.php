<?php
@session_start();
class user {

    function __construct() {
        include_once('includes/paths.php');
        include_once('includes/db.class.php');
        $this->db = new Db();
    }
	
    public function isDataExist($email, $mobile){
        $result = $this->db->rows("select id,first_name from users where email='$email'");
        $arr[0] = ($result==1)?true:false;
        $result = $this->db->rows("select id,first_name from users where mobile_num='$mobile'");
        $arr[1] = ($result==1)?true:false;
        
        return $arr;
    }
    
    public function userInsert($record){
    	$strQry = "null, '{$record['email']}', '{$record['fname']}', '{$record['lname']}', '{$record['password']}', '{$record['fname']}', '{$record['location']}', '0', '{$record['mobile']}', '{$record['mode']}', now(), '','','',''";
    	$userid = $this->db->fnInsert('users', $strQry);
    	 
    	if($userid){
    		$strQry = "null, '{$userid}', '{$record['category']}', '{$record['item']}', '{$record['postingby']}', '{$record['specialOffers']}'";
    		$userid = $this->db->fnInsert('users_preference', $strQry);
    		if($result){
    			return $userid;
    		}else{
    			return $userid;
    		}
    	}
    	else{
    		return false;
    	}
    }
	
	public function postInsert($str){
		$postId = $this->db->insertMulipleRecords('posts', $strQry);
	}
	
	public function insertAction($lTableName, $str) {
        $z = $this->db->fnInsert($lTableName, $str);
        return $z;
    }
	
    public function SetSessions($email) {
        $re = $this->db->getStates("select id,first_name,last_name,contact_person,contact_info,mobile_num,mode from users where email='$email'");
        while ($result = mysql_fetch_row($re)) {
            
            $_SESSION['id'] = $result[0];
            $_SESSION['userid'] = $result[0];
            $_SESSION['fname'] = $result[1];
            $_SESSION['lname'] = $result[2];
            $_SESSION['fcontact'] = $result[3];
            $_SESSION['faddress'] = $result[4];
            $_SESSION['username'] = $result[1] . " " . $result[2];
            $_SESSION['fmobile'] = $result[5];
            $_SESSION['fmode'] = $result[6];
        }
    }
	
	public function getMatchedEmails($cropid, $mode, $userid){
		
	}
	
	public function categoriesCount() {
		$dummyArray=array();
		$getPostsCount = $this->db->getRecords('main_category_id AS id, count(*) AS count','view_posts', 'GROUP BY main_category_id');
		$getSMSPostsCount = $this->db->getRecords('categoryid AS id, count(*) AS count','view_sms_posts', 'GROUP BY categoryid');
		
		foreach($getSMSPostsCount as $key=>$arr){
			$dummyArray[$arr['id']] = $arr['count'];
		}
		foreach($getPostsCount AS $key=>$assocArr){
	         $newArray[$assocArr['id']] = array('count'=>$assocArr['count'],'smsCount'=>$dummyArray[$assocArr['id']]);
		}
		return $newArray;
	}
	
	public function getPosts($mode, $id, $const) {
		if($const!=null && !empty($const)){
			$assemblyCond = "AND view_all_ads.constituencyid={$const}";
		}
		else{
			$assemblyCond = "";
		}
		switch ($mode) {
			case 'category':
				$column_name = 'view_all_ads.main_category_id';
				break;
			case 'state':
				$column_name = 'view_all_ads.stateid';
				break;
		}
		$strQry = <<<Qry
                SELECT view_all_ads.id
                    ,view_all_ads.title AS subject
                    ,view_all_ads.category
                    ,view_all_ads.subcategory
                    ,view_all_ads.item
                    ,view_all_ads.assembly AS assebly_name
                    ,view_all_ads.district_name AS district_name
                    ,view_all_ads.state_name
                    ,date_format(view_all_ads.date, '%d/%m/%Y') AS date
                    ,view_all_ads.mode AS sellingType
                    ,view_all_ads.quantityType AS quantityType
                    ,view_all_ads.quantity AS quantity
                    ,view_all_ads.main_category_id AS categoryid
                    ,view_all_ads.subcategoryid
                    ,view_all_ads.districtid
                    ,view_all_ads.constituencyid AS assemblyid
                    ,view_all_ads.itemid AS cropId
                    ,view_all_ads.postingby
                    ,view_all_ads.classification
                    ,view_all_ads.minPrice
                    ,view_all_ads.price
                FROM view_all_ads
                    WHERE  {$column_name} IN ({$id}) ORDER BY view_all_ads.date DESC;
Qry;
        
		mysql_set_charset("utf8");
		$result = $this->db->getStates($strQry);
		$arrPosts = array();
		while ($record = mysql_fetch_assoc($result)) {
			$arrPosts[] = $record;
		}
		return $arrPosts;
	}
	
	public function getRecentPosts($mode, $id, $const) {
		if($const!=null && !empty($const)){
			$assemblyCond = "AND view_posts.constituencyid={$const}";
		}
		else{
			$assemblyCond = "";
		}
		switch ($mode) {
			case 'category':
				$column_name = 'view_posts.main_category_id';
				break;
			case 'state':
				$column_name = 'view_posts.stateid';
				break;
		}
		$strQry = <<<Qry
                SELECT view_posts.id
                    ,view_posts.title AS subject
                    ,view_posts.category
                    ,view_posts.subcategory
                    ,view_posts.item
                    ,view_posts.assembly AS assebly_name
                    ,view_posts.district_name AS district_name
                    ,view_posts.state_name
                    ,view_posts.editedon AS date
                    ,view_posts.mode AS sellingType
                    ,view_posts.main_category_id AS categoryid
                    ,view_posts.subcategoryid
                    ,view_posts.districtid
                    ,view_posts.constituencyid AS assemblyid
                    ,view_posts.itemid AS cropId
                    ,view_posts.postingby
                    ,uploads.location AS upload
                    ,uploads.name AS upload_name
                    ,'ads' AS classification
                    ,view_posts.minPrice
                    ,view_posts.price
                    ,view_posts.date
                FROM view_posts, uploads
                    WHERE  {$column_name} IN ({$id}) AND uploads.postid=view_posts.id GROUP BY uploads.postid
Qry;
		mysql_set_charset("utf8");
		$result = $this->db->getStates($strQry);
		$arrPosts = array();
		while ($record = mysql_fetch_assoc($result)) {
			$arrPosts[] = $record;
		}
		return $arrPosts;
	}
	
	public function getRecentSMSPosts($mode, $id, $const) {
		if($const!=null && !empty($const)){
			$assemblyCond = "AND assemblyid={$const}";
		}
		else{
			$assemblyCond = "";
		}
		switch ($mode) {
			case 'category':
				$column_name = 'categoryid';
				break;
			case 'state':
				$column_name = 'stateid';
				break;
		}
		$strQry = <<<Qry
                SELECT id
                    ,title AS subject
                    ,category
                    ,subcategory
                    ,item
                    ,location AS assebly_name
                    ,district_name
                    ,state_name
                    ,createdon AS date
                    ,mode AS sellingType
                    ,categoryid
                    ,districtid
                    ,null as assemblyid
                    ,cropid
                    ,null as postingby
                    ,'sms' AS classification
                    ,null as minPrice
                    ,null as price
                    ,createdon as date
                FROM view_sms_posts
                    WHERE  {$column_name} IN ({$id})
Qry;
		mysql_set_charset("utf8");
		$result = $this->db->getStates($strQry);
		$arrPosts = array();
		while ($record = mysql_fetch_assoc($result)) {
			$arrPosts[] = $record;
		}
		return $arrPosts;
	}
	public function MainCategories($select)
	{
		$x=array();
		$result=$this->db->getStates("select id, category from categories where parentid='0' order by category");
		$temp = array();
		$i = 0;
		while($re=mysql_fetch_row($result))
		{
			$result1 = $this->db->getStates("select id, category from categories where parentid='$re[0]' order by category");
			while($re1 = mysql_fetch_row($result1))
			{
				if($re1[0] == $select){
					$temp[$re[1]][] = array('id'=>$re1[0], 'text'=>$re1[1], 'isSelected'=>true);
				}
				else{
					$temp[] = array('id'=>$re1[0], 'text'=>$re1[1]);
				}
			}
			$x[] = array('category' => $re[1], $temp);
			$temp = array();
		}
		return json_encode($x);
	}
	
	public function state($select,$mode="",$required=true) {
		$x=array();
		$result = $this->db->getStates("select id,name from states where parentid='1' order by name");
		$temp = array();
		while ($re = mysql_fetch_row($result))
		{
			$result1 = $this->db->getStates("select id,name from states where parentid='$re[0]' order by name");
			while ($re1 = mysql_fetch_row($result1))
			{
				if ($re1[0] == $select)
				{
					$temp[] = array('id'=>$re1[0], 'text'=>$re1[1], 'isSelected'=>true);
				}
				else
				{
					$temp[] = array('id'=>$re1[0], 'text'=>$re1[1]);
				}
			}
			$x[] = array('state' => $re[1], $temp);
			$temp = array();
		}
		return json_encode($x);
	}
}
