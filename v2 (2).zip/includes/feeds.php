<?php
@session_start();
class feeds {
    function __construct() {
        include_once('../includes/paths.php');
        include_once('includes/db.class.php');
        $this->db = new Db();
		$this->page = null;
		$this->strQry = null;
		$this->isMarket = false;
    }
	
	public function parseArray(){
		$result = $this->db->getStates($this->strQry);
        $arrPosts = array();
		$arrPosts['page'] = $this->page;
		$arrPosts['total'] = 150;
		$arrPosts['rows'] = array();
        while ($record = mysql_fetch_assoc($result)) {
			if($this->isMarket){
				$record['subject'] = '<a href="marketpost.php?postid='.$record['id'].'">'.$record['subject'].'</a>';
			}
		    if(isset($record['action']) &&  $record['action']!=null){
				$arrPosts['rows'][] = array(
				    'id' => $record['id'],
				    'cell' => array($record['id'],$record['subject'], $record['category'], $record['assembly'], $record['district'], $record['state'], $record['type'], $record['action'], $record['postedon'])
			    );
			}else{
				$arrPosts['rows'][] = array(
				    'id' => $record['id'],
				    'cell' => array($record['id'],$record['subject'], $record['category'], $record['assembly'], $record['district'], $record['state'], $record['type'], $record['postedon'])
			    );
			}
        }
        $json = json_encode($arrPosts);
        return $json;
	}
    
 public function getRecentPosts($page, $rp, $const) {
	$this->page = $page;
    $pageStart = ($page-1)*$rp;
	$this->strQry = <<<Qry
		 SELECT id
		,CONCAT( "<a href=post.php?postid=", id,">",title, "<\/a>" ) AS subject
		,category
		,assembly AS assembly
		,district_name AS district
		,state_name AS state
		,IF( view_posts.mode =1, "Buying", "Selling" ) AS type
		,view_posts.editedon AS postedon                
		FROM view_posts
		GROUP BY id
		LIMIT $pageStart, $rp
Qry;
		return $this->parseArray();
        
	}
	
	public function getMyRecentPosts($page, $rp, $const) {
		$this->page = $page;
		$pageStart = ($page-1)*$rp;
		$this->strQry = <<<Qry
		 SELECT id
		,CONCAT( "<a href=post.php?postid=", id,">",title, "<\/a>" ) AS subject
		,category
		,assembly AS assembly
		,district_name AS district
		,state_name AS state
		,IF( view_posts.mode =1, "Buying", "Selling" ) AS type
		,editedon AS postedon
		,CONCAT("<a href=postEdit.php?postid=", id,">Edit<\/a>" ) AS action
		FROM view_posts
		WHERE userid='{$_SESSION['userid']}'
		GROUP BY id
		LIMIT $pageStart, $rp
Qry;
		return $this->parseArray();
	
	}
	
	 public function RecentActions($page,$rp){
		$this->page = $page;
        $pageStart = ($page-1)*$rp;
        $this->strQry = <<<Qry
                SELECT id
                ,subject
                ,category
                ,name  AS assembly
                ,district_name AS district
                ,first_name AS state
                ,date AS postedon
                ,type
                ,action
                FROM view_recent_actions order by prty ASC LIMIT $pageStart,$rp
Qry;

		return $this->parseArray();
    }
	
	public function RecentMarketPosts($page,$rp){
		$this->page = $page;
        $pageStart = ($page-1)*17;
		$this->isMarket = true;
        $this->strQry = <<<Qry
                SELECT id
                ,subject
                ,category
                ,constituency  AS assembly
                ,district
                ,state_name AS state
                ,postedon
                ,mode AS type
                FROM market_view_list GROUP BY id order by updatedon ASC LIMIT $pageStart,$rp
Qry;
		return $this->parseArray();
    }
	
	 public function RecentSMSPosts($page,$districtid,$categoryid,$mode='recent',$rp){
	 $this->page = $page;
		$pageStart = ($page-1)*$rp;
        switch ($mode){
            case 'recent':
                $districtid = '';
                $categoryid = '';
                break;
            case 'districts':
                $districtid = 'WHERE  districtid IN ('.$districtid.') ';
                $categoryid = '';
                break;
            case 'district':
                $districtid = 'WHERE  districtid='.$districtid.' ';
                $categoryid = '';
                break;
            case 'crop':
                $districtid = 'WHERE  districtid='.$districtid.' AND ';
                $categoryid = 'cropid IN ('.$categoryid.') ';
                 break;
             case 'assembly':
                 $districtid = '';
                 $categoryid = 'WHERE  cropid IN ('.$categoryid.')';
                 break;
             case 'userid':
                 $districtid = '';
                 $categoryid = 'WHERE userid='.$_SESSION['userid'].'';
                 break;
        }
       
        $this->strQry = <<<Qry
                SELECT id
                ,CONCAT( "<a href=smspost.php?postid=", id,">",title, "<\/a>" ) AS subject
                ,item AS category
                ,district_name AS district
                ,'xxxx' AS phone
                ,createdon AS postedon
                ,mode AS type
                ,location AS assembly
                ,state_name AS state
                FROM view_sms_posts
                $districtid $categoryid 
                ORDER BY STR_TO_DATE(createdon, '%M %Y') DESC
                LIMIT $pageStart,$rp
Qry;
       
		return $this->parseArray();
    }
}