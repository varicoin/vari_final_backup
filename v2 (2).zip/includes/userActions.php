<?php
@session_start();
class useractions {

    function __construct() {
        include_once('includes/paths.php');
        include_once('includes/db.class.php');
        $this->db = new Db();
    }

    public function getMap($name) {
        return $this->db->getvalue("select map_code from states where image_name='$name'");
    }

    public function getParentId($name,$cond='image_name') {
        return $this->db->getvalue("select id from states where {$cond}='$name'");
    }

    public function getOneValue($fields,$tblName,$name,$cond) {
        return $this->db->getvalue("select {$fields} from {$tblName} where {$cond}='$name'");
    }

    public function getCategoryName($id) {
        return $this->db->getvalue("select category from categories where id='$id'");
    }

    public function getState($id) {
        return $this->db->getvalue("select name from states where id='$id'");
    }

    public function subCategoryid($categoryid) {
        return $this->db->getvalue("select id from categories where parentid='$categoryid' order by category LIMIT 1");
    }

    public function Categoryid($categoryname) {
        return $this->db->getvalue("select id from categories where category='$categoryname' LIMIT 1");
    }

    public function getId($name, $field) {
        return $this->db->getvalue("select $field from states where image_name='$name'");
    }

    public function getAssembly($id) {
        $x = null;
        $result = $this->db->getStates("select id,name from constituencies where parent_name='$id' order by name");
        while ($re = mysql_fetch_row($result)) {
            $bcount = $this->db->getvalue("select count(id) from posts where assemblyid='$re[0]'");
            //$scount = $this->db->getvalue("select count(id) from posts where assemblyid='$re[0]' and mode='0'");
            $x.="<tr>
            <td width='80%'>
            <a href='categories.php?constituency=$re[1]&&name=$re[0]'><font color='green'></font><b>" . $re[1] . "</b></a>
            </td>
            <td><font color='red'>({$bcount})</font></td>
            </tr>";
            // <td><font color='red'>Buyers($bcount)&nbsp;&nbsp;Sellers($scount)</font></td>
        }
        return $x;
    }

    public function getEmails() {
        $result = $this->db->getStates("SELECT id
            ,email
            FROM
            users ORDER BY id");
        $i = 0;
        $j = 0;
        $emails = array();
        while ($re = mysql_fetch_row($result)) {
            if ($i > 15) {
                $j++;
                $i = 0;
            }
            $emails[$j] .= trim($re[1]) . ',';
            $i++;
        }
        return $emails;
    }

    public function getSubCategories($categoryid) {
        $strIds = null;
        $strQry = <<<Qry
            SELECT id
		FROM categories
		WHERE parentid =$categoryid
		ORDER BY id
Qry;
        $result = $this->db->getStates($strQry);
        while ($record = mysql_fetch_assoc($result)) {
            $strIds .= $record['id'] . ', ';
        }
        return substr($strIds, 0, strlen($strIds) - 2);
    }

    public function getRecentPosts($mode, $id, $const) {
        if($const!=null && !empty($const)){
            $assemblyCond = "AND assemblyid={$const}";
        }
        else{
            $assemblyCond = "";
        }
        switch ($mode) {
            case 'category':
                $column_name = 'main_category_id';
                break;
            case 'state':
                $column_name = 'stateid';
                break;
        }
        $strQry = <<<Qry
                SELECT id
                    ,title AS subject
                    ,category
                    ,subcategory
                    ,item
                    ,assembly AS assebly_name
                    ,district_name AS district_name
                    ,state_name
                    ,editedon AS date
                    ,mode AS sellingType
                    ,categoryid
                    ,districtid
                    ,assemblyid
                    ,cropId
                    ,postingby
                    ,upload
                    ,upload_name
                    ,'ads' AS classification
                    ,minPrice
                    ,price
                FROM view_posts
                    WHERE  {$column_name} IN ({$id}) 
                    GROUP BY id
Qry;
        mysql_set_charset("utf8");
        $result = $this->db->getStates($strQry);
        $arrPosts = array();
        while ($record = mysql_fetch_assoc($result)) {
            $arrPosts[] = $record;
        }
        return $arrPosts;
    }
    
    public function getRecentSMSPosts($mode, $id, $const) {
        if($const!=null && !empty($const)){
            $assemblyCond = "AND assemblyid={$const}";
        }
        else{
            $assemblyCond = "";
        }
        switch ($mode) {
            case 'category':
                $column_name = 'categoryid';
                break;
            case 'state':
                $column_name = 'stateid';
                break;
        }
        $strQry = <<<Qry
                SELECT id 
                    ,title AS subject
                    ,category
                    ,subcategory
                    ,item
                    ,location AS assebly_name
                    ,district_name
                    ,state_name
                    ,createdon AS date
                    ,mode AS sellingType
                    ,categoryid
                    ,districtid
                    ,null as assemblyid
                    ,cropid
                    ,null as postingby
                    ,'sms' AS classification
                    ,null as minPrice
                    ,null as price 
                FROM view_sms_posts 
                    WHERE  {$column_name} IN ({$id}) GROUP BY id
Qry;
        mysql_set_charset("utf8");
        $result = $this->db->getStates($strQry);
        $arrPosts = array();
        while ($record = mysql_fetch_assoc($result)) {
            $arrPosts[] = $record;
        }
        return $arrPosts;
    }

    public function getImage($id) {
        $result = $this->db->getStates("SELECT
                id
                ,name
                ,CONCAT('uploads/',location)
                FROM
                    uploads
                WHERE
                    postid={$id} LIMIT 1
            ");
        while ($re = mysql_fetch_row($result)) {
            $arr = array($re[2], $re[1]);
        }
        return $arr;
    }

    public function getmyPosts( $id, $isLoggedIn=true ) {
		
		$edit = (isset($_SESSION['sessionid']) )?" / <a href=postEdit.php?postid=',id,'>Edit</a>'":"'";
		$strQry = "SELECT id
                ,CONCAT( '<a href=post.php?postid=', id, '&name=', assemblyid,'>',title, '<\/a>' ) AS subject
                ,state_name AS first_name
                ,date
                ,userid
                ,item
                ,assembly AS name
                ,district_name
                ,category
                ,IF( mode =1, 'Buying', 'Selling' ) AS type
                ,CONCAT( '<a href=post.php?postid=', id, '&name=', assemblyid,'>View<\/a>".$edit." ) AS action
                FROM
                view_posts
                WHERE
                userid={$id}
                ORDER BY date desc";
        $result = $this->db->getStates( $strQry );
				
		$arrPosts = array();
        $i=0;
        while ($record = mysql_fetch_assoc($result)) {
            $arrPosts[$i] = $record;
            $i++;
        }
        $json = json_encode($arrPosts);
        return $json;
    }

    
    public function RecentActions($mode=null){
        $limit =200;
        $x = null;
        $strQry = <<<Qry
                SELECT subject
                ,category
                ,name AS assembly
                ,district_name AS district
                ,first_name AS state
                ,date AS postedon
                ,type
                FROM view_recent_actions order by prty ASC LIMIT 0,15
Qry;

		$result = $this->db->getStates($strQry);
        $i = 0;
        $arrPosts = array();
        
        while ($record = mysql_fetch_assoc($result)) {
            $arrPosts[$i] = $record;
            $i++;
        }
        $json = json_encode($arrPosts);
        return $json;
		
    }

    public function viewAllPosts($districtid, $assemblyid, $subcategoryid, $cropid,$type) {
        $strAssembly = null;
        $strCrop = null;
        $condition = "";
        $ampersand = false;
        if (!empty($districtid)) {
            $condition = "districtid IN ($districtid)";
            $ampersand = true;
        }
        if (!empty($assemblyid)) {
            $condition .= ($ampersand==TRUE)?' AND ':'';
			$assemblyid = explode(",",$assemblyid);
			for($i=0;$i<sizeof($assemblyid);$i++)
			{
				$assembly = explode("_",$assemblyid[$i]);
				$strAssembly .= $assembly[0].',';
			}
			$strAssembly = substr($strAssembly,0,strlen($strAssembly)-1);
            $condition .= "assemblyid IN ($strAssembly)";
			
            $ampersand = true;
        }
        if (!empty($subcategoryid)) {
            $condition .= ($ampersand==TRUE)?' AND ':'';
            $condition .= "categoryid IN ($subcategoryid)";
            $ampersand = true;
        }
        if (!empty($cropid)) {
            $condition .= ($ampersand==TRUE)?' AND ':'';
			$cropid = explode(",",$cropid);
			for($i=0;$i<sizeof($cropid);$i++) {
				$crop = explode("_",$cropid[$i]);
				$strCrop .= $crop[0].',';
			}
			$strCrop = substr($strCrop,0,strlen($strCrop)-1);
            $condition .= "cropid IN ($strCrop)";
        }
        if(!empty($type)) {
		$condition .= ($ampersand==TRUE)?' AND ':'';
		$type = ($type==2)?0:$type;
		$condition .= "mode='{$type}'";
	}
		$strQry = "SELECT id
                ,CONCAT('<a href=post.php?postid=', id, '&name=', assemblyid,'>',title, '<\/a>' ) AS subject
                ,state_name AS first_name
                ,date
                ,userid
                ,item AS category
                ,assembly AS name
                ,district_name
                ,IF( mode =1, 'Buying', 'Selling' ) AS type
                , CONCAT( '<a href=post.php?postid=', id, '&name=', assemblyid,'>View<\/a>' ) AS action
                FROM
                view_posts
                WHERE
            {$condition}
                ORDER BY id desc";
        $result = $this->db->getStates( $strQry );
		//echo $strQry;	
        
        $arrPosts = array();
        $i=0;
        while ($record = mysql_fetch_assoc($result)) {
            $arrPosts[$i] = $record;
            $i++;
        }
		
        $json = json_encode($arrPosts);
        return $json;
    }
    

    public function viewAllPostIdPosts($postid){
        $strQry = "SELECT id
                ,CONCAT(id,'.','<a href=post.php?postid=', id, '&name=', assemblyid,'>',title, '<\/a>' ) AS subject
                ,state_name AS first_name
                ,date
                ,userid
                ,item AS category
                ,assembly AS name
                ,district_name
                ,IF( mode =1, 'Buying', 'Selling' ) AS type
                , CONCAT( '<a href=post.php?postid=', id, '&name=', assemblyid,'>View<\/a>' ) AS action
                FROM
                view_posts
                WHERE
                id LIKE '%$postid'
                ORDER BY date desc";
        $result = $this->db->getStates( $strQry );
		//echo $strQry;

        $arrPosts = array();
        $i=0;
        while ($record = mysql_fetch_assoc($result)) {
            $arrPosts[$i] = $record;
            $i++;
        }

        $json = json_encode($arrPosts);
        return $json;
    }
    
	public function MainCategories($select)
    {
        $x=array();
        $result=$this->db->getStates("select id, category from categories where parentid='0' order by category");
        $temp = array();
        $i = 0;
        while($re=mysql_fetch_row($result))
        {		
            $result1 = $this->db->getStates("select id, category from categories where parentid='$re[0]' order by category");
            while($re1 = mysql_fetch_row($result1))
            {
                if($re1[0] == $select){
                   $temp[$re[1]][] = array('id'=>$re1[0], 'text'=>$re1[1], 'isSelected'=>true);
                }                            
                else{
                    $temp[] = array('id'=>$re1[0], 'text'=>$re1[1]);
                }
            }
			$x[] = array('category' => $re[1], $temp);
            $temp = array();
        }
        return json_encode($x);
    }
    
	 public function state($select,$mode="",$required=true) {
        $x=array();
        $result = $this->db->getStates("select id,name from states where parentid='1' order by name");
        $temp = array();
        while ($re = mysql_fetch_row($result)) 
        {
            $result1 = $this->db->getStates("select id,name from states where parentid='$re[0]' order by name");
            while ($re1 = mysql_fetch_row($result1)) 
            {
                if ($re1[0] == $select)
                {
                      $temp[] = array('id'=>$re1[0], 'text'=>$re1[1], 'isSelected'=>true);
                }
                else
                {
                    $temp[] = array('id'=>$re1[0], 'text'=>$re1[1]);
                }
            }
            $x[] = array('state' => $re[1], $temp);
            $temp = array();
        }
        return json_encode($x);
    }
	
	public  function getRelatedPosts($id, $const,$postid){
        if($const!=null && !empty($const)){
            $assemblyCond = "AND assemblyid={$const}";
        }
        else{
            $assemblyCond = "";
        }
        $x = null;
                $strQry = <<<Qry
                SELECT id
                ,CONCAT( "<a href=post.php?postid=", id, "&name=", assemblyid,">",title, "<\/a>" ) AS subject
                ,category
                ,assembly AS name
                ,district_name AS district_name
                ,state_name AS first_name
                ,date AS date
                ,IF( mode =1, "Buying", "Selling" ) AS type
                , CONCAT( "<a href=post.php?postid=", id, "&name=", assemblyid,">View<\/a>" ) AS action
                FROM view_posts
        WHERE  cropid={$id}
		{$assemblyCond}
        ORDER BY id DESC
Qry;
        $result = $this->db->getStates($strQry);
        $i = 0;
        $arrPosts = array();
        
        while ($record = mysql_fetch_assoc($result)) {
			if($record['id']!=$postid){
				$arrPosts[$i] = $record;
				$i++;
			}            
        }
        $json = json_encode($arrPosts);
        return $json;
    }


    public function getPostReplies( $id, $isLoggedIn=true ) {
		
		$edit = (isSet($_SESSION['sessionid']))?"&nbsp;/&nbsp;<a href=postEdit.php?postid=',id,'>Edit</a>'":"'";
		$strQry = "SELECT id
               ,IF(type=1,'Clasified','Market') AS first_name
                ,posted_by AS date
                ,name as category
                ,email AS name
                ,phone_number AS district_name
                ,message as subject
                ,CONCAT( '<a href=post.php?postid=', postid, '>',postid, '<\/a>' ) AS type
                ,CONCAT( '<a href=repliesSubmit.php?id=',id, '&action=accept>Accept<\/a>&nbsp;/&nbsp;<a href=repliesSubmit.php?id=',id,'&action=reject>Reject<\/a>' ) AS action
                FROM
                replies
		WHERE sent=0
                ORDER BY posted_by desc";
        $result = $this->db->getStates( $strQry );
				
		$arrPosts = array();
        $i=0;
        while ($record = mysql_fetch_assoc($result)) {
            $arrPosts[$i] = $record;
            $i++;
        }
        $json = json_encode($arrPosts);
        return $json;
    }

    public function RecentSMSPosts($limit,$districtid,$categoryid,$mode){

        switch ($mode){
            case 'recent':
                $districtid = '';
                $categoryid = '';
                break;
            case 'districts':
                $districtid = 'WHERE  districtid IN ('.$districtid.') ';
                $categoryid = '';
                break;
            case 'district':
                $districtid = 'WHERE  districtid='.$districtid.' ';
                $categoryid = '';
                break;
            case 'crop':
                $districtid = 'WHERE  districtid='.$districtid.' AND ';
                $categoryid = 'cropid IN ('.$categoryid.') ';
                 break;
             case 'assembly':
                 $districtid = '';
                 $categoryid = 'WHERE  cropid IN ('.$categoryid.')';
                 break;
             case 'userid':
                 $districtid = '';
                 $categoryid = 'WHERE userid='.$_SESSION['userid'].'';
                 
                 break;
        }
       
        $x = null;
        $strQry = <<<Qry
                SELECT id
                ,CONCAT( "<a href=smspost.php?postid=", id,">",title, "<\/a>" ) AS title
                ,item AS item
                ,district_name
                ,'xxxx' AS phone
                ,createdon AS date
                ,CONCAT( "<a href=smspost.php?postid=", id,">View<\/a>" ) AS action
                ,mode AS type
                ,location AS location
                ,state_name
                FROM view_sms_posts
                $districtid $categoryid 
                ORDER BY id DESC
                LIMIT $limit
Qry;
       
		$result = $this->db->getStates($strQry);
        $i = 0;
        $arrPosts = array();
        
        while ($record = mysql_fetch_assoc($result)) {
            $arrPosts[$i] = $record;
            $i++;
        }
        $json = json_encode($arrPosts);
        return $json;        
    }

    public function getCropsIds($categoryid){
        $strQry = <<<Qry
                SELECT group_CONCAT(id SEPARATOR ',') FROM categories WHERE parentid IN ({$categoryid});
Qry;

        return $this->db->getValue($strQry);
    }

    public function getOpenSourceCodes($districtid){
		 $strQry = <<<Qry
                SELECT bbcode,lat FROM states WHERE id={$districtid};
Qry;
		$result = $this->db->getStates($strQry);
        $arrPosts = array();
		 while ($record = mysql_fetch_assoc($result)) {
            $arrPosts[0] = $record['bbcode'];
            $arrPosts[1] = $record['lat'];
        }
		return $arrPosts;
	}


public function marketList($mode=null, $id=null,$html='list',$limit=''){
		
		$records = 0;
		switch($mode){
			case 'crop':
				$strQuery = "SELECT id, SUBSTRING(subject,1,24), SUBSTRING(price,1,24), location, mode,SUBSTRING(offer_price,1,24) from market_view_list WHERE cropid={$id} GROUP BY id {$limit};";
				$resultSet = $this->db->getStates( $strQuery );
				$records = mysql_num_rows($resultSet);
				$welcomeText = "No Market Advertisements found!";
				break;
			case 'category':
				$strQuery = "SELECT id, SUBSTRING(subject,1,24), SUBSTRING(price,1,24), location, mode,SUBSTRING(offer_price,1,24) from market_view_list WHERE categoryid={$id} GROUP BY id {$limit};";
				$resultSet = $this->db->getStates( $strQuery );	
				$records = mysql_num_rows($resultSet);
				$welcomeText = "No Market Advertisements found!";
				break;
			case 'low':
				$strQuery = "SELECT id, SUBSTRING(subject,1,24), SUBSTRING(price,1,24), location, mode from market_view_list WHERE division=2 GROUP BY id {$limit};";
				$resultSet = $this->db->getStates( $strQuery );	
				$records = mysql_num_rows($resultSet);
				$welcomeText = "Low Price Market Advertisements found!";
				break;
			case 'bumper':
				$strQuery = "SELECT id, SUBSTRING(subject,1,24), SUBSTRING(price,1,24), location, mode,SUBSTRING(offer_price,1,24) from market_view_list WHERE division=1 GROUP BY id {$limit};";
				$resultSet = $this->db->getStates( $strQuery );	
				$records = mysql_num_rows($resultSet);
				$welcomeText = "Bumper Offer Market Advertisements found!";
				break;
			case 'new':
				$strQuery = "SELECT id, SUBSTRING(subject,1,24), SUBSTRING(price,1,24), location, mode,SUBSTRING(offer_price,1,24) from market_view_list  GROUP BY id ORDER BY postedon {$limit};";
				$resultSet = $this->db->getStates( $strQuery );	
				$records = mysql_num_rows($resultSet);
				$welcomeText = "Most Recent Market Advertisements found!";
				break;
			case 'list':
				$strQuery = "SELECT id, SUBSTRING(subject,1,24), SUBSTRING(price,1,24), location, mode,SUBSTRING(offer_price,1,24) from market_view_list GROUP BY id {$limit};";
				$resultSet = $this->db->getStates( $strQuery );
				$welcomeText = "Recent Market Advertisements";
		}
		if($mode==null || $records<1 && $html=='list'){
			$strQuery = "SELECT id, SUBSTRING(subject,1,24), SUBSTRING(price,1,24), location, mode,SUBSTRING(offer_price,1,24) from market_view_list GROUP BY id {$limit};";
			$resultSet = $this->db->getStates( $strQuery );
			$welcomeText = ($mode==null)?"Recent Market Advertisements":"No Market Advertisements found!";
		}
		if($html=='list'){
			$htmlContent = '<div class="right-heading">'.$welcomeText.'</div>
				<div class="main_products">';
			while($record = mysql_fetch_row( $resultSet ) ) {
                                $style=($record[4]=='Buying')?' style="color:green !important;text-decoration:none !important;"':'';
				$htmlContent .= "<div class='items'>
					
						<h2>{$record[1]}</h2>
						<p><img src='market_uploads/{$record[3]}' alt='Image' height='148' width='186' /></p>
						<h1{$style}>{$record[2]}</h1>
						<div class='details-but'><a href='marketpost.php?postid={$record[0]}'>{$record[4]}</a>";
				$htmlContent .= (isSet($_SESSION['isAdmin']) && $_SESSION['isAdmin']==TRUE)?" &nbsp; / &nbsp;<a href='marketEdit.php?postid={$record[0]}'>Edit</a> &nbsp; / &nbsp;<a href='market_submit.php?postid={$record[0]}&action=delete'>Delete</a>":'';
				$htmlContent .= "</div>
					</div>";
			}	
				$htmlContent .= '</div>';
		}elseif($html=='horizontal'){
			$htmlContent='';
			while($record = mysql_fetch_row( $resultSet ) ) {
				 $style=($record[4]=='Buying')?' style="color:green !important;text-decoration:none !important;"':'';
				$htmlContent.="<div class='items market_items_horizantal'>
					<h2>{$record[1]}<a href='marketpost.php?postid={$record[0]}'><img src='market_uploads/{$record[3]}' height='148' width='186' style='float:left;margin-right:0px;' class='img_market_Item' /></a></h2><h1 $style><span>{$record[2]}</span><br  /></h1>				
				</div>";
			}
		}elseif($html=='vertical'){
			$htmlContent='';
			while($record = mysql_fetch_row( $resultSet ) ) {
				$htmlContent .= "<div class='right_items'>
				  <p>{$record[1]}</p>
				  <a href='marketpost.php?postid={$record[0]}'><img src='market_uploads/{$record[3]}' height='111' width='109' /></a>
				  
				  <p><span style='text-decoration: line-through;'>{$record[2]}</span><br  />
					<span  style='font-weight:bold;color:#CC0000;'>{$record[5]}</span></p>
					</div>";
			}
		}
		return $htmlContent;
	}


    public function viewAds($mode,$arrVal,$stock_value) {
		if(in_array($arrVal, array('new','low','bumper'))){
			$stock = " AND stock='{$stock_value}' ";
		}else{
			$stock='';
		}
		$strQuery = "SELECT id, SUBSTRING(subject, 1, 18) AS label, location AS image from market_view_list WHERE mode='{$mode}'{$stock}GROUP BY id ORDER BY postedon DESC  LIMIT 0,9";
		$resultSet = $this->db->getStates( $strQuery ); 
		$i=0;
		$colorClassArr = array('yellow', 'green', 'skyBlue last', 'red', 'darkBlue', 'darlRed last', 'brown', 'greenLight', 'orange last');
		while($record = mysql_fetch_array( $resultSet ) ) {
		    $emptyDiv = (in_array($i, array(2, 5, 8))?true:false);
			$newArr[] = array(
			    'image' => $record[image],
				'label' => $record[label],
				'id' => $record[id],
				'class' => $colorClassArr[$i],
				'emptyDiv' => $emptyDiv
			);
			$i++;
		}
		return json_encode($newArr);		
	}
        public function categoriesCount() {
		 
		 $sql = mysql_query("SELECT 
   						   COUNT(IF(`main_category_id`=1,1,null)) as crops,
						   COUNT(IF(`main_category_id`=369,1,null)) as flowers,
						   COUNT(IF(`main_category_id`=3,1,null)) as animal_products,
						   COUNT(IF(`main_category_id`=360,1,null)) as vegetables,
						   COUNT(IF(`main_category_id`=345,1,null)) as medical_plants,
						   COUNT(IF(`main_category_id`=2,1,null)) as fruits,
						   COUNT(IF(`main_category_id`=6,1,null)) as products,	
						   COUNT(IF(`main_category_id`=4,1,null)) as manure,
						   COUNT(IF(`main_category_id`=319,1,null)) as machine,	
						   COUNT(IF(`main_category_id`=303,1,null)) as organic
						FROM view_posts;");
		 $row = mysql_fetch_assoc($sql);
		
		 return $row;
	 }
}
